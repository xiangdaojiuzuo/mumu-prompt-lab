package com.mumu.intraday.app.ocr;

import android.graphics.Rect;

public final class OcrToken {
    private final String text;
    private final Rect bounds;
    private final float confidence;
    private final boolean lineAggregate;

    public OcrToken(String text, Rect bounds, float confidence) {
        this(text, bounds, confidence, false);
    }

    public OcrToken(String text, Rect bounds, float confidence, boolean lineAggregate) {
        this.text = text == null ? "" : text.trim();
        this.bounds = bounds == null ? new Rect() : new Rect(bounds);
        this.confidence = confidence;
        this.lineAggregate = lineAggregate;
    }

    public String text() { return text; }
    public Rect bounds() { return new Rect(bounds); }
    public float confidence() { return confidence; }
    public boolean lineAggregate() { return lineAggregate; }
}
