package com.mumu.intraday.app.store;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayDeque;

/** Stores text-only decision transitions. No screenshots or account fields are saved. */
public final class SharedPreferencesDecisionHistoryStore {
    private static final String PREFS = "decision_history_v2";
    private static final String KEY_LINES = "lines";
    private static final String SEPARATOR = "\u001E";
    private static final int MAX_LINES = 60;
    private final SharedPreferences preferences;

    public SharedPreferencesDecisionHistoryStore(Context context) {
        preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized void append(String line) {
        String cleaned = clean(line);
        if (cleaned.isBlank()) return;
        ArrayDeque<String> lines = readLines();
        if (!lines.isEmpty() && cleaned.equals(lines.peekLast())) return;
        lines.addLast(cleaned);
        while (lines.size() > MAX_LINES) lines.removeFirst();
        preferences.edit().putString(KEY_LINES, String.join(SEPARATOR, lines)).apply();
    }

    public synchronized String joined() {
        ArrayDeque<String> lines = readLines();
        if (lines.isEmpty()) return "尚無判斷事件。";
        return String.join("\n", lines);
    }

    private ArrayDeque<String> readLines() {
        ArrayDeque<String> output = new ArrayDeque<>();
        String stored = preferences.getString(KEY_LINES, "");
        if (stored == null || stored.isBlank()) return output;
        for (String value : stored.split(SEPARATOR, -1)) {
            String cleaned = clean(value);
            if (!cleaned.isBlank()) output.addLast(cleaned);
        }
        while (output.size() > MAX_LINES) output.removeFirst();
        return output;
    }

    private String clean(String value) {
        if (value == null) return "";
        return value.replace('\n', ' ').replace('\r', ' ').trim();
    }
}
