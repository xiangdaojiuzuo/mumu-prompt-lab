package com.mumu.intraday.app.store;

import android.content.Context;
import android.content.SharedPreferences;

import com.mumu.intraday.core.AlertMemory;

import java.util.Map;

public final class SharedPreferencesAlertMemory implements AlertMemory {
    private static final String FILE = "signal_alert_history";
    private static final String PREFIX = "alert|";
    private final SharedPreferences preferences;

    public SharedPreferencesAlertMemory(Context context) {
        preferences = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    @Override public boolean wasAlerted(String eventKey) {
        return preferences.contains(PREFIX + eventKey);
    }

    @Override public void remember(String eventKey, long alertedAtEpochMs) {
        preferences.edit().putLong(PREFIX + eventKey, alertedAtEpochMs).apply();
    }

    @Override public void clear() {
        SharedPreferences.Editor editor = preferences.edit();
        for (Map.Entry<String, ?> entry : preferences.getAll().entrySet()) {
            if (entry.getKey().startsWith(PREFIX)) editor.remove(entry.getKey());
        }
        editor.apply();
    }
}
