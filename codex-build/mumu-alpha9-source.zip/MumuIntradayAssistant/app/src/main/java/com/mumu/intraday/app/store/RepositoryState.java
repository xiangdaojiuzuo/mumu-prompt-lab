package com.mumu.intraday.app.store;

import com.mumu.intraday.core.SignalDecision;
import com.mumu.intraday.core.OpenPosition;
import com.mumu.intraday.core.PositionAdvice;

public final class RepositoryState {
    private final String monitorStatus;
    private final String timeframeStatus;
    private final String signalStatus;
    private final String latestLog;
    private final String symbol;
    private final String name;
    private final double displayedPrice;
    private final SignalDecision lastDecision;
    private final OpenPosition openPosition;
    private final PositionAdvice positionAdvice;
    private final boolean showingLastKLineDecision;

    public RepositoryState(
            String monitorStatus,
            String timeframeStatus,
            String signalStatus,
            String latestLog,
            String symbol,
            String name,
            double displayedPrice,
            SignalDecision lastDecision,
            OpenPosition openPosition,
            PositionAdvice positionAdvice,
            boolean showingLastKLineDecision
    ) {
        this.monitorStatus = monitorStatus;
        this.timeframeStatus = timeframeStatus;
        this.signalStatus = signalStatus;
        this.latestLog = latestLog;
        this.symbol = symbol;
        this.name = name;
        this.displayedPrice = displayedPrice;
        this.lastDecision = lastDecision;
        this.openPosition = openPosition;
        this.positionAdvice = positionAdvice;
        this.showingLastKLineDecision = showingLastKLineDecision;
    }

    public String monitorStatus() { return monitorStatus; }
    public String timeframeStatus() { return timeframeStatus; }
    public String signalStatus() { return signalStatus; }
    public String latestLog() { return latestLog; }
    public String symbol() { return symbol; }
    public String name() { return name; }
    public double displayedPrice() { return displayedPrice; }
    public SignalDecision lastDecision() { return lastDecision; }
    public OpenPosition openPosition() { return openPosition; }
    public PositionAdvice positionAdvice() { return positionAdvice; }
    public boolean hasOpenPosition() { return openPosition != null; }
    public boolean showingLastKLineDecision() { return showingLastKLineDecision; }
}
