package com.mumu.intraday.app.notify;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import com.mumu.intraday.app.MainActivity;
import com.mumu.intraday.app.R;
import com.mumu.intraday.app.store.RepositoryState;
import com.mumu.intraday.core.AlertGate;
import com.mumu.intraday.core.PositionAdvice;
import com.mumu.intraday.core.PositionAlertGate;
import com.mumu.intraday.core.SignalDecision;
import com.mumu.intraday.core.TaiwanPriceSteps;

import java.util.Locale;

public final class SignalNotifier {
    public static final int FOREGROUND_NOTIFICATION_ID = 2201;
    private static final String SERVICE_CHANNEL = "screen_monitor_service";
    private static final String SIGNAL_CHANNEL = "one_time_signal_alerts";
    private final Context context;
    private final NotificationManager manager;

    public SignalNotifier(Context context) {
        this.context = context.getApplicationContext();
        manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannels();
    }

    public Notification foregroundNotification(String text) {
        return new Notification.Builder(context, SERVICE_CHANNEL)
                .setSmallIcon(R.drawable.ic_assistant)
                .setContentTitle("盤中判斷助手正在監看")
                .setContentText(text == null ? "等待元大 K 線畫面" : text)
                .setContentIntent(contentIntent())
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    public void updateForeground(RepositoryState state) {
        String text = state == null ? "等待元大 K 線畫面" : state.signalStatus();
        manager.notify(FOREGROUND_NOTIFICATION_ID, foregroundNotification(text));
    }

    public void notifySignal(AlertGate.AlertEvent event) {
        if (event == null || !canPost()) return;
        SignalDecision d = event.decision();
        String stock = d.name().isBlank() ? d.symbol() : d.name() + " " + d.symbol();
        String title = stock + "｜已到" + d.direction().label() + "價 "
                + formatPrice(d.triggerReference());
        String operation = d.direction() == com.mumu.intraday.core.SignalDirection.LONG
                ? "確認1分K回踩觸發區不破後，可考慮做多"
                : "確認1分K反彈觸發區不過後，可考慮做空";
        String body = d.direction().label() + "價 " + formatPrice(d.triggerReference())
                + " 已到；" + operation + "。觸發區 "
                + formatPrice(d.zoneLow()) + "–" + formatPrice(d.zoneHigh())
                + "，失效價 " + formatPrice(d.invalidationReference())
                + "，第一停利 " + formatPrice(d.targetOneReference())
                + "，第二停利 " + formatPrice(d.targetTwoReference())
                + "，多空分界 " + formatPrice(d.boundaryReference())
                + "。同一偏多／偏空價格只提醒一次。";
        Notification notification = new Notification.Builder(context, SIGNAL_CHANNEL)
                .setSmallIcon(R.drawable.ic_assistant)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(contentIntent())
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_RECOMMENDATION)
                .build();
        manager.notify(10_000 + Math.abs(event.eventKey().hashCode() % 20_000), notification);
    }

    public void notifyPosition(PositionAlertGate.PositionAlertEvent event) {
        if (event == null || !canPost()) return;
        PositionAdvice advice = event.advice();
        if (advice == null || advice.position() == null) return;
        String stock = advice.position().name().isBlank()
                ? advice.position().symbol()
                : advice.position().name() + " " + advice.position().symbol();
        String title = stock + "｜" + advice.position().side().label()
                + "｜" + advice.action().label();
        String body = "現價 " + formatPrice(advice.currentPrice())
                + "，停損／保護 " + formatPrice(advice.stopReference())
                + "，多空分界 " + formatPrice(advice.boundaryReference())
                + "。" + advice.reason() + "；同一持倉狀態只提醒一次。";
        Notification notification = new Notification.Builder(context, SIGNAL_CHANNEL)
                .setSmallIcon(R.drawable.ic_assistant)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(contentIntent())
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_RECOMMENDATION)
                .build();
        manager.notify(40_000 + Math.abs(event.eventKey().hashCode() % 20_000), notification);
    }

    private PendingIntent contentIntent() {
        Intent intent = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private void createChannels() {
        NotificationChannel service = new NotificationChannel(
                SERVICE_CHANNEL,
                context.getString(R.string.service_channel_name),
                NotificationManager.IMPORTANCE_LOW
        );
        service.setDescription("維持螢幕判斷服務運作；更新時不重複跳出。");
        service.setSound(null, null);
        manager.createNotificationChannel(service);

        NotificationChannel signal = new NotificationChannel(
                SIGNAL_CHANNEL,
                context.getString(R.string.signal_channel_name),
                NotificationManager.IMPORTANCE_HIGH
        );
        signal.setDescription("價格到達偏多或偏空觸發區時，同一訊號提醒一次。");
        manager.createNotificationChannel(signal);
    }

    private boolean canPost() {
        return Build.VERSION.SDK_INT < 33
                || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private String formatPrice(double value) {
        if (!Double.isFinite(value) || value <= 0.0) return "—";
        double tick = TaiwanPriceSteps.tickSize(value);
        int decimals = tick < 0.1 ? 2 : tick < 1.0 ? 1 : 0;
        return String.format(Locale.TAIWAN, "%." + decimals + "f", value);
    }
}
