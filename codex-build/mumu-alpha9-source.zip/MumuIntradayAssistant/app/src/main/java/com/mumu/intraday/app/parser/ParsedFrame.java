package com.mumu.intraday.app.parser;

import com.mumu.intraday.core.MarketSnapshot;

public final class ParsedFrame {
    private final HeaderQuote headerQuote;
    private final boolean kLinePage;
    private final MarketSnapshot snapshot;
    private final String diagnostic;

    public ParsedFrame(
            HeaderQuote headerQuote,
            boolean kLinePage,
            MarketSnapshot snapshot,
            String diagnostic
    ) {
        this.headerQuote = headerQuote;
        this.kLinePage = kLinePage;
        this.snapshot = snapshot;
        this.diagnostic = diagnostic == null ? "" : diagnostic;
    }

    public HeaderQuote headerQuote() { return headerQuote; }
    public boolean kLinePage() { return kLinePage; }
    public MarketSnapshot snapshot() { return snapshot; }
    public String diagnostic() { return diagnostic; }
}
