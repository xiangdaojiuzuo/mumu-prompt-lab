package com.mumu.intraday.app.parser;

import android.graphics.Rect;

import com.mumu.intraday.app.ocr.OcrToken;
import com.mumu.intraday.app.ocr.ScreenVisualHints;
import com.mumu.intraday.core.IndicatorPoint;
import com.mumu.intraday.core.MarketSnapshot;
import com.mumu.intraday.core.MiddlePanel;
import com.mumu.intraday.core.Timeframe;
import com.mumu.intraday.core.Trend;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class YuantaScreenParser {
    private static final Pattern NUMBER = Pattern.compile("[-+]?\\d[\\d,]*(?:\\.\\d+)?");
    private static final Pattern SYMBOL = Pattern.compile("(?<!\\d)\\d{4,6}(?!\\d)");
    private static final Pattern CHINESE_NAME = Pattern.compile("[\\u4e00-\\u9fff]{2,7}");
    private static final Pattern DATE_TIME = Pattern.compile(
            "(?:20\\d{2}/\\d{2}/\\d{2}|\\d{2}/\\d{2})(?:\\s*\\d{2}:\\d{2})?"
    );

    public ParsedFrame parse(
            List<OcrToken> tokens,
            boolean kLinePage,
            ScreenVisualHints hints,
            long capturedAtEpochMs
    ) {
        List<OcrToken> safeTokens = tokens == null ? List.of() : tokens;
        HeaderQuote quote = parseHeader(safeTokens, hints, capturedAtEpochMs);
        if (!kLinePage) {
            return new ParsedFrame(
                    quote,
                    false,
                    null,
                    quote.isUsable()
                            ? "非K線頁：僅更新 " + quote.symbol() + " 現價"
                            : "非K線頁：保留最後有效判斷"
            );
        }

        String dense = denseText(safeTokens);
        Timeframe timeframe = hints == null ? Timeframe.OTHER : hints.selectedTimeframe();
        MiddlePanel middlePanel = detectMiddlePanel(dense);
        IndicatorPoint ma5 = findIndicator(dense, "(?:均[價价]?|[價价]|MA)5");
        IndicatorPoint ma10 = findIndicator(dense, "(?:均[價价]?|[價价]|MA)10");
        IndicatorPoint ma20 = findIndicator(dense, "(?:均[價价]?|[價价]|MA)20");
        IndicatorPoint ma60 = findIndicator(dense, "(?:均[價价]?|[價价]|MA)60");
        IndicatorPoint averageVolume5 = findIndicator(dense, "均量5");
        IndicatorPoint averageVolume20 = findIndicator(dense, "均量20");
        IndicatorPoint k = findIndicator(dense, "(?<![A-Z])K(?:\\(9[,，]3[,，]3\\))?");
        IndicatorPoint d = findIndicator(dense, "(?<![A-Z])D(?:\\(9[,，]3[,，]3\\))?");
        IndicatorPoint j = findIndicator(dense, "(?<![A-Z])J");
        if (!k.isPresent() && d.isPresent() && j.isPresent()) {
            k = new IndicatorPoint((j.value() + 2.0 * d.value()) / 3.0, Trend.UNKNOWN);
        }
        if (!d.isPresent() && k.isPresent() && j.isPresent()) {
            d = new IndicatorPoint((3.0 * k.value() - j.value()) / 2.0, Trend.UNKNOWN);
        }
        IndicatorPoint dif = findIndicator(dense, "DIF(?:\\([^)]*\\))?");
        IndicatorPoint macd = findIndicator(dense, "(?:MACD|DEA)(?:\\([^)]*\\))?");
        IndicatorPoint histogram = findIndicator(dense, "(?:OSC|HIST|柱體|柱体)");

        double open = firstFinite(
                numberInRegion(safeTokens, hints, 0.36, 0.258, 0.61, 0.293),
                findNumberAfter(dense, "開")
        );
        double low = firstFinite(
                numberInRegion(safeTokens, hints, 0.68, 0.258, 0.92, 0.293),
                findNumberAfter(dense, "低")
        );
        double high = firstFinite(
                numberInRegion(safeTokens, hints, 0.36, 0.289, 0.61, 0.326),
                findNumberAfter(dense, "高")
        );
        double close = firstFinite(
                numberInRegion(safeTokens, hints, 0.68, 0.289, 0.92, 0.326),
                findNumberAfter(dense, "收")
        );
        double volume = firstFinite(
                numberInRegion(safeTokens, hints, 0.08, 0.289, 0.32, 0.326),
                findNumberAfter(dense, "成交量"),
                findNumberAfter(dense, "量")
        );
        double currentPrice = quote.currentPrice() > 0.0 ? quote.currentPrice() : close;
        String barTime = findDateTime(readableText(safeTokens));

        double confidence = recognitionConfidence(
                quote,
                timeframe,
                open,
                high,
                low,
                close,
                ma5,
                ma10,
                ma20,
                k,
                d,
                middlePanel,
                hints
        );

        MarketSnapshot.Builder builder = MarketSnapshot.builder()
                .symbol(quote.symbol()).name(quote.name()).timeframe(timeframe)
                .capturedAtEpochMs(capturedAtEpochMs).sourceBarTime(barTime)
                .currentPrice(currentPrice).open(open).high(high).low(low).close(close).volume(volume)
                .ma5(ma5).ma10(ma10).ma20(ma20).ma60(ma60)
                .averageVolume5(averageVolume5).averageVolume20(averageVolume20)
                .middlePanel(middlePanel).macdDif(dif).macdSignal(macd).macdHistogram(histogram)
                .bollingerUpper(findNumberAfter(dense, "布林上20"))
                .bollingerMiddle(findNumberAfter(dense, "布林中20"))
                .bollingerLower(findNumberAfter(dense, "布林下20"))
                .k(k).d(d).j(j)
                .recognitionConfidence(confidence)
                .stableFrame(false);

        if (timeframe == Timeframe.OTHER) builder.addRecognitionNote("未辨認日K／5分K／1分K選取色");
        if (middlePanel == MiddlePanel.UNKNOWN) builder.addRecognitionNote("中間視窗不是可辨認的MACD或成交量能");
        if (!quote.isUsable()) builder.addRecognitionNote("股票名稱／代號／現價辨識不完整");

        MarketSnapshot snapshot = builder.build();
        String diagnostic = diagnostic(snapshot, safeTokens, hints);
        return new ParsedFrame(quote, true, snapshot, diagnostic);
    }

    private HeaderQuote parseHeader(List<OcrToken> tokens, ScreenVisualHints hints, long capturedAtEpochMs) {
        int width = hints == null ? 1080 : hints.width();
        int height = hints == null ? 2400 : hints.height();
        String symbol = "";
        String name = "";
        double price = Double.NaN;
        int bestPriceHeight = -1;

        for (OcrToken token : tokens) {
            if (token.lineAggregate()) continue;
            Rect bounds = token.bounds();
            double centerY = bounds.centerY() / (double) Math.max(1, height);
            double centerX = bounds.centerX() / (double) Math.max(1, width);
            String text = normalize(token.text());
            if (centerY >= 0.080 && centerY <= 0.182) {
                Matcher symbolMatcher = SYMBOL.matcher(text);
                if (symbol.isBlank() && centerX <= 0.40 && symbolMatcher.find()) {
                    symbol = symbolMatcher.group();
                }
                if (name.isBlank() && centerX <= 0.42) {
                    Matcher nameMatcher = CHINESE_NAME.matcher(text);
                    if (nameMatcher.find() && !excludedName(nameMatcher.group())) name = nameMatcher.group();
                }
                if (centerX >= 0.30 && centerX <= 0.72 && bounds.height() > bestPriceHeight) {
                    Matcher numberMatcher = NUMBER.matcher(text);
                    if (numberMatcher.matches()) {
                        double candidate = parseNumber(numberMatcher.group());
                        if (candidate > 0.0 && candidate < 100_000.0) {
                            price = candidate;
                            bestPriceHeight = bounds.height();
                        }
                    }
                }
            }
        }
        double confidence = 0.0;
        if (!symbol.isBlank()) confidence += 0.40;
        if (!name.isBlank()) confidence += 0.20;
        if (price > 0.0) confidence += 0.40;
        return new HeaderQuote(symbol, name, price, capturedAtEpochMs, confidence);
    }

    private boolean excludedName(String value) {
        return value.contains("個股資訊") || value.contains("个股资讯")
                || value.contains("分時") || value.contains("价量")
                || value.contains("價量") || value.contains("指標")
                || value.contains("法人") || value.contains("自訂");
    }

    private MiddlePanel detectMiddlePanel(String dense) {
        String upper = dense.toUpperCase(Locale.ROOT);
        if (upper.contains("DIF") || upper.contains("MACD") || upper.contains("OSC") || upper.contains("DEA")) {
            return MiddlePanel.MACD;
        }
        if (dense.contains("成交量") || dense.contains("均量")) return MiddlePanel.VOLUME;
        return MiddlePanel.UNKNOWN;
    }

    private IndicatorPoint findIndicator(String dense, String labelRegex) {
        Pattern pattern = Pattern.compile(
                "(?:" + labelRegex + ")[:：]?([-+]?\\d[\\d,]*(?:\\.\\d+)?)([↑↓↗↘]?)",
                Pattern.CASE_INSENSITIVE
        );
        Matcher matcher = pattern.matcher(dense);
        if (!matcher.find()) return IndicatorPoint.missing();
        return new IndicatorPoint(parseNumber(matcher.group(1)), Trend.fromArrow(matcher.group(2)));
    }

    private double findNumberAfter(String dense, String label) {
        Pattern pattern = Pattern.compile(
                Pattern.quote(label) + "[:：]?([-+]?\\d[\\d,]*(?:\\.\\d+)?)"
        );
        Matcher matcher = pattern.matcher(dense);
        return matcher.find() ? parseNumber(matcher.group(1)) : Double.NaN;
    }

    private double numberInRegion(
            List<OcrToken> tokens,
            ScreenVisualHints hints,
            double left,
            double top,
            double right,
            double bottom
    ) {
        int width = hints == null ? 1080 : Math.max(1, hints.width());
        int height = hints == null ? 2400 : Math.max(1, hints.height());
        double best = Double.NaN;
        int bestHeight = -1;
        for (OcrToken token : tokens) {
            if (token.lineAggregate()) continue;
            Rect bounds = token.bounds();
            double x = bounds.centerX() / (double) width;
            double y = bounds.centerY() / (double) height;
            if (x < left || x > right || y < top || y > bottom) continue;
            Matcher matcher = NUMBER.matcher(normalize(token.text()));
            if (!matcher.find()) continue;
            double candidate = parseNumber(matcher.group());
            if (Double.isFinite(candidate) && bounds.height() > bestHeight) {
                best = candidate;
                bestHeight = bounds.height();
            }
        }
        return best;
    }

    private String findDateTime(String text) {
        Matcher matcher = DATE_TIME.matcher(text);
        return matcher.find() ? matcher.group().replaceAll("\\s+", " ").trim() : "";
    }

    private double recognitionConfidence(
            HeaderQuote quote,
            Timeframe timeframe,
            double open,
            double high,
            double low,
            double close,
            IndicatorPoint ma5,
            IndicatorPoint ma10,
            IndicatorPoint ma20,
            IndicatorPoint k,
            IndicatorPoint d,
            MiddlePanel middlePanel,
            ScreenVisualHints hints
    ) {
        double score = quote.confidence() * 0.22;
        if (timeframe != Timeframe.OTHER) score += 0.16;
        if (Double.isFinite(open)) score += 0.035;
        if (Double.isFinite(high)) score += 0.035;
        if (Double.isFinite(low)) score += 0.035;
        if (Double.isFinite(close)) score += 0.055;
        if (ma5.isPresent()) score += 0.08;
        if (ma10.isPresent()) score += 0.08;
        if (ma20.isPresent()) score += 0.10;
        if (k.isPresent()) score += 0.07;
        if (d.isPresent()) score += 0.07;
        if (middlePanel != MiddlePanel.UNKNOWN) score += 0.07;
        if (hints != null) score += Math.min(0.04, hints.selectionConfidence() * 0.04);
        return Math.max(0.0, Math.min(1.0, score));
    }

    private String diagnostic(
            MarketSnapshot s,
            List<OcrToken> tokens,
            ScreenVisualHints hints
    ) {
        List<String> parts = new ArrayList<>();
        parts.add(s.name() + " " + s.symbol());
        parts.add(s.timeframe().label());
        parts.add(s.middlePanel().label());
        if (s.effectiveClose() > 0.0) parts.add("現價 " + s.effectiveClose());
        if (s.ma5().isPresent()) parts.add("MA5 " + s.ma5().value());
        if (s.ma10().isPresent()) parts.add("MA10 " + s.ma10().value());
        if (s.ma20().isPresent()) parts.add("MA20 " + s.ma20().value());
        if (s.k().isPresent() && s.d().isPresent()) parts.add("KD " + s.k().value() + "/" + s.d().value());
        parts.add("辨識 " + Math.round(s.recognitionConfidence() * 100.0) + "%");
        if (!s.missingRequiredFields().isEmpty()) {
            parts.add("缺 " + String.join("、", s.missingRequiredFields()));
        }
        if (!s.hasVolumePanelData() && !s.hasMacdData()) parts.add("缺 MACD／量能");
        if (!s.missingRequiredFields().isEmpty()
                || (!s.hasVolumePanelData() && !s.hasMacdData())) {
            String raw = chartLegendText(tokens, hints);
            if (!raw.isBlank()) parts.add("OCR原文 " + raw);
        }
        return String.join("｜", parts);
    }

    private String chartLegendText(List<OcrToken> tokens, ScreenVisualHints hints) {
        int height = hints == null ? 2400 : Math.max(1, hints.height());
        StringBuilder value = new StringBuilder();
        for (OcrToken token : tokens) {
            double y = token.bounds().centerY() / (double) height;
            boolean legendBand = (y >= 0.258 && y <= 0.378)
                    || (y >= 0.600 && y <= 0.652)
                    || (y >= 0.742 && y <= 0.790);
            if (!legendBand) continue;
            String text = normalize(token.text()).replaceAll("\\s+", "");
            if (text.isBlank()) continue;
            if (value.length() > 0) value.append('/');
            value.append(text);
            if (value.length() >= 180) break;
        }
        if (value.length() > 180) return value.substring(0, 180) + "…";
        return value.toString();
    }

    private String denseText(List<OcrToken> tokens) {
        return readableText(tokens)
                .replaceAll("\\s+", "")
                .replace("，", ",")
                .replace("；", ":")
                .replace("﹕", ":");
    }

    private String readableText(List<OcrToken> tokens) {
        StringBuilder value = new StringBuilder();
        for (OcrToken token : tokens) value.append(normalize(token.text())).append(' ');
        return value.toString().trim();
    }

    private String normalize(String value) {
        if (value == null) return "";
        return value.trim()
                .replace('Ｏ', '0')
                .replace('０', '0')
                .replace('１', '1')
                .replace('２', '2')
                .replace('３', '3')
                .replace('４', '4')
                .replace('５', '5')
                .replace('６', '6')
                .replace('７', '7')
                .replace('８', '8')
                .replace('９', '9')
                .replace('．', '.')
                .replace('Ｉ', '1')
                .replace('ｌ', '1')
                .replace('｜', '1');
    }

    private double parseNumber(String value) {
        try {
            return Double.parseDouble(value.replace(",", ""));
        } catch (Exception ignored) {
            return Double.NaN;
        }
    }

    private double firstFinite(double... values) {
        for (double value : values) if (Double.isFinite(value)) return value;
        return Double.NaN;
    }
}
