package com.mumu.intraday.app.store;

import android.content.Context;
import android.content.SharedPreferences;

import com.mumu.intraday.core.IndicatorPoint;
import com.mumu.intraday.core.MarketSnapshot;
import com.mumu.intraday.core.MiddlePanel;
import com.mumu.intraday.core.Timeframe;
import com.mumu.intraday.core.Trend;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.EnumMap;
import java.util.Map;

/** Keeps only numeric K-line observations; screenshots are never persisted. */
public final class SharedPreferencesSnapshotStore {
    private static final String PREFS = "recent_kline_snapshots_v1";
    private final SharedPreferences preferences;

    public SharedPreferencesSnapshotStore(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public Map<Timeframe, MarketSnapshot> loadFresh(long nowEpochMs) {
        Map<Timeframe, MarketSnapshot> result = new EnumMap<>(Timeframe.class);
        SharedPreferences.Editor cleanup = null;
        for (Timeframe timeframe : new Timeframe[]{Timeframe.DAILY, Timeframe.MIN_5, Timeframe.MIN_1}) {
            String key = timeframe.name();
            String encoded = preferences.getString(key, "");
            if (encoded == null || encoded.isBlank()) continue;
            try {
                MarketSnapshot snapshot = decode(new JSONObject(encoded));
                if (snapshot.timeframe() == timeframe
                        && snapshot.stableFrame()
                        && snapshot.isFresh(nowEpochMs)) {
                    result.put(timeframe, snapshot);
                } else {
                    if (cleanup == null) cleanup = preferences.edit();
                    cleanup.remove(key);
                }
            } catch (Exception ignored) {
                if (cleanup == null) cleanup = preferences.edit();
                cleanup.remove(key);
            }
        }
        if (cleanup != null) cleanup.apply();
        return result;
    }

    public void save(MarketSnapshot snapshot) {
        if (snapshot == null || snapshot.timeframe() == Timeframe.OTHER || !snapshot.stableFrame()) return;
        try {
            preferences.edit()
                    .putString(snapshot.timeframe().name(), encode(snapshot).toString())
                    .apply();
        } catch (Exception ignored) {
        }
    }

    public void clear() {
        preferences.edit().clear().apply();
    }

    private JSONObject encode(MarketSnapshot value) throws Exception {
        JSONObject json = new JSONObject();
        json.put("symbol", value.symbol());
        json.put("name", value.name());
        json.put("timeframe", value.timeframe().name());
        json.put("captured_at", value.capturedAtEpochMs());
        json.put("bar_time", value.sourceBarTime());
        putNumber(json, "current", value.currentPrice());
        putNumber(json, "open", value.open());
        putNumber(json, "high", value.high());
        putNumber(json, "low", value.low());
        putNumber(json, "close", value.close());
        putNumber(json, "volume", value.volume());
        putPoint(json, "ma5", value.ma5());
        putPoint(json, "ma10", value.ma10());
        putPoint(json, "ma20", value.ma20());
        putPoint(json, "ma60", value.ma60());
        putPoint(json, "avg_volume5", value.averageVolume5());
        putPoint(json, "avg_volume20", value.averageVolume20());
        json.put("middle_panel", value.middlePanel().name());
        putPoint(json, "macd_dif", value.macdDif());
        putPoint(json, "macd_signal", value.macdSignal());
        putPoint(json, "macd_histogram", value.macdHistogram());
        putNumber(json, "boll_upper", value.bollingerUpper());
        putNumber(json, "boll_middle", value.bollingerMiddle());
        putNumber(json, "boll_lower", value.bollingerLower());
        putPoint(json, "k", value.k());
        putPoint(json, "d", value.d());
        putPoint(json, "j", value.j());
        json.put("confidence", value.recognitionConfidence());
        json.put("stable", value.stableFrame());
        JSONArray notes = new JSONArray();
        for (String note : value.recognitionNotes()) notes.put(note);
        json.put("notes", notes);
        return json;
    }

    private MarketSnapshot decode(JSONObject json) {
        MarketSnapshot.Builder value = MarketSnapshot.builder()
                .symbol(json.optString("symbol", ""))
                .name(json.optString("name", ""))
                .timeframe(enumOr(Timeframe.class, json.optString("timeframe", ""), Timeframe.OTHER))
                .capturedAtEpochMs(json.optLong("captured_at", 0L))
                .sourceBarTime(json.optString("bar_time", ""))
                .currentPrice(number(json, "current"))
                .open(number(json, "open"))
                .high(number(json, "high"))
                .low(number(json, "low"))
                .close(number(json, "close"))
                .volume(number(json, "volume"))
                .ma5(point(json, "ma5"))
                .ma10(point(json, "ma10"))
                .ma20(point(json, "ma20"))
                .ma60(point(json, "ma60"))
                .averageVolume5(point(json, "avg_volume5"))
                .averageVolume20(point(json, "avg_volume20"))
                .middlePanel(enumOr(
                        MiddlePanel.class,
                        json.optString("middle_panel", ""),
                        MiddlePanel.UNKNOWN
                ))
                .macdDif(point(json, "macd_dif"))
                .macdSignal(point(json, "macd_signal"))
                .macdHistogram(point(json, "macd_histogram"))
                .bollingerUpper(number(json, "boll_upper"))
                .bollingerMiddle(number(json, "boll_middle"))
                .bollingerLower(number(json, "boll_lower"))
                .k(point(json, "k"))
                .d(point(json, "d"))
                .j(point(json, "j"))
                .recognitionConfidence(json.optDouble("confidence", 0.0))
                .stableFrame(json.optBoolean("stable", false));
        JSONArray notes = json.optJSONArray("notes");
        if (notes != null) {
            for (int index = 0; index < notes.length(); index++) {
                value.addRecognitionNote(notes.optString(index, ""));
            }
        }
        return value.build();
    }

    private void putNumber(JSONObject json, String key, double value) throws Exception {
        if (Double.isFinite(value)) json.put(key, value);
    }

    private void putPoint(JSONObject json, String key, IndicatorPoint point) throws Exception {
        if (point == null || !point.isPresent()) return;
        json.put(key, point.value());
        json.put(key + "_trend", point.trend().name());
    }

    private double number(JSONObject json, String key) {
        return json.has(key) ? json.optDouble(key, Double.NaN) : Double.NaN;
    }

    private IndicatorPoint point(JSONObject json, String key) {
        if (!json.has(key)) return IndicatorPoint.missing();
        return new IndicatorPoint(
                json.optDouble(key, Double.NaN),
                enumOr(Trend.class, json.optString(key + "_trend", ""), Trend.UNKNOWN)
        );
    }

    private <T extends Enum<T>> T enumOr(Class<T> type, String value, T fallback) {
        try {
            return Enum.valueOf(type, value);
        } catch (Exception ignored) {
            return fallback;
        }
    }
}
