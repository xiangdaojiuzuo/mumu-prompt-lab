package com.mumu.intraday.app.ocr;

import com.mumu.intraday.core.Timeframe;

public final class ScreenVisualHints {
    private final int width;
    private final int height;
    private final boolean kLineTabSelected;
    private final Timeframe selectedTimeframe;
    private final double selectionConfidence;

    public ScreenVisualHints(
            int width,
            int height,
            boolean kLineTabSelected,
            Timeframe selectedTimeframe,
            double selectionConfidence
    ) {
        this.width = width;
        this.height = height;
        this.kLineTabSelected = kLineTabSelected;
        this.selectedTimeframe = selectedTimeframe == null ? Timeframe.OTHER : selectedTimeframe;
        this.selectionConfidence = Math.max(0.0, Math.min(1.0, selectionConfidence));
    }

    public int width() { return width; }
    public int height() { return height; }
    public boolean kLineTabSelected() { return kLineTabSelected; }
    public Timeframe selectedTimeframe() { return selectedTimeframe; }
    public double selectionConfidence() { return selectionConfidence; }
}
