package com.mumu.intraday.app.capture;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.mumu.intraday.app.notify.SignalNotifier;
import com.mumu.intraday.app.ocr.SafeScreenOcrEngine;
import com.mumu.intraday.app.overlay.OverlayController;
import com.mumu.intraday.app.parser.FrameStabilizer;
import com.mumu.intraday.app.parser.ParsedFrame;
import com.mumu.intraday.app.parser.YuantaScreenParser;
import com.mumu.intraday.app.store.RepositoryState;
import com.mumu.intraday.app.store.SharedPreferencesDecisionHistoryStore;
import com.mumu.intraday.app.store.SharedPreferencesAlertMemory;
import com.mumu.intraday.app.store.SharedPreferencesPositionStore;
import com.mumu.intraday.app.store.SharedPreferencesSnapshotStore;
import com.mumu.intraday.app.store.SnapshotRepository;
import com.mumu.intraday.core.AlertGate;
import com.mumu.intraday.core.MarketSnapshot;
import com.mumu.intraday.core.MultiTimeframeEngine;
import com.mumu.intraday.core.PositionAlertGate;
import com.mumu.intraday.core.PositionManager;
import com.mumu.intraday.core.PositionSide;

import java.nio.ByteBuffer;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ScreenCaptureService extends Service {
    public static final String ACTION_START = "com.mumu.intraday.action.START";
    public static final String ACTION_STOP = "com.mumu.intraday.action.STOP";
    public static final String ACTION_RESET_ALERTS = "com.mumu.intraday.action.RESET_ALERTS";
    public static final String ACTION_REQUEST_STATUS = "com.mumu.intraday.action.REQUEST_STATUS";
    public static final String ACTION_STATUS = "com.mumu.intraday.action.STATUS";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_PROJECTION_DATA = "projection_data";
    public static final String EXTRA_MONITOR_STATUS = "monitor_status";
    public static final String EXTRA_TIMEFRAME_STATUS = "timeframe_status";
    public static final String EXTRA_SIGNAL_STATUS = "signal_status";
    public static final String EXTRA_LATEST_LOG = "latest_log";

    private static final long ANALYZE_INTERVAL_MS = 1_200L;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private HandlerThread workerThread;
    private Handler workerHandler;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private SafeScreenOcrEngine ocrEngine;
    private YuantaScreenParser parser;
    private FrameStabilizer stabilizer;
    private SnapshotRepository repository;
    private OverlayController overlay;
    private SignalNotifier notifier;
    private RepositoryState lastState;
    private long lastAnalyzeAt;
    private boolean activeCapture;
    private boolean releasingCapture;

    @Override public void onCreate() {
        super.onCreate();
        workerThread = new HandlerThread("market-screen-reader");
        workerThread.start();
        workerHandler = new Handler(workerThread.getLooper());
        ocrEngine = new SafeScreenOcrEngine();
        parser = new YuantaScreenParser();
        stabilizer = new FrameStabilizer();
        notifier = new SignalNotifier(this);
        SharedPreferencesAlertMemory alertMemory = new SharedPreferencesAlertMemory(this);
        AlertGate gate = new AlertGate(alertMemory, 2);
        PositionAlertGate positionGate = new PositionAlertGate(alertMemory, 2);
        repository = new SnapshotRepository(
                new MultiTimeframeEngine(),
                gate,
                new PositionManager(),
                positionGate,
                new SharedPreferencesPositionStore(this),
                new SharedPreferencesSnapshotStore(this),
                new SharedPreferencesDecisionHistoryStore(this),
                this::handleRepositoryState
        );
        overlay = new OverlayController(this, new OverlayController.ActionListener() {
            @Override public void onMarkLong() {
                repository.markPosition(PositionSide.LONG, System.currentTimeMillis());
            }

            @Override public void onMarkShort() {
                repository.markPosition(PositionSide.SHORT, System.currentTimeMillis());
            }

            @Override public void onMarkExited() {
                repository.closePosition(System.currentTimeMillis());
            }
        });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopCaptureAndSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_RESET_ALERTS.equals(action)) {
            repository.resetAlerts(System.currentTimeMillis());
            if (!activeCapture) stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (ACTION_REQUEST_STATUS.equals(action)) {
            repository.publishCurrentState(System.currentTimeMillis());
            if (!activeCapture) stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
            Intent projectionData = projectionData(intent);
            if (resultCode != Activity.RESULT_OK || projectionData == null) {
                broadcastSimple("監看：螢幕讀取授權失敗", "週期：日K —　5分K —　1分K —", "判斷：未啟動", "沒有可用的螢幕授權");
                stopSelf(startId);
                return START_NOT_STICKY;
            }
            startCapture(resultCode, projectionData);
        }
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }

    @Override public void onDestroy() {
        releaseCapture();
        if (ocrEngine != null) ocrEngine.close();
        if (workerThread != null) workerThread.quitSafely();
        if (overlay != null) overlay.hide();
        super.onDestroy();
    }

    private void startCapture(int resultCode, Intent projectionData) {
        if (activeCapture) {
            repository.publishCurrentState(System.currentTimeMillis());
            return;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                    SignalNotifier.FOREGROUND_NOTIFICATION_ID,
                    notifier.foregroundNotification("等待元大 K 線畫面"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            );
        } else {
            startForeground(
                    SignalNotifier.FOREGROUND_NOTIFICATION_ID,
                    notifier.foregroundNotification("等待元大 K 線畫面")
            );
        }

        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(resultCode, projectionData);
        if (projection == null) {
            broadcastSimple("監看：無法建立螢幕讀取", "週期：日K —　5分K —　1分K —", "判斷：未啟動", "系統未提供螢幕畫面");
            stopCaptureAndSelf();
            return;
        }

        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        int density = metrics.densityDpi;

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                mainHandler.post(() -> {
                    broadcastSimple(
                            "監看：螢幕讀取已被系統停止",
                            lastState == null ? "週期：日K —　5分K —　1分K —" : lastState.timeframeStatus(),
                            lastState == null ? "判斷：已停止" : lastState.signalStatus(),
                            "若同時使用手機錄影，兩者可能互相搶佔螢幕擷取功能。"
                    );
                    stopCaptureAndSelf();
                });
            }
        }, workerHandler);

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(this::onImageAvailable, workerHandler);
        virtualDisplay = projection.createVirtualDisplay(
                "MumuIntradayScreen",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                workerHandler
        );
        activeCapture = true;
        overlay.show();
        repository.publishCurrentState(System.currentTimeMillis());
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            // The expanded card can cover chart legends. Keep it fully
            // interactive and pause OCR until the user collapses it again.
            if (overlay != null && overlay.isExpanded()) return;
            long now = System.currentTimeMillis();
            if (now - lastAnalyzeAt < ANALYZE_INTERVAL_MS || !processing.compareAndSet(false, true)) return;
            lastAnalyzeAt = now;
            Bitmap bitmap = toBitmap(image);
            image.close();
            image = null;
            ocrEngine.recognize(bitmap, new SafeScreenOcrEngine.Callback() {
                @Override public void onSuccess(
                        java.util.List<com.mumu.intraday.app.ocr.OcrToken> tokens,
                        boolean kLinePage,
                        com.mumu.intraday.app.ocr.ScreenVisualHints hints
                ) {
                    try {
                        long capturedAt = System.currentTimeMillis();
                        ParsedFrame parsed = parser.parse(tokens, kLinePage, hints, capturedAt);
                        if (parsed.snapshot() != null) {
                            MarketSnapshot stable = stabilizer.accept(parsed.snapshot());
                            parsed = new ParsedFrame(
                                    parsed.headerQuote(),
                                    parsed.kLinePage(),
                                    stable,
                                    parsed.diagnostic()
                            );
                        } else {
                            stabilizer.reset();
                        }
                        repository.accept(parsed, capturedAt);
                    } finally {
                        processing.set(false);
                    }
                }

                @Override public void onFailure(Exception error) {
                    processing.set(false);
                    ParsedFrame failure = new ParsedFrame(
                            null,
                            false,
                            null,
                            "辨識暫停：" + (error == null ? "未知錯誤" : error.getClass().getSimpleName())
                    );
                    repository.accept(failure, System.currentTimeMillis());
                }
            });
        } catch (Exception error) {
            processing.set(false);
        } finally {
            if (image != null) image.close();
        }
    }

    private Bitmap toBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int width = image.getWidth();
        int height = image.getHeight();
        int rowPadding = rowStride - pixelStride * width;
        int paddedWidth = width + rowPadding / pixelStride;
        Bitmap padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, width, height);
        padded.recycle();
        return cropped;
    }

    private void handleRepositoryState(
            RepositoryState state,
            Optional<AlertGate.AlertEvent> alertEvent,
            Optional<PositionAlertGate.PositionAlertEvent> positionAlertEvent
    ) {
        mainHandler.post(() -> {
            lastState = state;
            if (activeCapture) {
                overlay.update(state);
                notifier.updateForeground(state);
                alertEvent.ifPresent(notifier::notifySignal);
                positionAlertEvent.ifPresent(notifier::notifyPosition);
            }
            broadcast(state);
        });
    }

    private void broadcast(RepositoryState state) {
        Intent status = new Intent(ACTION_STATUS)
                .setPackage(getPackageName())
                .putExtra(EXTRA_MONITOR_STATUS, state.monitorStatus())
                .putExtra(EXTRA_TIMEFRAME_STATUS, state.timeframeStatus())
                .putExtra(EXTRA_SIGNAL_STATUS, state.signalStatus())
                .putExtra(EXTRA_LATEST_LOG, state.latestLog());
        sendBroadcast(status);
    }

    private void broadcastSimple(String monitor, String timeframes, String signal, String log) {
        Intent status = new Intent(ACTION_STATUS)
                .setPackage(getPackageName())
                .putExtra(EXTRA_MONITOR_STATUS, monitor)
                .putExtra(EXTRA_TIMEFRAME_STATUS, timeframes)
                .putExtra(EXTRA_SIGNAL_STATUS, signal)
                .putExtra(EXTRA_LATEST_LOG, log);
        sendBroadcast(status);
    }

    private Intent projectionData(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent.class);
        }
        @SuppressWarnings("deprecation")
        Intent value = intent.getParcelableExtra(EXTRA_PROJECTION_DATA);
        return value;
    }

    private void stopCaptureAndSelf() {
        releaseCapture();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void releaseCapture() {
        if (releasingCapture) return;
        releasingCapture = true;
        activeCapture = false;
        processing.set(false);
        if (imageReader != null) {
            imageReader.setOnImageAvailableListener(null, null);
            imageReader.close();
            imageReader = null;
        }
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        MediaProjection projectionToStop = projection;
        projection = null;
        if (projectionToStop != null) {
            try {
                projectionToStop.stop();
            } catch (Exception ignored) {
            }
        }
        if (overlay != null) overlay.hide();
        releasingCapture = false;
    }
}
