package com.mumu.intraday.app.ocr;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import com.mumu.intraday.core.Timeframe;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * OCR is deliberately limited to known non-account regions. The first pass only
 * reads only the stock header and K-line navigation/timeframe selector. This
 * safe header remains readable on the order page so an existing setup can
 * watch its live trigger; chart legends are exposed only after K-line confirmation.
 */
public final class SafeScreenOcrEngine implements AutoCloseable {
    public interface Callback {
        void onSuccess(List<OcrToken> tokens, boolean kLinePage, ScreenVisualHints hints);
        void onFailure(Exception error);
    }

    private final TextRecognizer recognizer = TextRecognition.getClient(
            new ChineseTextRecognizerOptions.Builder().build()
    );

    public void recognize(Bitmap source, Callback callback) {
        if (source == null || source.isRecycled()) {
            callback.onFailure(new IllegalArgumentException("empty screenshot"));
            return;
        }
        ScreenVisualHints visualHints = visualHints(source);
        Bitmap headerMask = maskedCopy(source, false);
        recognizer.process(InputImage.fromBitmap(headerMask, 0))
                .addOnSuccessListener(result -> {
                    List<OcrToken> headerTokens = flatten(result);
                    boolean kLinePage = visualHints.kLineTabSelected()
                            && (visualHints.selectedTimeframe() != Timeframe.OTHER
                                || looksLikeKLine(headerTokens));
                    headerMask.recycle();
                    if (!kLinePage) {
                        source.recycle();
                        callback.onSuccess(headerTokens, false, visualHints);
                        return;
                    }
                    Bitmap kLineMask = maskedCopy(source, true);
                    source.recycle();
                    recognizer.process(InputImage.fromBitmap(kLineMask, 0))
                            .addOnSuccessListener(kResult -> {
                                List<OcrToken> tokens = flatten(kResult);
                                kLineMask.recycle();
                                callback.onSuccess(tokens, true, visualHints);
                            })
                            .addOnFailureListener(error -> {
                                kLineMask.recycle();
                                callback.onFailure(error);
                            });
                })
                .addOnFailureListener(error -> {
                    headerMask.recycle();
                    source.recycle();
                    callback.onFailure(error);
                });
    }

    private Bitmap maskedCopy(Bitmap source, boolean includeChartLegends) {
        int width = source.getWidth();
        int height = source.getHeight();
        Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        canvas.drawColor(Color.BLACK);
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);

        // Primary navigation plus the full timeframe selector.  Yuanta places
        // these lower than the stock header (roughly 16.5%–26.7% of the screen).
        copyRegion(source, canvas, paint, rect(width, height, 0.00, 0.165, 0.97, 0.267));

        // Stock name/code/current price only. The same non-account header can
        // remain visible after entering Yuanta's order page, allowing the
        // already calculated trigger to continue without scanning order data.
        copyRegion(source, canvas, paint, rect(width, height, 0.08, 0.080, 0.93, 0.180));

        if (includeChartLegends) {
            // OHLC and MA/Bollinger text bands.
            copyRegion(source, canvas, paint, rect(width, height, 0.00, 0.258, 1.00, 0.378));
            // Middle panel legend only: MACD or volume. Chart body remains masked.
            copyRegion(source, canvas, paint, rect(width, height, 0.00, 0.600, 1.00, 0.652));
            // Bottom KD legend only.
            copyRegion(source, canvas, paint, rect(width, height, 0.00, 0.742, 0.96, 0.790));
        }
        return output;
    }

    private void copyRegion(Bitmap source, Canvas canvas, Paint paint, Rect region) {
        canvas.drawBitmap(source, region, region, paint);
    }

    private Rect rect(int width, int height, double left, double top, double right, double bottom) {
        return new Rect(
                (int) Math.round(width * left),
                (int) Math.round(height * top),
                (int) Math.round(width * right),
                (int) Math.round(height * bottom)
        );
    }

    private List<OcrToken> flatten(Text result) {
        List<OcrToken> tokens = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                // Keep ML Kit's reconstructed full line as well as individual
                // elements. Colored Yuanta legends are often split into a
                // label element and a value element; the line preserves their
                // reading order while elements retain precise header bounds.
                Rect lineBounds = line.getBoundingBox();
                if (lineBounds != null && !line.getText().isBlank()) {
                    tokens.add(new OcrToken(line.getText(), lineBounds, 1.0f, true));
                }
                for (Text.Element element : line.getElements()) {
                    Rect bounds = element.getBoundingBox();
                    if (bounds != null && !element.getText().isBlank()) {
                        tokens.add(new OcrToken(element.getText(), bounds, 1.0f));
                    }
                }
            }
        }
        tokens.sort(Comparator
                .comparingInt((OcrToken token) -> token.bounds().top)
                .thenComparingInt(token -> token.bounds().left));
        return tokens;
    }

    private boolean looksLikeKLine(List<OcrToken> tokens) {
        StringBuilder joined = new StringBuilder();
        for (OcrToken token : tokens) joined.append(token.text()).append(' ');
        String value = joined.toString().toUpperCase(Locale.ROOT).replace(" ", "");
        boolean hasKLine = value.contains("K線") || value.contains("K线");
        boolean hasPeriod = value.contains("1分") || value.contains("5分")
                || value.contains("15分") || value.contains("日週月")
                || value.contains("日周月");
        return hasKLine && hasPeriod;
    }

    private ScreenVisualHints visualHints(Bitmap source) {
        int width = source.getWidth();
        int height = source.getHeight();
        int kLineTab = selectedColorCount(
                source,
                rect(width, height, 0.42, 0.165, 0.64, 0.223)
        );
        // Start below the cyan underline of the primary "K線" tab; otherwise
        // that underline can be mistaken for a selected 5-minute period.
        int daily = selectedColorCount(source, rect(width, height, 0.00, 0.223, 0.095, 0.267));
        int one = selectedColorCount(source, rect(width, height, 0.355, 0.223, 0.458, 0.267));
        int five = selectedColorCount(source, rect(width, height, 0.455, 0.223, 0.555, 0.267));
        int max = Math.max(daily, Math.max(one, five));
        int second = daily + one + five - max - Math.min(daily, Math.min(one, five));
        Timeframe timeframe = Timeframe.OTHER;
        if (max >= 18) {
            if (max == daily) timeframe = Timeframe.DAILY;
            else if (max == one) timeframe = Timeframe.MIN_1;
            else timeframe = Timeframe.MIN_5;
        }
        double confidence = max <= 0 ? 0.0 : Math.min(1.0, (max - second) / (double) Math.max(20, max));
        return new ScreenVisualHints(width, height, kLineTab >= 20, timeframe, confidence);
    }

    private int selectedColorCount(Bitmap source, Rect region) {
        int count = 0;
        float[] hsv = new float[3];
        for (int y = region.top; y < region.bottom; y += 3) {
            for (int x = region.left; x < region.right; x += 3) {
                Color.colorToHSV(source.getPixel(x, y), hsv);
                boolean blueOrCyan = hsv[0] >= 175f && hsv[0] <= 225f;
                if (blueOrCyan && hsv[1] >= 0.42f && hsv[2] >= 0.55f) count++;
            }
        }
        return count;
    }

    @Override public void close() {
        recognizer.close();
    }
}
