package com.mumu.intraday.app;

import android.annotation.SuppressLint;
import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.mumu.intraday.app.capture.ScreenCaptureService;

public final class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 4101;
    private static final int REQUEST_OVERLAY = 4102;
    private static final int REQUEST_NOTIFICATIONS = 4103;

    private TextView permissionStatus;
    private TextView monitorStatus;
    private TextView timeframeStatus;
    private TextView signalStatus;
    private TextView latestLog;
    private boolean pendingStart;
    private boolean notificationPermissionHandled;
    private boolean captureConsentLaunched;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ScreenCaptureService.ACTION_STATUS.equals(intent.getAction())) return;
            String monitor = intent.getStringExtra(ScreenCaptureService.EXTRA_MONITOR_STATUS);
            String timeframes = intent.getStringExtra(ScreenCaptureService.EXTRA_TIMEFRAME_STATUS);
            String signal = intent.getStringExtra(ScreenCaptureService.EXTRA_SIGNAL_STATUS);
            String log = intent.getStringExtra(ScreenCaptureService.EXTRA_LATEST_LOG);
            if (monitor != null) monitorStatus.setText(monitor);
            if (timeframes != null) timeframeStatus.setText(timeframes);
            if (signal != null) signalStatus.setText(signal);
            if (log != null) latestLog.setText(log);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildContent());
        updatePermissionStatus();
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(ScreenCaptureService.ACTION_STATUS);
        ContextCompat.registerReceiver(
                this,
                statusReceiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
        );
        sendServiceAction(ScreenCaptureService.ACTION_REQUEST_STATUS);
    }

    @Override protected void onStop() {
        try {
            unregisterReceiver(statusReceiver);
        } catch (IllegalArgumentException ignored) {
        }
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        updatePermissionStatus();
        if (pendingStart && Settings.canDrawOverlays(this)) continueStartFlow();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) continueStartFlow();
            else {
                pendingStart = false;
                monitorStatus.setText("尚未取得浮窗權限");
            }
            return;
        }
        if (requestCode == REQUEST_CAPTURE) {
            pendingStart = false;
            captureConsentLaunched = false;
            if (resultCode != RESULT_OK || data == null) {
                monitorStatus.setText("螢幕讀取授權已取消");
                return;
            }
            Intent service = new Intent(this, ScreenCaptureService.class)
                    .setAction(ScreenCaptureService.ACTION_START)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    .putExtra(ScreenCaptureService.EXTRA_PROJECTION_DATA, data);
            startForegroundService(service);
            monitorStatus.setText("啟動中，請切到元大 K 線畫面");
        }
    }

    @Override public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NOTIFICATIONS) {
            notificationPermissionHandled = true;
            continueStartFlow();
        }
    }

    private View buildContent() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(color("#07111F"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        TextView title = text("盤中判斷助手", 30, Color.WHITE, true);
        root.addView(title);
        TextView subtitle = text(
                "不用輸入股票代號或成本。切到哪一檔，就自動讀取哪一檔；只提供偏多、偏空或先不動作，不會替妳下單。",
                16,
                color("#A9B5C5"),
                false
        );
        subtitle.setLineSpacing(0f, 1.28f);
        root.addView(subtitle, margins(0, 12, 0, 22));

        LinearLayout statusCard = card();
        permissionStatus = statusLine("權限：檢查中");
        monitorStatus = statusLine("監看：尚未啟動");
        timeframeStatus = statusLine("週期：日K —　5分K —　1分K —");
        signalStatus = statusLine("判斷：等待盤面資料");
        statusCard.addView(permissionStatus);
        statusCard.addView(monitorStatus, margins(0, 8, 0, 0));
        statusCard.addView(timeframeStatus, margins(0, 8, 0, 0));
        statusCard.addView(signalStatus, margins(0, 8, 0, 0));
        root.addView(statusCard);

        Button start = button("開始自動讀取", "#60D4CB", "#07111F");
        start.setOnClickListener(v -> beginStartFlow());
        root.addView(start, margins(0, 18, 0, 0));

        Button stop = button("停止並關閉浮窗", "#223248", "#F3F6FA");
        stop.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_STOP));
        root.addView(stop, margins(0, 10, 0, 0));

        Button reset = button("重設今日訊號通知", "#223248", "#F3F6FA");
        reset.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_RESET_ALERTS));
        root.addView(reset, margins(0, 10, 0, 0));

        TextView section = text("判斷歷程與辨識紀錄", 18, Color.WHITE, true);
        root.addView(section, margins(0, 24, 0, 8));
        latestLog = text("尚無紀錄。只保存判斷狀態、時間與安全股票數值，不保存螢幕圖片或帳號欄位。", 14, color("#A9B5C5"), false);
        latestLog.setLineSpacing(0f, 1.25f);
        LinearLayout logCard = card();
        logCard.addView(latestLog);
        root.addView(logCard);

        TextView note = text(
                "判斷順序：日K看大方向 → 5分K看結構與多空分界 → 1分K建立偏多／偏空計畫。未到價時只用棕色顯示等待回踩／反彈；真的進入觸發區才變紅／綠並提醒一次。自行成交後可在浮窗標記已做多或已做空。",
                13,
                color("#7F8EA2"),
                false
        );
        note.setLineSpacing(0f, 1.25f);
        root.addView(note, margins(0, 18, 0, 0));
        return scroll;
    }

    private void beginStartFlow() {
        pendingStart = true;
        notificationPermissionHandled = false;
        captureConsentLaunched = false;
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivityForResult(intent, REQUEST_OVERLAY);
            return;
        }
        continueStartFlow();
    }

    private void continueStartFlow() {
        if (!pendingStart || captureConsentLaunched) return;
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !notificationPermissionHandled) {
            notificationPermissionHandled = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        captureConsentLaunched = true;
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    private void sendServiceAction(String action) {
        Intent intent = new Intent(this, ScreenCaptureService.class).setAction(action);
        if (ScreenCaptureService.ACTION_REQUEST_STATUS.equals(action)) {
            try {
                startService(intent);
            } catch (IllegalStateException ignored) {
            }
        } else {
            startService(intent);
        }
    }

    @SuppressLint("SetTextI18n")
    private void updatePermissionStatus() {
        if (permissionStatus == null) return;
        boolean overlay = Settings.canDrawOverlays(this);
        boolean notifications = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        permissionStatus.setText("權限：浮窗" + (overlay ? "✓" : "—")
                + "　通知" + (notifications ? "✓" : "—")
                + "　螢幕讀取啟動時詢問");
    }

    private LinearLayout card() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setPadding(dp(16), dp(15), dp(16), dp(15));
        view.setBackground(roundRect("#111D2D", 14));
        return view;
    }

    private TextView statusLine(String value) {
        return text(value, 15, color("#E6ECF3"), false);
    }

    private TextView text(String value, int sp, int textColor, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(textColor);
        if (bold) view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        return view;
    }

    private Button button(String label, String background, String foreground) {
        Button view = new Button(this);
        view.setText(label);
        view.setTextSize(16);
        view.setTextColor(color(foreground));
        view.setAllCaps(false);
        view.setGravity(Gravity.CENTER);
        view.setBackground(roundRect(background, 12));
        view.setMinHeight(dp(54));
        return view;
    }

    private GradientDrawable roundRect(String hex, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color(hex));
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private LinearLayout.LayoutParams margins(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private int color(String value) {
        return Color.parseColor(value);
    }
}
