package com.mumu.intraday.app.overlay;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mumu.intraday.app.store.RepositoryState;
import com.mumu.intraday.core.OpenPosition;
import com.mumu.intraday.core.PositionAdvice;
import com.mumu.intraday.core.PositionSide;
import com.mumu.intraday.core.SignalDecision;
import com.mumu.intraday.core.SignalDirection;
import com.mumu.intraday.core.TaiwanPriceSteps;

import java.util.Locale;

public final class OverlayController {
    public interface ActionListener {
        void onMarkLong();
        void onMarkShort();
        void onMarkExited();
    }

    private static final String PREFS = "overlay_position";
    private final Context context;
    private final WindowManager windowManager;
    private final SharedPreferences preferences;
    private final ActionListener actionListener;
    private LinearLayout root;
    private TextView summary;
    private TextView details;
    private TextView tradeHint;
    private TextView longButton;
    private TextView shortButton;
    private TextView exitButton;
    private LinearLayout actionRow;
    private WindowManager.LayoutParams layoutParams;
    private boolean attached;
    private volatile boolean expanded;
    private RepositoryState lastState;

    public OverlayController(Context context, ActionListener actionListener) {
        this.context = context.getApplicationContext();
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        this.preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.actionListener = actionListener;
    }

    public void show() {
        if (attached) return;
        buildView();
        try {
            windowManager.addView(root, layoutParams);
            attached = true;
        } catch (Exception ignored) {
            attached = false;
        }
    }

    @SuppressLint("SetTextI18n")
    public void update(RepositoryState state) {
        lastState = state;
        if (!attached) show();
        if (!attached || state == null) return;

        SignalDecision decision = state.lastDecision();
        OpenPosition position = state.openPosition();
        PositionAdvice advice = state.positionAdvice();
        SignalDirection colorDirection = position == null
                ? decision != null && decision.shouldNotify()
                    ? decision.direction()
                    : SignalDirection.WAIT
                : position.side() == PositionSide.LONG ? SignalDirection.LONG : SignalDirection.SHORT;
        root.setBackground(roundRect(colorFor(colorDirection), 14));

        String stock = state.name().isBlank() ? state.symbol() : state.name() + " " + state.symbol();
        String price = state.displayedPrice() > 0.0 ? " · " + formatPrice(state.displayedPrice()) : "";
        String progress = compactProgress(state.timeframeStatus());
        String ageFlag = state.showingLastKLineDecision() ? "｜最後K" : "";
        double boundary = advice != null && advice.boundaryReference() > 0.0
                ? advice.boundaryReference()
                : decision != null ? decision.boundaryReference() : Double.NaN;

        String middle;
        if (position != null) {
            String action = advice == null ? "等待更新" : advice.action().label();
            String pnl = advice != null && Double.isFinite(advice.unrealizedPercent())
                    ? " " + formatPercent(advice.unrealizedPercent())
                    : "";
            middle = "持倉" + position.side().label() + "｜" + action + pnl + ageFlag;
        } else {
            String direction;
            if (decision == null) {
                direction = "收集中";
            } else if (decision.hasDirectionalSetup()) {
                direction = decision.shouldNotify()
                        ? "已到" + decision.direction().label() + "區 "
                            + formatPrice(decision.zoneLow()) + "–" + formatPrice(decision.zoneHigh())
                        : decision.direction().label() + "計畫｜" + waitingSummary(decision);
            } else {
                direction = decision.direction().label();
            }
            middle = progress + "｜" + direction + ageFlag;
        }
        String boundaryLine = boundary > 0.0 ? "\n多空界 " + formatPrice(boundary) : "";
        summary.setText((stock.isBlank() ? "等待元大畫面" : stock + price)
                + "\n" + middle + boundaryLine);

        if (position != null) {
            details.setText(positionDetails(state, position, advice));
        } else if (decision == null) {
            details.setText(state.timeframeStatus() + "\n" + state.monitorStatus()
                    + "\n不需輸入股票資料；請依序停留日K、5分K、1分K。"
                    + "\n最近：" + lastLogLine(state.latestLog())
                    + "\n浮窗展開時暫停辨識；點一下縮小後自動繼續。");
        } else {
            StringBuilder value = new StringBuilder();
            value.append(state.signalStatus()).append('\n').append(state.timeframeStatus());
            if (decision.boundaryReference() > 0.0) {
                value.append("\n多空分界：")
                        .append(formatPrice(decision.boundaryReference()))
                        .append("（5分K MA20，只作結構參考，不在此價通知）");
            }
            if (decision.hasDirectionalSetup()) {
                value.append("\n").append(decision.direction().label()).append("進場計畫")
                        .append("\n進場觸發區：")
                        .append(formatPrice(decision.zoneLow())).append("–")
                        .append(formatPrice(decision.zoneHigh()))
                        .append("（中心 ").append(formatPrice(decision.triggerReference())).append("）")
                        .append("\n停損／失效：")
                        .append(formatPrice(decision.invalidationReference()))
                        .append("　第一停利：")
                        .append(formatPrice(decision.targetOneReference()))
                        .append("　第二停利：")
                        .append(formatPrice(decision.targetTwoReference()));
            } else {
                value.append("\n進出計畫：尚未形成可執行的偏多／偏空方向，不提供假進場點。");
            }
            value.append(decision.shouldNotify() ? "\n到價操作：" : "\n目前狀態：")
                    .append(entryInstruction(decision));
            if (!decision.reasons().isEmpty()) {
                value.append("\n依據：").append(String.join("、", decision.reasons()));
            }
            if (!decision.blockers().isEmpty()) {
                value.append("\n等待：").append(String.join("、", decision.blockers()));
            }
            if (state.showingLastKLineDecision()) {
                value.append("\n已離開K線：安全股票標頭現價持續監看，結構沿用最後一次完整資料。");
            }
            value.append("\n成交後點下方『已做多／已做空』，助手才會切換成持倉管理。")
                    .append("\n下單由妳決定；助手不會點擊交易介面。");
            details.setText(value.toString());
        }

        updateActionControls(state);
        details.setVisibility(expanded ? View.VISIBLE : View.GONE);
        actionRow.setVisibility(expanded ? View.VISIBLE : View.GONE);
        tradeHint.setVisibility(expanded ? View.VISIBLE : View.GONE);
        if (attached) windowManager.updateViewLayout(root, layoutParams);
    }

    private String positionDetails(
            RepositoryState state,
            OpenPosition position,
            PositionAdvice advice
    ) {
        StringBuilder value = new StringBuilder();
        value.append(state.signalStatus()).append('\n').append(state.timeframeStatus());
        if (advice == null) {
            value.append("\n參考進場：").append(formatPrice(position.entryPrice()))
                    .append("　初始停損：").append(formatPrice(position.initialStopReference()))
                    .append("\n等待目前價格與K線更新。");
        } else {
            value.append("\n參考進場：").append(formatPrice(position.entryPrice()))
                    .append("　現價：").append(formatPrice(advice.currentPrice()))
                    .append("　損益：").append(formatPercent(advice.unrealizedPercent()))
                    .append("\n多空分界：").append(formatPrice(advice.boundaryReference()))
                    .append("（5分K MA20）")
                    .append("\n停損／保護：").append(formatPrice(advice.stopReference()))
                    .append("　第一停利：").append(formatPrice(advice.targetOneReference()))
                    .append("　第二停利：").append(formatPrice(advice.targetTwoReference()))
                    .append("\n持倉依據：").append(advice.reason());
        }
        if (state.showingLastKLineDecision()) {
            value.append("\n已離開K線：現價可依股票標頭更新，結構判斷沿用最後K線。");
        }
        value.append("\n實際出場後請點『已出場』；助手不會替妳送單。");
        return value.toString();
    }

    private String entryInstruction(SignalDecision decision) {
        if (decision == null || !decision.hasDirectionalSetup()) {
            return "目前沒有偏多／偏空觸發，先不動作。";
        }
        if (!decision.shouldNotify()) {
            double low = Math.min(decision.zoneLow(), decision.zoneHigh());
            double high = Math.max(decision.zoneLow(), decision.zoneHigh());
            String zone = formatPrice(low) + "–" + formatPrice(high);
            if (decision.direction() == SignalDirection.LONG && decision.currentPrice() > high) {
                return "偏多計畫已建立，但現價已高於觸發區；等待回踩 " + zone
                        + "，現在不追價，也不跳紅色到價提醒。";
            }
            if (decision.direction() == SignalDirection.SHORT && decision.currentPrice() < low) {
                return "偏空計畫已建立，但現價已低於觸發區；等待反彈 " + zone
                        + "，現在不追空，也不跳綠色到價提醒。";
            }
            return "計畫已建立；等待現價第一次進入" + decision.direction().label()
                    + "觸發區 " + zone + "，此時不發到價通知。";
        }
        if (decision.direction() == SignalDirection.LONG) {
            return "已到偏多價；確認1分K回踩觸發區不破後，可考慮做多，跌破 "
                    + formatPrice(decision.invalidationReference()) + " 視為失效；第一停利 "
                    + formatPrice(decision.targetOneReference()) + "，第二停利 "
                    + formatPrice(decision.targetTwoReference()) + "。";
        }
        return "已到偏空價；確認1分K反彈觸發區不過後，可考慮做空，突破 "
                + formatPrice(decision.invalidationReference()) + " 視為失效；第一停利 "
                + formatPrice(decision.targetOneReference()) + "，第二停利 "
                + formatPrice(decision.targetTwoReference()) + "。";
    }

    private String waitingSummary(SignalDecision decision) {
        double current = decision.currentPrice();
        double low = Math.min(decision.zoneLow(), decision.zoneHigh());
        double high = Math.max(decision.zoneLow(), decision.zoneHigh());
        String zone = formatPrice(low) + "–" + formatPrice(high);
        if (decision.direction() == SignalDirection.LONG) {
            if (current > high) return "等回踩 " + zone;
            if (current < low) return "等站回 " + zone;
        } else {
            if (current < low) return "等反彈 " + zone;
            if (current > high) return "等跌回 " + zone;
        }
        return "等進入 " + zone;
    }

    private void updateActionControls(RepositoryState state) {
        boolean hasPosition = state != null && state.hasOpenPosition();
        boolean canMark = state != null && state.lastDecision() != null && state.displayedPrice() > 0.0;
        longButton.setVisibility(!hasPosition && canMark ? View.VISIBLE : View.GONE);
        shortButton.setVisibility(!hasPosition && canMark ? View.VISIBLE : View.GONE);
        exitButton.setVisibility(hasPosition ? View.VISIBLE : View.GONE);
        if (hasPosition) {
            tradeHint.setText("實際成交出場後，再點『已出場』結束持倉監控。");
        } else if (canMark) {
            tradeHint.setText("妳自行成交後，再點已做多或已做空；點擊不會送出訂單。");
        } else {
            tradeHint.setText("三週期完成後，才會出現持倉標記按鈕。");
        }
    }

    public void hide() {
        if (!attached) return;
        try {
            windowManager.removeView(root);
        } catch (Exception ignored) {
        }
        attached = false;
    }

    public boolean isExpanded() {
        return expanded;
    }

    @SuppressLint({"ClickableViewAccessibility", "SetTextI18n"})
    private void buildView() {
        root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(9), dp(12), dp(9));
        root.setBackground(roundRect(colorFor(SignalDirection.WAIT), 14));
        root.setElevation(dp(9));

        summary = new TextView(context);
        summary.setTextColor(Color.WHITE);
        summary.setTextSize(13);
        summary.setTypeface(summary.getTypeface(), android.graphics.Typeface.BOLD);
        summary.setMaxLines(3);
        summary.setMinWidth(dp(230));
        summary.setMaxWidth(dp(275));
        root.addView(summary);

        details = new TextView(context);
        details.setTextColor(Color.WHITE);
        details.setTextSize(12);
        details.setLineSpacing(0f, 1.18f);
        details.setPadding(0, dp(7), 0, 0);
        details.setMaxWidth(dp(275));
        details.setVisibility(View.GONE);
        root.addView(details);

        actionRow = new LinearLayout(context);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setGravity(Gravity.CENTER);
        actionRow.setPadding(0, dp(9), 0, 0);
        actionRow.setVisibility(View.GONE);
        longButton = actionButton("已做多", "#F05A73");
        shortButton = actionButton("已做空", "#32B98A");
        exitButton = actionButton("已出場", "#D7DEE8");
        exitButton.setTextColor(Color.parseColor("#152233"));
        actionRow.addView(longButton, weightedMargins(0, 0, 4, 0));
        actionRow.addView(shortButton, weightedMargins(4, 0, 0, 0));
        actionRow.addView(exitButton, weightedMargins(0, 0, 0, 0));
        root.addView(actionRow);

        tradeHint = new TextView(context);
        tradeHint.setTextColor(Color.argb(220, 255, 255, 255));
        tradeHint.setTextSize(10);
        tradeHint.setLineSpacing(0f, 1.1f);
        tradeHint.setPadding(0, dp(6), 0, 0);
        tradeHint.setMaxWidth(dp(275));
        tradeHint.setVisibility(View.GONE);
        root.addView(tradeHint);

        longButton.setOnClickListener(v -> {
            if (actionListener != null) actionListener.onMarkLong();
        });
        shortButton.setOnClickListener(v -> {
            if (actionListener != null) actionListener.onMarkShort();
        });
        exitButton.setOnClickListener(v -> {
            if (actionListener != null) actionListener.onMarkExited();
        });

        layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        int screenHeight = context.getResources().getDisplayMetrics().heightPixels;
        int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
        layoutParams.x = preferences.getInt("x", Math.max(dp(8), screenWidth - dp(300)));
        layoutParams.y = preferences.getInt("y", Math.round(screenHeight * 0.42f));
        root.setOnClickListener(view -> toggleExpanded());
        root.setOnTouchListener(new DragTouchListener());
    }

    private TextView actionButton(String label, String color) {
        TextView view = new TextView(context);
        view.setText(label);
        view.setTextColor(Color.WHITE);
        view.setTextSize(12);
        view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setMinHeight(dp(40));
        view.setPadding(dp(7), dp(6), dp(7), dp(6));
        view.setBackground(roundRect(Color.parseColor(color), 9));
        view.setClickable(true);
        return view;
    }

    private LinearLayout.LayoutParams weightedMargins(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(40), 1f);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private void toggleExpanded() {
        expanded = !expanded;
        details.setVisibility(expanded ? View.VISIBLE : View.GONE);
        actionRow.setVisibility(expanded ? View.VISIBLE : View.GONE);
        tradeHint.setVisibility(expanded ? View.VISIBLE : View.GONE);
        if (attached) windowManager.updateViewLayout(root, layoutParams);
        if (lastState != null) update(lastState);
    }

    private String compactProgress(String status) {
        String value = status == null ? "" : status;
        String daily = compactMark(value, "日K", "日");
        String five = compactMark(value, "5分K", "5");
        String one = compactMark(value, "1分K", "1");
        return daily + " " + five + " " + one;
    }

    private String compactMark(String status, String fullLabel, String shortLabel) {
        if (status.contains(fullLabel + " ✓")) return shortLabel + "✓";
        if (status.contains(fullLabel + " 確認中")) return shortLabel + "…";
        if (status.contains(fullLabel + " 待補") || status.contains(fullLabel + " 辨識弱")) {
            return shortLabel + "!";
        }
        return shortLabel + "—";
    }

    private String lastLogLine(String log) {
        if (log == null || log.isBlank()) return "尚無辨識結果";
        int newline = log.lastIndexOf('\n');
        return newline >= 0 ? log.substring(newline + 1) : log;
    }

    private int colorFor(SignalDirection direction) {
        if (direction == SignalDirection.LONG) return Color.parseColor("#C02F4A");
        if (direction == SignalDirection.SHORT) return Color.parseColor("#137A5B");
        return Color.parseColor("#8B6624");
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), Color.argb(110, 255, 255, 255));
        return drawable;
    }

    private String formatPrice(double value) {
        if (!Double.isFinite(value) || value <= 0.0) return "—";
        double tick = TaiwanPriceSteps.tickSize(value);
        int decimals = tick < 0.1 ? 2 : tick < 1.0 ? 1 : 0;
        return String.format(Locale.TAIWAN, "%." + decimals + "f", value);
    }

    private String formatPercent(double value) {
        return Double.isFinite(value)
                ? String.format(Locale.TAIWAN, "%+.2f%%", value)
                : "—";
    }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private final class DragTouchListener implements View.OnTouchListener {
        private int startX;
        private int startY;
        private float touchX;
        private float touchY;
        private boolean dragged;

        @Override public boolean onTouch(View view, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = layoutParams.x;
                    startY = layoutParams.y;
                    touchX = event.getRawX();
                    touchY = event.getRawY();
                    dragged = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = Math.round(event.getRawX() - touchX);
                    int dy = Math.round(event.getRawY() - touchY);
                    if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) dragged = true;
                    layoutParams.x = Math.max(0, startX + dx);
                    layoutParams.y = Math.max(0, startY + dy);
                    if (attached) windowManager.updateViewLayout(root, layoutParams);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (dragged) {
                        preferences.edit().putInt("x", layoutParams.x).putInt("y", layoutParams.y).apply();
                    } else {
                        view.performClick();
                    }
                    return true;
                default:
                    return false;
            }
        }
    }
}
