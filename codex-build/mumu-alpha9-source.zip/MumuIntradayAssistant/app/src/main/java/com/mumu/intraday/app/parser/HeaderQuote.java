package com.mumu.intraday.app.parser;

public final class HeaderQuote {
    private final String symbol;
    private final String name;
    private final double currentPrice;
    private final long capturedAtEpochMs;
    private final double confidence;

    public HeaderQuote(
            String symbol,
            String name,
            double currentPrice,
            long capturedAtEpochMs,
            double confidence
    ) {
        this.symbol = symbol == null ? "" : symbol.trim();
        this.name = name == null ? "" : name.trim();
        this.currentPrice = currentPrice;
        this.capturedAtEpochMs = capturedAtEpochMs;
        this.confidence = Math.max(0.0, Math.min(1.0, confidence));
    }

    public String symbol() { return symbol; }
    public String name() { return name; }
    public double currentPrice() { return currentPrice; }
    public long capturedAtEpochMs() { return capturedAtEpochMs; }
    public double confidence() { return confidence; }

    public boolean isUsable() {
        return !symbol.isBlank() && currentPrice > 0.0 && confidence >= 0.65;
    }
}
