package com.mumu.intraday.app.store;

import android.content.Context;
import android.content.SharedPreferences;

import com.mumu.intraday.core.OpenPosition;
import com.mumu.intraday.core.PriceScaleNormalizer;
import com.mumu.intraday.core.PositionSide;

public final class SharedPreferencesPositionStore {
    private static final String PREFS = "open_position_state";
    private final SharedPreferences preferences;

    public SharedPreferencesPositionStore(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public OpenPosition load() {
        String sideName = preferences.getString("side", "");
        double entry = number("entry");
        if (sideName == null || sideName.isBlank() || !(entry > 0.0)) return null;
        try {
            return new OpenPosition(
                    preferences.getString("symbol", ""),
                    preferences.getString("name", ""),
                    PositionSide.valueOf(sideName),
                    entry,
                    preferences.getLong("entry_at", 0L),
                    PriceScaleNormalizer.normalizePrice(number("initial_stop"), entry),
                    PriceScaleNormalizer.normalizePrice(number("entry_boundary"), entry),
                    PriceScaleNormalizer.normalizePrice(number("highest"), entry),
                    PriceScaleNormalizer.normalizePrice(number("lowest"), entry)
            );
        } catch (Exception ignored) {
            clear();
            return null;
        }
    }

    public void save(OpenPosition position) {
        if (position == null) {
            clear();
            return;
        }
        preferences.edit()
                .putString("symbol", position.symbol())
                .putString("name", position.name())
                .putString("side", position.side().name())
                .putLong("entry_bits", Double.doubleToRawLongBits(position.entryPrice()))
                .putLong("entry_at", position.entryAtEpochMs())
                .putLong("initial_stop_bits", Double.doubleToRawLongBits(position.initialStopReference()))
                .putLong("entry_boundary_bits", Double.doubleToRawLongBits(position.entryBoundaryReference()))
                .putLong("highest_bits", Double.doubleToRawLongBits(position.highestSeen()))
                .putLong("lowest_bits", Double.doubleToRawLongBits(position.lowestSeen()))
                .apply();
    }

    public void clear() {
        preferences.edit().clear().apply();
    }

    private double number(String key) {
        long bits = preferences.getLong(key + "_bits", Double.doubleToRawLongBits(Double.NaN));
        return Double.longBitsToDouble(bits);
    }
}
