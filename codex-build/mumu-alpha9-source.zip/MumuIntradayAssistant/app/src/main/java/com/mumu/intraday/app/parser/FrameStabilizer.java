package com.mumu.intraday.app.parser;

import com.mumu.intraday.core.MarketSnapshot;
import com.mumu.intraday.core.PriceScaleNormalizer;
import com.mumu.intraday.core.TaiwanPriceSteps;

/** Requires two similar completed frames before data can influence a decision. */
public final class FrameStabilizer {
    private MarketSnapshot candidate;
    private int matchingFrames;

    public MarketSnapshot accept(MarketSnapshot incoming) {
        incoming = PriceScaleNormalizer.normalize(incoming);
        if (incoming == null || incoming.recognitionConfidence() < 0.55) {
            reset();
            return incoming;
        }
        if (candidate != null && similar(candidate, incoming)) {
            matchingFrames += 1;
        } else {
            candidate = incoming;
            matchingFrames = 1;
        }
        if (matchingFrames >= 2) {
            candidate = incoming;
            return incoming.toBuilder().stableFrame(true).build();
        }
        return incoming.toBuilder().stableFrame(false).build();
    }

    public void reset() {
        candidate = null;
        matchingFrames = 0;
    }

    private boolean similar(MarketSnapshot a, MarketSnapshot b) {
        if (!a.symbol().equals(b.symbol())) return false;
        if (a.timeframe() != b.timeframe()) return false;
        if (a.middlePanel() != b.middlePanel()
                && a.middlePanel() != com.mumu.intraday.core.MiddlePanel.UNKNOWN
                && b.middlePanel() != com.mumu.intraday.core.MiddlePanel.UNKNOWN) return false;
        if (!a.sourceBarTime().isBlank() && !b.sourceBarTime().isBlank()
                && !a.sourceBarTime().equals(b.sourceBarTime())) return false;
        double tick = TaiwanPriceSteps.tickSize(b.effectiveClose());
        if (!close(a.effectiveClose(), b.effectiveClose(), tick * 3.1)) return false;

        int commonFields = 0;
        int[] comparisons = {
                compareIfPresent(a.open(), b.open(), tick * 3.1),
                compareIfPresent(a.high(), b.high(), tick * 3.1),
                compareIfPresent(a.low(), b.low(), tick * 3.1),
                compareIfPresent(a.ma5().value(), b.ma5().value(), tick * 2.1),
                compareIfPresent(a.ma10().value(), b.ma10().value(), tick * 2.1),
                compareIfPresent(a.ma20().value(), b.ma20().value(), tick * 2.1),
                compareIfPresent(a.k().value(), b.k().value(), 8.0),
                compareIfPresent(a.d().value(), b.d().value(), 8.0)
        };
        for (int comparison : comparisons) {
            if (comparison < 0) return false;
            commonFields += comparison;
        }
        return commonFields >= 2;
    }

    private int compareIfPresent(double a, double b, double tolerance) {
        if (!Double.isFinite(a) || !Double.isFinite(b)) return 0;
        return Math.abs(a - b) <= tolerance ? 1 : -1;
    }

    private boolean close(double a, double b, double tolerance) {
        if (!Double.isFinite(a) || !Double.isFinite(b)) return false;
        return Math.abs(a - b) <= tolerance;
    }
}
