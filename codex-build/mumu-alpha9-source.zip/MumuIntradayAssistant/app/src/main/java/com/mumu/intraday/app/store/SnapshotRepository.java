package com.mumu.intraday.app.store;

import com.mumu.intraday.app.parser.HeaderQuote;
import com.mumu.intraday.app.parser.ParsedFrame;
import com.mumu.intraday.core.AlertGate;
import com.mumu.intraday.core.EntryPlanTracker;
import com.mumu.intraday.core.MarketSnapshot;
import com.mumu.intraday.core.MultiTimeframeEngine;
import com.mumu.intraday.core.OpenPosition;
import com.mumu.intraday.core.PositionAction;
import com.mumu.intraday.core.PositionAdvice;
import com.mumu.intraday.core.PositionAlertGate;
import com.mumu.intraday.core.PositionManager;
import com.mumu.intraday.core.PositionSide;
import com.mumu.intraday.core.SignalDecision;
import com.mumu.intraday.core.SignalDirection;
import com.mumu.intraday.core.SnapshotMerger;
import com.mumu.intraday.core.TaiwanPriceSteps;
import com.mumu.intraday.core.Timeframe;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;

public final class SnapshotRepository {
    public interface Listener {
        void onState(
                RepositoryState state,
                Optional<AlertGate.AlertEvent> signalAlert,
                Optional<PositionAlertGate.PositionAlertEvent> positionAlert
        );
    }

    private static final int MAX_LOG_LINES = 20;
    private final Map<Timeframe, MarketSnapshot> snapshots = new EnumMap<>(Timeframe.class);
    private final Map<Timeframe, MarketSnapshot> lastAttempts = new EnumMap<>(Timeframe.class);
    private final ArrayDeque<String> logLines = new ArrayDeque<>();
    private final MultiTimeframeEngine engine;
    private final AlertGate alertGate;
    private final PositionManager positionManager;
    private final PositionAlertGate positionAlertGate;
    private final SharedPreferencesPositionStore positionStore;
    private final SharedPreferencesSnapshotStore snapshotStore;
    private final SharedPreferencesDecisionHistoryStore historyStore;
    private final EntryPlanTracker entryPlanTracker = new EntryPlanTracker();
    private final Listener listener;
    private String activeSymbol = "";
    private String activeName = "";
    private double latestPrice = Double.NaN;
    private SignalDecision lastDecision;
    private SignalDecision latestRawDecision;
    private long lastDecisionAt;
    private boolean currentlyOnKLine;
    private OpenPosition openPosition;
    private PositionAdvice positionAdvice;
    private PositionAction lastLoggedPositionAction;
    private String lastLoggedDecisionSignature = "";
    private String lastRetainedPlanKey = "";

    public SnapshotRepository(
            MultiTimeframeEngine engine,
            AlertGate alertGate,
            PositionManager positionManager,
            PositionAlertGate positionAlertGate,
            SharedPreferencesPositionStore positionStore,
            SharedPreferencesSnapshotStore snapshotStore,
            SharedPreferencesDecisionHistoryStore historyStore,
            Listener listener
    ) {
        this.engine = engine;
        this.alertGate = alertGate;
        this.positionManager = positionManager;
        this.positionAlertGate = positionAlertGate;
        this.positionStore = positionStore;
        this.snapshotStore = snapshotStore;
        this.historyStore = historyStore;
        this.listener = listener;
        openPosition = positionStore.load();
        restoreSnapshots(System.currentTimeMillis());
        if (openPosition != null) {
            activeSymbol = openPosition.symbol();
            activeName = openPosition.name();
            if (!(latestPrice > 0.0)) latestPrice = openPosition.entryPrice();
            addLog("已恢復 " + activeName + " " + activeSymbol + " " + openPosition.side().label() + " 持倉監控");
        }
    }

    public synchronized void accept(ParsedFrame frame, long nowEpochMs) {
        if (frame == null) return;
        currentlyOnKLine = frame.kLinePage();
        Optional<AlertGate.AlertEvent> signalAlert = Optional.empty();
        EntryPlanTracker.Update planUpdate = null;

        HeaderQuote quote = frame.headerQuote();
        if (quote != null && quote.isUsable()
                && (activeSymbol.isBlank() || activeSymbol.equals(quote.symbol()))) {
            if (activeSymbol.isBlank()) {
                activeSymbol = quote.symbol();
                activeName = quote.name();
            }
            if (activeSymbol.equals(quote.symbol())) latestPrice = quote.currentPrice();
        }

        MarketSnapshot incoming = frame.snapshot();
        if (incoming != null) {
            if (incoming.timeframe() != Timeframe.OTHER) {
                lastAttempts.put(incoming.timeframe(), incoming);
            }
            addLog(time(nowEpochMs) + " " + frame.diagnostic());
            if (incoming.stableFrame()) {
                if (incoming.recognitionNotes().stream()
                        .anyMatch(note -> note.contains("價格小數點尺度"))) {
                    addLog(time(nowEpochMs) + " OCR價格小數點已依現價自動校正");
                }
                boolean differentSymbol = !activeSymbol.isBlank()
                        && !activeSymbol.equals(incoming.symbol());
                if (differentSymbol && openPosition != null
                        && !openPosition.symbol().equals(incoming.symbol())) {
                    addLog(time(nowEpochMs) + " 持倉 " + openPosition.symbol()
                            + " 尚未標記出場，暫不切換至 " + incoming.symbol());
                } else {
                    if (activeSymbol.isBlank() || differentSymbol) switchSymbol(incoming);
                    if (activeSymbol.equals(incoming.symbol())) {
                        activeName = incoming.name().isBlank() ? activeName : incoming.name();
                        boolean headerMatches = quote != null && quote.isUsable()
                                && incoming.symbol().equals(quote.symbol());
                        latestPrice = headerMatches ? quote.currentPrice() : incoming.effectiveClose();
                        MarketSnapshot merged = SnapshotMerger.merge(
                                snapshots.get(incoming.timeframe()),
                                incoming
                        );
                        snapshots.put(incoming.timeframe(), merged);
                        snapshotStore.save(merged);
                        lastAttempts.remove(incoming.timeframe());
                        SignalDecision evaluated = evaluateIfReady(nowEpochMs);
                        if (evaluated != null) {
                            latestRawDecision = evaluated;
                            lastDecisionAt = nowEpochMs;
                            if (openPosition == null) {
                                planUpdate = entryPlanTracker.onEvaluation(
                                        evaluated,
                                        latestPrice,
                                        nowEpochMs
                                );
                            }
                        }
                    }
                }
            } else {
                String missing = incoming.missingRequiredFields().isEmpty()
                        ? ""
                        : "｜缺 " + String.join("、", incoming.missingRequiredFields());
                addLog(time(nowEpochMs) + " " + incoming.timeframe().label()
                        + " 確認中｜辨識 "
                        + Math.round(incoming.recognitionConfidence() * 100.0) + "%" + missing);
            }
        } else if (!frame.diagnostic().isBlank()) {
            addLog(time(nowEpochMs) + " " + frame.diagnostic());
        }

        // A complete setup comes from the three K-line views. Once armed, the
        // original zone is retained for five minutes and its live quote keeps
        // updating on the order page. A one-minute WAIT cannot erase it while
        // the day/five-minute structure remains valid.
        if (openPosition == null) {
            if (planUpdate == null) {
                planUpdate = entryPlanTracker.onPrice(latestPrice, nowEpochMs);
            }
            applyPlanUpdate(planUpdate, nowEpochMs);
        }

        if (openPosition == null && lastDecision != null && latestPrice > 0.0) {
            signalAlert = alertGate.evaluate(
                    lastDecision,
                    tradingDate(nowEpochMs),
                    nowEpochMs
            );
            if (signalAlert.isPresent()) {
                SignalDecision alerted = signalAlert.get().decision();
                addHistory(time(nowEpochMs) + " " + stockLabel(alerted)
                        + "｜已送一次" + alerted.direction().label() + "到價提醒"
                        + "｜現價 " + price(alerted.currentPrice())
                        + "｜觸發區 " + price(alerted.zoneLow()) + "–" + price(alerted.zoneHigh()));
            }
        }

        Optional<PositionAlertGate.PositionAlertEvent> positionAlert = refreshPosition(nowEpochMs);
        listener.onState(buildState(nowEpochMs), signalAlert, positionAlert);
    }

    public synchronized void publishCurrentState(long nowEpochMs) {
        refreshPosition(nowEpochMs);
        listener.onState(buildState(nowEpochMs), Optional.empty(), Optional.empty());
    }

    public synchronized void resetAlerts(long nowEpochMs) {
        alertGate.resetAll();
        positionAlertGate.resetAll();
        addLog(time(nowEpochMs) + " 已重設今日訊號與持倉通知");
        addHistory(time(nowEpochMs) + " 已重設今日一次性通知；現有進場計畫仍保留");
        listener.onState(buildState(nowEpochMs), Optional.empty(), Optional.empty());
    }

    public synchronized void markPosition(PositionSide side, long nowEpochMs) {
        if (openPosition != null) {
            addLog(time(nowEpochMs) + " 已在監控持倉，請先點已出場");
        } else if (side == null || activeSymbol.isBlank() || !(latestPrice > 0.0)) {
            addLog(time(nowEpochMs) + " 尚未取得股票與現價，無法標記持倉");
        } else if (lastDecision == null
                || snapshots.get(Timeframe.MIN_5) == null
                || snapshots.get(Timeframe.MIN_1) == null) {
            addLog(time(nowEpochMs) + " 請先完成日K、5分K、1分K辨識再標記持倉");
        } else {
            openPosition = positionManager.open(
                    side,
                    activeSymbol,
                    activeName,
                    latestPrice,
                    nowEpochMs,
                    lastDecision,
                    snapshots.get(Timeframe.MIN_5),
                    snapshots.get(Timeframe.MIN_1)
            );
            entryPlanTracker.clear();
            positionStore.save(openPosition);
            positionAlertGate.clearPending();
            lastLoggedPositionAction = null;
            addLog(time(nowEpochMs) + " 已標記" + side.label()
                    + "｜參考進場 " + openPosition.entryPrice()
                    + "｜初始停損 " + openPosition.initialStopReference());
            addHistory(time(nowEpochMs) + " " + activeName + " " + activeSymbol
                    + "｜已標記" + side.label()
                    + "｜參考進場 " + price(openPosition.entryPrice())
                    + "｜失效／初始停損 " + price(openPosition.initialStopReference()));
            refreshPosition(nowEpochMs);
        }
        listener.onState(buildState(nowEpochMs), Optional.empty(), Optional.empty());
    }

    public synchronized void closePosition(long nowEpochMs) {
        if (openPosition == null) {
            addLog(time(nowEpochMs) + " 目前沒有已標記持倉");
        } else {
            String result = positionAdvice != null && Double.isFinite(positionAdvice.unrealizedPercent())
                    ? String.format(Locale.TAIWAN, "%+.2f%%", positionAdvice.unrealizedPercent())
                    : "—";
            addLog(time(nowEpochMs) + " 已標記出場｜" + openPosition.side().label()
                    + "｜參考結果 " + result);
            addHistory(time(nowEpochMs) + " " + openPosition.name() + " " + openPosition.symbol()
                    + "｜已標記出場｜參考結果 " + result);
            openPosition = null;
            positionAdvice = null;
            lastLoggedPositionAction = null;
            positionStore.clear();
            positionAlertGate.clearPending();
        }
        listener.onState(buildState(nowEpochMs), Optional.empty(), Optional.empty());
    }

    private Optional<PositionAlertGate.PositionAlertEvent> refreshPosition(long nowEpochMs) {
        if (openPosition == null) {
            positionAdvice = null;
            positionAlertGate.clearPending();
            return Optional.empty();
        }
        OpenPosition observed = openPosition.withObservedPrice(latestPrice);
        if (observed != openPosition) {
            openPosition = observed;
            positionStore.save(openPosition);
        }
        positionAdvice = positionManager.evaluate(
                openPosition,
                latestPrice,
                latestRawDecision != null ? latestRawDecision : lastDecision,
                snapshots.get(Timeframe.MIN_5),
                snapshots.get(Timeframe.MIN_1)
        );
        if (positionAdvice != null && positionAdvice.action() != lastLoggedPositionAction) {
            addLog(time(nowEpochMs) + " 持倉：" + positionAdvice.action().label()
                    + "｜" + positionAdvice.reason());
            lastLoggedPositionAction = positionAdvice.action();
        }
        return positionAlertGate.evaluate(positionAdvice, nowEpochMs);
    }

    private void switchSymbol(MarketSnapshot incoming) {
        snapshots.clear();
        lastAttempts.clear();
        snapshotStore.clear();
        activeSymbol = incoming.symbol();
        activeName = incoming.name();
        latestPrice = incoming.effectiveClose();
        lastDecision = null;
        latestRawDecision = null;
        lastDecisionAt = 0L;
        entryPlanTracker.clear();
        lastLoggedDecisionSignature = "";
        lastRetainedPlanKey = "";
        addLog("已切換至 " + activeName + " " + activeSymbol + "，重新收集三週期");
        addHistory(time(System.currentTimeMillis()) + " 已切換至 " + activeName + " " + activeSymbol
                + "｜清除前一檔進場計畫");
    }

    private void restoreSnapshots(long nowEpochMs) {
        Map<Timeframe, MarketSnapshot> restored = snapshotStore.loadFresh(nowEpochMs);
        if (restored.isEmpty()) return;
        String requiredSymbol = openPosition == null ? "" : openPosition.symbol();
        MarketSnapshot newest = null;
        for (MarketSnapshot snapshot : restored.values()) {
            if (!requiredSymbol.isBlank() && !requiredSymbol.equals(snapshot.symbol())) continue;
            if (newest == null) {
                requiredSymbol = snapshot.symbol();
            }
            if (!requiredSymbol.equals(snapshot.symbol())) continue;
            snapshots.put(snapshot.timeframe(), snapshot);
            if (newest == null || snapshot.capturedAtEpochMs() > newest.capturedAtEpochMs()) {
                newest = snapshot;
            }
        }
        if (newest == null) {
            snapshotStore.clear();
            return;
        }
        activeSymbol = newest.symbol();
        activeName = newest.name();
        latestPrice = newest.effectiveClose();
        latestRawDecision = evaluateIfReady(nowEpochMs);
        if (latestRawDecision != null) {
            EntryPlanTracker.Update restored = entryPlanTracker.onEvaluation(
                    latestRawDecision,
                    latestPrice,
                    nowEpochMs
            );
            lastDecision = restored.decision();
            lastDecisionAt = nowEpochMs;
        }
        addLog("已恢復 " + activeName + " " + activeSymbol + " 尚在有效期內的K線資料");
    }

    private SignalDecision evaluateIfReady(long nowEpochMs) {
        MarketSnapshot daily = snapshots.get(Timeframe.DAILY);
        MarketSnapshot five = snapshots.get(Timeframe.MIN_5);
        MarketSnapshot one = snapshots.get(Timeframe.MIN_1);
        if (daily == null || five == null || one == null) return null;
        return engine.evaluate(daily, five, one, nowEpochMs);
    }

    private void applyPlanUpdate(EntryPlanTracker.Update update, long nowEpochMs) {
        if (update == null) return;
        lastDecision = update.decision();
        if (update.event() != EntryPlanTracker.Event.NONE) {
            String event = planEventText(update);
            addLog(time(nowEpochMs) + " " + event);
            addHistory(time(nowEpochMs) + " " + event);
            lastRetainedPlanKey = "";
        } else if (update.retainedAgainstWait() && lastDecision != null) {
            String retainedKey = planKey(lastDecision);
            if (!retainedKey.equals(lastRetainedPlanKey)) {
                String line = time(nowEpochMs) + " " + stockLabel(lastDecision)
                        + "｜1分K暫時轉為等待，原" + lastDecision.direction().label()
                        + "計畫仍保留至到期或失效";
                addLog(line);
                addHistory(line);
                lastRetainedPlanKey = retainedKey;
            }
        } else if (lastDecision == null || !lastDecision.hasDirectionalSetup()) {
            lastRetainedPlanKey = "";
        }
        logDecisionIfChanged(nowEpochMs);
    }

    private String planEventText(EntryPlanTracker.Update update) {
        SignalDecision decision = update.decision();
        String stock = stockLabel(decision);
        switch (update.event()) {
            case ARMED:
                return stock + "｜建立" + decision.direction().label() + "計畫"
                        + "｜現價 " + price(decision.currentPrice())
                        + "｜觸發區 " + price(decision.zoneLow()) + "–" + price(decision.zoneHigh())
                        + "｜" + waitingStatus(decision) + "｜未到價不通知";
            case ARMED_AT_ZONE:
                return stock + "｜建立計畫時已在" + decision.direction().label() + "觸發區"
                        + "｜現價 " + price(decision.currentPrice())
                        + "｜等待第二次穩定讀取";
            case ZONE_REACHED:
                return stock + "｜第一次到達" + decision.direction().label() + "觸發區"
                        + "｜現價 " + price(decision.currentPrice())
                        + "｜區間 " + price(decision.zoneLow()) + "–" + price(decision.zoneHigh())
                        + "｜等待第二次穩定讀取後只提醒一次";
            case REPLACED:
                return stock + "｜反向結構連續確認，改為" + decision.direction().label() + "計畫"
                        + "｜觸發區 " + price(decision.zoneLow()) + "–" + price(decision.zoneHigh());
            case INVALIDATED:
            case EXPIRED:
            case CANCELLED:
                return stock + "｜進場計畫取消｜" + update.reason()
                        + "｜現價 " + price(decision == null ? latestPrice : decision.currentPrice());
            default:
                return stock + "｜" + update.reason();
        }
    }

    private void logDecisionIfChanged(long nowEpochMs) {
        if (lastDecision == null) return;
        String signature = lastDecision.direction().name() + "|" + planKey(lastDecision)
                + "|" + firstBlocker(lastDecision);
        if (signature.equals(lastLoggedDecisionSignature)) return;
        lastLoggedDecisionSignature = signature;
        if (lastDecision.direction() == SignalDirection.WAIT) {
            String line = time(nowEpochMs) + " " + stockLabel(lastDecision)
                    + "｜先不動作｜" + firstBlocker(lastDecision);
            addLog(line);
            addHistory(line);
        } else {
            addLog(time(nowEpochMs) + " " + lastDecision.direction().label() + "計畫保留"
                    + "｜觸發區 " + price(lastDecision.zoneLow()) + "–" + price(lastDecision.zoneHigh())
                    + "｜多空界 " + price(lastDecision.boundaryReference()));
        }
    }

    private String waitingStatus(SignalDecision decision) {
        if (decision == null || !decision.hasDirectionalSetup()) return "等待新結構";
        double current = decision.currentPrice();
        double low = Math.min(decision.zoneLow(), decision.zoneHigh());
        double high = Math.max(decision.zoneLow(), decision.zoneHigh());
        String zone = price(low) + "–" + price(high);
        if (decision.direction() == SignalDirection.LONG) {
            if (current > high) return "等待回踩 " + zone + "，不追價";
            if (current < low) return "等待站回 " + zone;
        } else {
            if (current < low) return "等待反彈 " + zone + "，不追空";
            if (current > high) return "等待跌回 " + zone;
        }
        return "等待進入 " + zone;
    }

    private String planKey(SignalDecision decision) {
        if (decision == null || !decision.hasDirectionalSetup()) return "";
        return decision.symbol() + "|" + decision.direction().name() + "|"
                + TaiwanPriceSteps.alertZoneBucket(decision.triggerReference());
    }

    private String stockLabel(SignalDecision decision) {
        if (decision == null) {
            return activeName.isBlank() ? activeSymbol : activeName + " " + activeSymbol;
        }
        return decision.name().isBlank()
                ? decision.symbol()
                : decision.name() + " " + decision.symbol();
    }

    private RepositoryState buildState(long nowEpochMs) {
        String monitor;
        if (openPosition != null) {
            monitor = currentlyOnKLine
                    ? "監看：持倉中，正在更新K線"
                    : "監看：安全標頭現價持續更新；結構沿用最後K線";
        } else {
            monitor = currentlyOnKLine
                    ? "監看：正在讀取元大 K 線"
                    : (lastDecision == null
                        ? "監看：請切到元大 K 線收集資料"
                        : "監看：安全標頭現價持續更新；結構沿用最後K線");
        }
        String timeframe = "週期：日K " + chip(Timeframe.DAILY, nowEpochMs)
                + "　5分K " + chip(Timeframe.MIN_5, nowEpochMs)
                + "　1分K " + chip(Timeframe.MIN_1, nowEpochMs);
        String signal;
        if (openPosition != null) {
            String action = positionAdvice == null
                    ? PositionAction.WAIT_DATA.label()
                    : positionAdvice.action().label();
            String percent = positionAdvice != null && Double.isFinite(positionAdvice.unrealizedPercent())
                    ? "（" + String.format(Locale.TAIWAN, "%+.2f%%", positionAdvice.unrealizedPercent()) + "）"
                    : "";
            signal = "持倉：" + openPosition.side().label() + "｜" + action + percent;
        } else if (lastDecision == null) {
            signal = "判斷：等待三週期資料";
        } else {
            String prefix = currentlyOnKLine ? "判斷：" : "最後判斷 " + time(lastDecisionAt) + "：";
            if (lastDecision.direction() == SignalDirection.WAIT) {
                signal = prefix + lastDecision.direction().label() + "｜" + firstBlocker(lastDecision);
            } else {
                signal = prefix + (lastDecision.shouldNotify()
                        ? "已到" + lastDecision.direction().label() + "觸發區 "
                            + price(lastDecision.zoneLow()) + "–" + price(lastDecision.zoneHigh())
                        : lastDecision.direction().label() + "計畫｜" + waitingStatus(lastDecision))
                        + "（訊號信心 " + lastDecision.confidencePercent() + "%）";
            }
        }
        return new RepositoryState(
                monitor,
                timeframe,
                signal,
                combinedLogs(),
                activeSymbol,
                activeName,
                latestPrice,
                lastDecision,
                openPosition,
                positionAdvice,
                !currentlyOnKLine && (lastDecision != null || openPosition != null)
        );
    }

    private String chip(Timeframe timeframe, long nowEpochMs) {
        MarketSnapshot value = snapshots.get(timeframe);
        if (value == null) {
            MarketSnapshot attempt = lastAttempts.get(timeframe);
            if (attempt == null) return "—";
            return attempt.recognitionConfidence() < 0.55 ? "辨識弱" : "確認中";
        }
        String panels = value.hasMacdData() && value.hasVolumePanelData()
                ? "量+MACD"
                : value.hasMacdData() ? "MACD" : value.hasVolumePanelData() ? "量" : "?";
        if (!value.isFresh(nowEpochMs)) return "過期(" + panels + ")";
        if (value.recognitionConfidence() < 0.78
                || !value.missingRequiredFields().isEmpty()
                || (!value.hasVolumePanelData() && !value.hasMacdData())) {
            return "待補(" + panels + ")";
        }
        return "✓(" + panels + ")";
    }

    private String firstBlocker(SignalDecision decision) {
        return decision.blockers().isEmpty() ? "條件尚未對齊" : decision.blockers().get(0);
    }

    private void addLog(String line) {
        if (line == null || line.isBlank()) return;
        if (!logLines.isEmpty() && line.equals(logLines.peekLast())) return;
        logLines.addLast(line);
        while (logLines.size() > MAX_LOG_LINES) logLines.removeFirst();
    }

    private void addHistory(String line) {
        if (historyStore != null) historyStore.append(line);
    }

    private String combinedLogs() {
        String history = historyStore == null ? "尚無判斷事件。" : historyStore.joined();
        return "【判斷歷程】\n" + history
                + "\n\n【最近辨識】\n" + joinedLogs();
    }

    private String joinedLogs() {
        if (logLines.isEmpty()) return "尚無紀錄。畫面圖片不會保存。";
        StringBuilder output = new StringBuilder();
        for (String line : logLines) {
            if (output.length() > 0) output.append('\n');
            output.append(line);
        }
        return output.toString();
    }

    private String time(long epochMs) {
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss", Locale.TAIWAN);
        format.setTimeZone(TimeZone.getTimeZone("Asia/Taipei"));
        return format.format(new Date(epochMs));
    }

    private String price(double value) {
        if (!Double.isFinite(value) || value <= 0.0) return "—";
        double tick = TaiwanPriceSteps.tickSize(value);
        int decimals = tick < 0.1 ? 2 : tick < 1.0 ? 1 : 0;
        return String.format(Locale.TAIWAN, "%." + decimals + "f", value);
    }

    private String tradingDate(long epochMs) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.TAIWAN);
        format.setTimeZone(TimeZone.getTimeZone("Asia/Taipei"));
        return format.format(new Date(epochMs));
    }
}
