# Release minification is disabled for the first field-test build.
