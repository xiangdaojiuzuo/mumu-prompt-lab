package com.mumu.intraday.core;

public enum PositionAction {
    WAIT_DATA("等待K線更新", false),
    HOLD("續抱觀察", false),
    PROTECT("提高停損／保本", true),
    TAKE_PROFIT("可分批停利", true),
    EXIT("建議出場", true);

    private final String label;
    private final boolean alertWorthy;

    PositionAction(String label, boolean alertWorthy) {
        this.label = label;
        this.alertWorthy = alertWorthy;
    }

    public String label() {
        return label;
    }

    public boolean alertWorthy() {
        return alertWorthy;
    }
}
