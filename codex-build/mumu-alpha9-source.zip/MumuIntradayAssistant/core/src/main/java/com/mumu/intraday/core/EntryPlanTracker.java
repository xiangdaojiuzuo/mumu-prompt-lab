package com.mumu.intraday.core;

/**
 * Keeps a directional entry plan alive long enough for price to return to its
 * trigger zone.  A one-minute WAIT result must not silently erase a plan whose
 * day/five-minute structure is still valid.
 */
public final class EntryPlanTracker {
    public static final long DEFAULT_TTL_MS = 5L * 60L * 1_000L;
    private static final int REQUIRED_STRUCTURE_LOSSES = 2;

    public enum Event {
        NONE,
        ARMED,
        ARMED_AT_ZONE,
        ZONE_REACHED,
        INVALIDATED,
        EXPIRED,
        CANCELLED,
        REPLACED
    }

    public static final class Update {
        private final SignalDecision decision;
        private final Event event;
        private final String reason;
        private final boolean activePlan;
        private final boolean retainedAgainstWait;
        private final long armedAtEpochMs;
        private final long expiresAtEpochMs;

        private Update(
                SignalDecision decision,
                Event event,
                String reason,
                boolean activePlan,
                boolean retainedAgainstWait,
                long armedAtEpochMs,
                long expiresAtEpochMs
        ) {
            this.decision = decision;
            this.event = event == null ? Event.NONE : event;
            this.reason = reason == null ? "" : reason;
            this.activePlan = activePlan;
            this.retainedAgainstWait = retainedAgainstWait;
            this.armedAtEpochMs = armedAtEpochMs;
            this.expiresAtEpochMs = expiresAtEpochMs;
        }

        public SignalDecision decision() { return decision; }
        public Event event() { return event; }
        public String reason() { return reason; }
        public boolean hasActivePlan() { return activePlan; }
        public boolean retainedAgainstWait() { return retainedAgainstWait; }
        public long armedAtEpochMs() { return armedAtEpochMs; }
        public long expiresAtEpochMs() { return expiresAtEpochMs; }
    }

    private final long ttlMs;
    private SignalDecision activePlan;
    private SignalDecision latestEvaluation;
    private long armedAtEpochMs;
    private long expiresAtEpochMs;
    private boolean zoneTouched;
    private SignalDirection lossCandidate = SignalDirection.WAIT;
    private int structureLossCount;
    private String blockedPlanKey = "";
    private SignalDecision lastInactiveDecision;

    public EntryPlanTracker() {
        this(DEFAULT_TTL_MS);
    }

    public EntryPlanTracker(long ttlMs) {
        if (ttlMs <= 0L) throw new IllegalArgumentException("ttlMs must be positive");
        this.ttlMs = ttlMs;
    }

    public Update onEvaluation(SignalDecision evaluated, double livePrice, long nowEpochMs) {
        latestEvaluation = reprice(evaluated, livePrice);
        Update lifecycle = updateActive(latestEvaluation, livePrice, nowEpochMs, true);
        if (lifecycle != null) return lifecycle;

        if (latestEvaluation == null) return inactive(Event.NONE, "");
        if (!latestEvaluation.hasDirectionalSetup()) {
            if (latestEvaluation.confidencePercent() > 0) blockedPlanKey = "";
            lastInactiveDecision = latestEvaluation;
            return inactive(Event.NONE, "");
        }

        String candidateKey = planKey(latestEvaluation);
        if (!blockedPlanKey.isBlank() && blockedPlanKey.equals(candidateKey)) {
            lastInactiveDecision = waitFromPlan(
                    latestEvaluation,
                    livePrice,
                    "前次同一進場計畫已失效或逾時，等待新的K線結構"
            );
            return inactive(Event.NONE, "同一計畫暫不重新啟用");
        }
        return arm(latestEvaluation, livePrice, nowEpochMs, Event.ARMED);
    }

    public Update onPrice(double livePrice, long nowEpochMs) {
        Update lifecycle = updateActive(null, livePrice, nowEpochMs, false);
        return lifecycle == null ? inactive(Event.NONE, "") : lifecycle;
    }

    public SignalDecision activePlan() {
        return activePlan;
    }

    public void clear() {
        activePlan = null;
        latestEvaluation = null;
        lastInactiveDecision = null;
        armedAtEpochMs = 0L;
        expiresAtEpochMs = 0L;
        zoneTouched = false;
        structureLossCount = 0;
        lossCandidate = SignalDirection.WAIT;
        blockedPlanKey = "";
    }

    private Update updateActive(
            SignalDecision evaluated,
            double livePrice,
            long nowEpochMs,
            boolean hasNewEvaluation
    ) {
        if (activePlan == null) return null;
        activePlan = reprice(activePlan, livePrice);

        if (nowEpochMs >= expiresAtEpochMs) {
            return cancel(Event.EXPIRED, "進場計畫已超過5分鐘，需重新確認K線", livePrice);
        }
        if (isInvalidated(activePlan, livePrice)) {
            String side = activePlan.direction() == SignalDirection.LONG ? "跌破" : "突破";
            return cancel(
                    Event.INVALIDATED,
                    side + "失效價 " + activePlan.invalidationReference() + "，原計畫取消",
                    livePrice
            );
        }

        boolean retainedAgainstWait = false;
        if (hasNewEvaluation && evaluated != null && evaluated.confidencePercent() > 0) {
            SignalDirection observed = evaluated.hasDirectionalSetup()
                    ? evaluated.direction()
                    : evaluated.structuralBias();
            if (observed == activePlan.direction()) {
                resetStructureLoss();
                retainedAgainstWait = !evaluated.hasDirectionalSetup();
            } else {
                if (observed != lossCandidate) {
                    lossCandidate = observed;
                    structureLossCount = 1;
                } else {
                    structureLossCount++;
                }
                if (structureLossCount >= REQUIRED_STRUCTURE_LOSSES) {
                    SignalDecision old = activePlan;
                    String reason = observed == SignalDirection.WAIT
                            ? "日K與5分K結構已連續兩次不再同向，原計畫取消"
                            : "出現連續兩次反向結構，原" + old.direction().label() + "計畫取消";
                    Update cancelled = cancel(Event.CANCELLED, reason, livePrice);
                    if (evaluated.hasDirectionalSetup()
                            && evaluated.direction() != old.direction()) {
                        blockedPlanKey = planKey(old);
                        return arm(evaluated, livePrice, nowEpochMs, Event.REPLACED);
                    }
                    return cancelled;
                }
            }
        }

        boolean nowInZone = activePlan.shouldNotify();
        Event event = Event.NONE;
        String reason = retainedAgainstWait
                ? "1分K短暫轉為等待，但日K與5分K方向仍在，沿用原進場區"
                : "";
        if (nowInZone && !zoneTouched) {
            zoneTouched = true;
            event = Event.ZONE_REACHED;
            reason = "現價第一次進入原計畫觸發區";
        }
        return active(event, reason, retainedAgainstWait);
    }

    private Update arm(
            SignalDecision plan,
            double livePrice,
            long nowEpochMs,
            Event requestedEvent
    ) {
        activePlan = reprice(plan, livePrice);
        armedAtEpochMs = nowEpochMs;
        expiresAtEpochMs = nowEpochMs + ttlMs;
        resetStructureLoss();
        blockedPlanKey = "";
        zoneTouched = activePlan.shouldNotify();
        Event event = zoneTouched && requestedEvent == Event.ARMED
                ? Event.ARMED_AT_ZONE
                : requestedEvent;
        String reason = zoneTouched
                ? "計畫建立時現價已在觸發區"
                : "進場計畫已建立，等待現價進入觸發區";
        return active(event, reason, false);
    }

    private Update cancel(Event event, String reason, double livePrice) {
        SignalDecision old = activePlan;
        blockedPlanKey = planKey(old);
        lastInactiveDecision = waitFromPlan(old, livePrice, reason);
        activePlan = null;
        armedAtEpochMs = 0L;
        expiresAtEpochMs = 0L;
        zoneTouched = false;
        resetStructureLoss();
        return new Update(lastInactiveDecision, event, reason, false, false, 0L, 0L);
    }

    private Update active(Event event, String reason, boolean retainedAgainstWait) {
        return new Update(
                activePlan,
                event,
                reason,
                true,
                retainedAgainstWait,
                armedAtEpochMs,
                expiresAtEpochMs
        );
    }

    private Update inactive(Event event, String reason) {
        SignalDecision decision = lastInactiveDecision != null
                ? lastInactiveDecision
                : latestEvaluation;
        return new Update(decision, event, reason, false, false, 0L, 0L);
    }

    private void resetStructureLoss() {
        structureLossCount = 0;
        lossCandidate = SignalDirection.WAIT;
    }

    private boolean isInvalidated(SignalDecision plan, double livePrice) {
        if (!(livePrice > 0.0) || !(plan.invalidationReference() > 0.0)) return false;
        double tolerance = TaiwanPriceSteps.tickSize(livePrice) * 0.01;
        return plan.direction() == SignalDirection.LONG
                ? livePrice <= plan.invalidationReference() + tolerance
                : livePrice >= plan.invalidationReference() - tolerance;
    }

    private SignalDecision reprice(SignalDecision decision, double livePrice) {
        if (decision == null || !(livePrice > 0.0)) return decision;
        return decision.withCurrentPrice(livePrice);
    }

    private SignalDecision waitFromPlan(SignalDecision plan, double livePrice, String reason) {
        if (plan == null) return null;
        return SignalDecision.builder()
                .symbol(plan.symbol())
                .name(plan.name())
                .direction(SignalDirection.WAIT)
                .structuralBias(SignalDirection.WAIT)
                .confidencePercent(plan.confidencePercent())
                .currentPrice(livePrice)
                .boundaryReference(plan.boundaryReference())
                .dailyScore(plan.dailyScore())
                .fiveMinuteScore(plan.fiveMinuteScore())
                .oneMinuteScore(plan.oneMinuteScore())
                .addBlocker(reason)
                .build();
    }

    private String planKey(SignalDecision plan) {
        if (plan == null || !plan.hasDirectionalSetup()) return "";
        return plan.symbol() + "|" + plan.direction().name() + "|"
                + TaiwanPriceSteps.alertZoneBucket(plan.triggerReference());
    }
}
