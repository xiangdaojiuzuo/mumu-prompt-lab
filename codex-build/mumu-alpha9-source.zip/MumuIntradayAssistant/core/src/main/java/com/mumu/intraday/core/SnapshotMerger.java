package com.mumu.intraday.core;

/** Merges MACD and volume captures for the same stock and timeframe. */
public final class SnapshotMerger {
    private SnapshotMerger() {}

    public static MarketSnapshot merge(MarketSnapshot previous, MarketSnapshot current) {
        if (previous == null) return current;
        if (current == null) return previous;
        if (!previous.symbol().equals(current.symbol()) || previous.timeframe() != current.timeframe()) {
            return current;
        }

        MarketSnapshot.Builder merged = current.toBuilder()
                .sourceBarTime(current.sourceBarTime().isBlank()
                        ? previous.sourceBarTime() : current.sourceBarTime())
                .currentPrice(numberOr(current.currentPrice(), previous.currentPrice()))
                .open(numberOr(current.open(), previous.open()))
                .high(numberOr(current.high(), previous.high()))
                .low(numberOr(current.low(), previous.low()))
                .close(numberOr(current.close(), previous.close()))
                .volume(numberOr(current.volume(), previous.volume()))
                .ma5(pointOr(current.ma5(), previous.ma5()))
                .ma10(pointOr(current.ma10(), previous.ma10()))
                .ma20(pointOr(current.ma20(), previous.ma20()))
                .ma60(pointOr(current.ma60(), previous.ma60()))
                .averageVolume5(pointOr(current.averageVolume5(), previous.averageVolume5()))
                .averageVolume20(pointOr(current.averageVolume20(), previous.averageVolume20()))
                .middlePanel(current.middlePanel() == MiddlePanel.UNKNOWN
                        ? previous.middlePanel() : current.middlePanel())
                .macdDif(pointOr(current.macdDif(), previous.macdDif()))
                .macdSignal(pointOr(current.macdSignal(), previous.macdSignal()))
                .macdHistogram(pointOr(current.macdHistogram(), previous.macdHistogram()))
                .bollingerUpper(numberOr(current.bollingerUpper(), previous.bollingerUpper()))
                .bollingerMiddle(numberOr(current.bollingerMiddle(), previous.bollingerMiddle()))
                .bollingerLower(numberOr(current.bollingerLower(), previous.bollingerLower()))
                .k(pointOr(current.k(), previous.k()))
                .d(pointOr(current.d(), previous.d()))
                .j(pointOr(current.j(), previous.j()))
                .recognitionConfidence(Math.max(
                        current.recognitionConfidence(),
                        previous.recognitionConfidence()
                ));
        return merged.build();
    }

    private static double numberOr(double current, double previous) {
        return Double.isFinite(current) ? current : previous;
    }

    private static IndicatorPoint pointOr(IndicatorPoint current, IndicatorPoint previous) {
        return current != null && current.isPresent() ? current : previous;
    }
}
