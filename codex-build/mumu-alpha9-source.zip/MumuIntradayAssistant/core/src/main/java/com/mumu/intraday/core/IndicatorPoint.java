package com.mumu.intraday.core;

public final class IndicatorPoint {
    private static final IndicatorPoint MISSING = new IndicatorPoint(Double.NaN, Trend.UNKNOWN);

    private final double value;
    private final Trend trend;

    public IndicatorPoint(double value, Trend trend) {
        this.value = value;
        this.trend = trend == null ? Trend.UNKNOWN : trend;
    }

    public static IndicatorPoint missing() {
        return MISSING;
    }

    public double value() {
        return value;
    }

    public Trend trend() {
        return trend;
    }

    public boolean isPresent() {
        return Double.isFinite(value);
    }
}
