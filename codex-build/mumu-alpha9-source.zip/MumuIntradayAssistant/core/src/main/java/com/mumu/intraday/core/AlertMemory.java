package com.mumu.intraday.core;

public interface AlertMemory {
    boolean wasAlerted(String eventKey);
    void remember(String eventKey, long alertedAtEpochMs);
    void clear();
}
