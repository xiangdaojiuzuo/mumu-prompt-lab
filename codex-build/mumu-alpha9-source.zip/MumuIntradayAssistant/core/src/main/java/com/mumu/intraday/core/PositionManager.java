package com.mumu.intraday.core;

public final class PositionManager {
    private static final int MINIMUM_RISK_TICKS = 3;

    public OpenPosition open(
            PositionSide side,
            String symbol,
            String name,
            double entryPrice,
            long entryAtEpochMs,
            SignalDecision decision,
            MarketSnapshot fiveMinute,
            MarketSnapshot oneMinute
    ) {
        if (side == null) throw new IllegalArgumentException("side is required");
        if (!(entryPrice > 0.0)) throw new IllegalArgumentException("entry price must be positive");
        fiveMinute = PriceScaleNormalizer.normalize(fiveMinute);
        oneMinute = PriceScaleNormalizer.normalize(oneMinute);

        double boundary = decision != null && decision.boundaryReference() > 0.0
                ? decision.boundaryReference()
                : boundaryFrom(fiveMinute);
        double stop = decision != null
                && matches(side, decision.direction())
                && validStop(side, entryPrice, decision.invalidationReference())
                    ? decision.invalidationReference()
                    : initialStop(side, entryPrice, fiveMinute, oneMinute, boundary);
        return new OpenPosition(
                symbol,
                name,
                side,
                TaiwanPriceSteps.nearestTick(entryPrice),
                entryAtEpochMs,
                TaiwanPriceSteps.nearestTick(stop),
                boundary,
                entryPrice,
                entryPrice
        );
    }

    public PositionAdvice evaluate(
            OpenPosition position,
            double livePrice,
            SignalDecision decision,
            MarketSnapshot fiveMinute,
            MarketSnapshot oneMinute
    ) {
        if (position == null) return null;
        fiveMinute = PriceScaleNormalizer.normalize(fiveMinute);
        oneMinute = PriceScaleNormalizer.normalize(oneMinute);
        double current = livePrice > 0.0
                ? livePrice
                : oneMinute != null ? oneMinute.effectiveClose() : Double.NaN;
        double boundary = decision != null && decision.boundaryReference() > 0.0
                ? decision.boundaryReference()
                : position.entryBoundaryReference();
        double initialStop = position.initialStopReference();
        double risk = Math.abs(position.entryPrice() - initialStop);
        double tick = TaiwanPriceSteps.tickSize(position.entryPrice());
        if (!(risk >= tick)) risk = tick * MINIMUM_RISK_TICKS;
        double targetOne = offset(position.side(), position.entryPrice(), risk);
        double targetTwo = offset(position.side(), position.entryPrice(), risk * 2.0);

        if (!(current > 0.0)) {
            return advice(position, PositionAction.WAIT_DATA, current, initialStop,
                    targetOne, targetTwo, boundary, "尚未取得目前價格");
        }

        double bestFavorable = position.side() == PositionSide.LONG
                ? position.highestSeen() - position.entryPrice()
                : position.entryPrice() - position.lowestSeen();
        double stop = trailingStop(position, current, risk, bestFavorable, oneMinute);
        boolean stopBroken = position.side() == PositionSide.LONG
                ? current <= stop
                : current >= stop;
        if (stopBroken) {
            return advice(position, PositionAction.EXIT, current, stop,
                    targetOne, targetTwo, boundary, "現價已碰到停損／移動停損參考");
        }

        boolean strongReverse = decision != null && (position.side() == PositionSide.LONG
                ? decision.fiveMinuteScore() <= -3 && decision.oneMinuteScore() <= -2
                : decision.fiveMinuteScore() >= 3 && decision.oneMinuteScore() >= 2);
        if (strongReverse) {
            return advice(position, PositionAction.EXIT, current, stop,
                    targetOne, targetTwo, boundary, "5分K與1分K已形成反向結構");
        }

        boolean reachedTargetTwo = position.side() == PositionSide.LONG
                ? current >= targetTwo
                : current <= targetTwo;
        boolean reachedTargetOne = position.side() == PositionSide.LONG
                ? current >= targetOne
                : current <= targetOne;
        boolean extreme = isExtreme(position.side(), current, oneMinute);
        if (reachedTargetTwo || (reachedTargetOne && extreme)) {
            return advice(position, PositionAction.TAKE_PROFIT, current, stop,
                    targetOne, targetTwo, boundary,
                    reachedTargetTwo ? "已到第二停利參考" : "已到第一停利且1分K接近過熱區");
        }

        boolean oneMinuteWeakening = decision != null && (position.side() == PositionSide.LONG
                ? decision.oneMinuteScore() <= -2
                : decision.oneMinuteScore() >= 2);
        if (bestFavorable >= risk || (bestFavorable >= risk * 0.5 && oneMinuteWeakening)) {
            return advice(position, PositionAction.PROTECT, current, stop,
                    targetOne, targetTwo, boundary,
                    bestFavorable >= risk ? "最大有利幅度已達一倍風險，可保護成本" : "1分K動能轉弱，宜縮小風險");
        }

        return advice(position, PositionAction.HOLD, current, stop,
                targetOne, targetTwo, boundary, "尚未觸及停損或停利條件");
    }

    private PositionAdvice advice(
            OpenPosition position,
            PositionAction action,
            double current,
            double stop,
            double targetOne,
            double targetTwo,
            double boundary,
            String reason
    ) {
        double rawPercent = current > 0.0
                ? (current - position.entryPrice()) / position.entryPrice() * 100.0
                : Double.NaN;
        double percent = position.side() == PositionSide.SHORT ? -rawPercent : rawPercent;
        return new PositionAdvice(
                position,
                action,
                current,
                percent,
                TaiwanPriceSteps.nearestTick(stop),
                TaiwanPriceSteps.nearestTick(targetOne),
                TaiwanPriceSteps.nearestTick(targetTwo),
                boundary > 0.0 ? TaiwanPriceSteps.nearestTick(boundary) : Double.NaN,
                reason
        );
    }

    private double trailingStop(
            OpenPosition position,
            double current,
            double risk,
            double bestFavorable,
            MarketSnapshot oneMinute
    ) {
        double stop = position.initialStopReference();
        double tick = TaiwanPriceSteps.tickSize(current);
        if (bestFavorable >= risk * 2.0) {
            double locked = offset(position.side(), position.entryPrice(), risk * 0.5);
            stop = tighter(position.side(), stop, locked);
        } else if (bestFavorable >= risk) {
            stop = tighter(position.side(), stop, position.entryPrice());
        }

        if (bestFavorable >= risk && oneMinute != null && oneMinute.ma10().isPresent()) {
            double maStop = position.side() == PositionSide.LONG
                    ? oneMinute.ma10().value() - tick
                    : oneMinute.ma10().value() + tick;
            if (validStop(position.side(), current, maStop)) {
                stop = tighter(position.side(), stop, maStop);
            }
        }
        return stop;
    }

    private double initialStop(
            PositionSide side,
            double entry,
            MarketSnapshot five,
            MarketSnapshot one,
            double boundary
    ) {
        double tick = TaiwanPriceSteps.tickSize(entry);
        double raw;
        if (side == PositionSide.LONG) {
            raw = minPositive(
                    one == null ? Double.NaN : one.low(),
                    boundary > 0.0 ? boundary : five == null ? Double.NaN : five.ma20().value()
            );
            raw = raw > 0.0 ? raw - tick : entry - tick * MINIMUM_RISK_TICKS;
        } else {
            raw = maxPositive(
                    one == null ? Double.NaN : one.high(),
                    boundary > 0.0 ? boundary : five == null ? Double.NaN : five.ma20().value()
            );
            raw = raw > 0.0 ? raw + tick : entry + tick * MINIMUM_RISK_TICKS;
        }
        return validStop(side, entry, raw)
                ? raw
                : side == PositionSide.LONG
                    ? entry - tick * MINIMUM_RISK_TICKS
                    : entry + tick * MINIMUM_RISK_TICKS;
    }

    private boolean isExtreme(PositionSide side, double current, MarketSnapshot one) {
        if (one == null || !one.k().isPresent()) return false;
        if (side == PositionSide.LONG) {
            boolean hot = one.k().value() >= 85.0;
            boolean nearUpper = one.bollingerUpper() > 0.0
                    && current >= one.bollingerUpper() - TaiwanPriceSteps.tickSize(current);
            return hot || nearUpper;
        }
        boolean cold = one.k().value() <= 15.0;
        boolean nearLower = one.bollingerLower() > 0.0
                && current <= one.bollingerLower() + TaiwanPriceSteps.tickSize(current);
        return cold || nearLower;
    }

    private double boundaryFrom(MarketSnapshot five) {
        if (five == null) return Double.NaN;
        double value = five.ma20().isPresent()
                ? five.ma20().value()
                : five.bollingerMiddle() > 0.0
                    ? five.bollingerMiddle()
                    : five.ma10().isPresent() ? five.ma10().value() : Double.NaN;
        return value > 0.0 ? TaiwanPriceSteps.nearestTick(value) : Double.NaN;
    }

    private boolean matches(PositionSide side, SignalDirection direction) {
        return side == PositionSide.LONG && direction == SignalDirection.LONG
                || side == PositionSide.SHORT && direction == SignalDirection.SHORT;
    }

    private boolean validStop(PositionSide side, double reference, double stop) {
        return stop > 0.0 && (side == PositionSide.LONG ? stop < reference : stop > reference);
    }

    private double offset(PositionSide side, double value, double amount) {
        return side == PositionSide.LONG ? value + amount : value - amount;
    }

    private double tighter(PositionSide side, double first, double second) {
        return side == PositionSide.LONG ? Math.max(first, second) : Math.min(first, second);
    }

    private double minPositive(double first, double second) {
        if (first > 0.0 && second > 0.0) return Math.min(first, second);
        if (first > 0.0) return first;
        return second;
    }

    private double maxPositive(double first, double second) {
        if (first > 0.0 && second > 0.0) return Math.max(first, second);
        if (first > 0.0) return first;
        return second;
    }
}
