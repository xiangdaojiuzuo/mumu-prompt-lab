package com.mumu.intraday.core;

import java.util.Optional;

/**
 * Converts continuously recalculated decisions into one-time alert events.
 * The current price is deliberately not part of the event key. A stable trigger
 * reference is grouped into a five-tick zone, so one-tick oscillation cannot
 * create repeated notifications.
 */
public final class AlertGate {
    private final AlertMemory memory;
    private final int requiredStableScans;
    private String pendingKey = "";
    private int pendingCount;

    public AlertGate(AlertMemory memory) {
        this(memory, 2);
    }

    public AlertGate(AlertMemory memory, int requiredStableScans) {
        if (memory == null) throw new IllegalArgumentException("memory is required");
        this.memory = memory;
        this.requiredStableScans = Math.max(2, requiredStableScans);
    }

    public Optional<AlertEvent> evaluate(
            SignalDecision decision,
            String tradingDateKey,
            long nowEpochMs
    ) {
        if (decision == null || !decision.shouldNotify()) {
            clearPending();
            return Optional.empty();
        }
        String key = decision.eventKey(tradingDateKey);
        if (key.isBlank() || memory.wasAlerted(key)) {
            clearPending();
            return Optional.empty();
        }
        if (key.equals(pendingKey)) {
            pendingCount += 1;
        } else {
            pendingKey = key;
            pendingCount = 1;
        }
        if (pendingCount < requiredStableScans) return Optional.empty();

        memory.remember(key, nowEpochMs);
        clearPending();
        return Optional.of(new AlertEvent(key, decision, nowEpochMs));
    }

    public void resetAll() {
        memory.clear();
        clearPending();
    }

    private void clearPending() {
        pendingKey = "";
        pendingCount = 0;
    }

    public static final class AlertEvent {
        private final String eventKey;
        private final SignalDecision decision;
        private final long createdAtEpochMs;

        private AlertEvent(String eventKey, SignalDecision decision, long createdAtEpochMs) {
            this.eventKey = eventKey;
            this.decision = decision;
            this.createdAtEpochMs = createdAtEpochMs;
        }

        public String eventKey() { return eventKey; }
        public SignalDecision decision() { return decision; }
        public long createdAtEpochMs() { return createdAtEpochMs; }
    }
}
