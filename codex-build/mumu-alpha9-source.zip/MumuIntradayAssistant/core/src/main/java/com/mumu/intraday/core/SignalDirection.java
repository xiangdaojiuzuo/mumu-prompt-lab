package com.mumu.intraday.core;

public enum SignalDirection {
    LONG("偏多"),
    SHORT("偏空"),
    WAIT("先不動作");

    private final String label;

    SignalDirection(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}
