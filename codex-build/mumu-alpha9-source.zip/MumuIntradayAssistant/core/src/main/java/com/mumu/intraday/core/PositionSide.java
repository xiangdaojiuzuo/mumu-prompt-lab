package com.mumu.intraday.core;

public enum PositionSide {
    LONG("做多"),
    SHORT("做空");

    private final String label;

    PositionSide(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}
