package com.mumu.intraday.core;

public enum Trend {
    UP,
    DOWN,
    FLAT,
    UNKNOWN;

    public static Trend fromArrow(String text) {
        if (text == null) return UNKNOWN;
        if (text.contains("↑") || text.contains("↗")) return UP;
        if (text.contains("↓") || text.contains("↘")) return DOWN;
        if (text.contains("→") || text.contains("－") || text.contains("-")) return FLAT;
        return UNKNOWN;
    }
}
