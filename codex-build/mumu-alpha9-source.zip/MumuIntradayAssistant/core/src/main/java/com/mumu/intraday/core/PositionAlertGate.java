package com.mumu.intraday.core;

import java.util.Optional;

/** Emits each management action once per position after two stable scans. */
public final class PositionAlertGate {
    private final AlertMemory memory;
    private final int requiredStableScans;
    private String pendingKey = "";
    private int pendingCount;

    public PositionAlertGate(AlertMemory memory, int requiredStableScans) {
        if (memory == null) throw new IllegalArgumentException("memory is required");
        this.memory = memory;
        this.requiredStableScans = Math.max(2, requiredStableScans);
    }

    public Optional<PositionAlertEvent> evaluate(PositionAdvice advice, long nowEpochMs) {
        if (advice == null || !advice.shouldNotify()) {
            clearPending();
            return Optional.empty();
        }
        String key = advice.eventKey();
        if (key.isBlank() || memory.wasAlerted(key)) {
            clearPending();
            return Optional.empty();
        }
        if (key.equals(pendingKey)) {
            pendingCount += 1;
        } else {
            pendingKey = key;
            pendingCount = 1;
        }
        if (pendingCount < requiredStableScans) return Optional.empty();
        memory.remember(key, nowEpochMs);
        clearPending();
        return Optional.of(new PositionAlertEvent(key, advice, nowEpochMs));
    }

    public void resetAll() {
        memory.clear();
        clearPending();
    }

    public void clearPending() {
        pendingKey = "";
        pendingCount = 0;
    }

    public static final class PositionAlertEvent {
        private final String eventKey;
        private final PositionAdvice advice;
        private final long createdAtEpochMs;

        private PositionAlertEvent(String eventKey, PositionAdvice advice, long createdAtEpochMs) {
            this.eventKey = eventKey;
            this.advice = advice;
            this.createdAtEpochMs = createdAtEpochMs;
        }

        public String eventKey() { return eventKey; }
        public PositionAdvice advice() { return advice; }
        public long createdAtEpochMs() { return createdAtEpochMs; }
    }
}
