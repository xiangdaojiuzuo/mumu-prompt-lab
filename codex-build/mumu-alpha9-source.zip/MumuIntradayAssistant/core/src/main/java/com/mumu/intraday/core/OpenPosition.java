package com.mumu.intraday.core;

public final class OpenPosition {
    private final String symbol;
    private final String name;
    private final PositionSide side;
    private final double entryPrice;
    private final long entryAtEpochMs;
    private final double initialStopReference;
    private final double entryBoundaryReference;
    private final double highestSeen;
    private final double lowestSeen;

    public OpenPosition(
            String symbol,
            String name,
            PositionSide side,
            double entryPrice,
            long entryAtEpochMs,
            double initialStopReference,
            double entryBoundaryReference,
            double highestSeen,
            double lowestSeen
    ) {
        if (side == null) throw new IllegalArgumentException("position side is required");
        if (!(entryPrice > 0.0)) throw new IllegalArgumentException("entry price must be positive");
        this.symbol = symbol == null ? "" : symbol.trim();
        this.name = name == null ? "" : name.trim();
        this.side = side;
        this.entryPrice = entryPrice;
        this.entryAtEpochMs = entryAtEpochMs;
        this.initialStopReference = initialStopReference;
        this.entryBoundaryReference = entryBoundaryReference;
        this.highestSeen = highestSeen > 0.0 ? highestSeen : entryPrice;
        this.lowestSeen = lowestSeen > 0.0 ? lowestSeen : entryPrice;
    }

    public String symbol() { return symbol; }
    public String name() { return name; }
    public PositionSide side() { return side; }
    public double entryPrice() { return entryPrice; }
    public long entryAtEpochMs() { return entryAtEpochMs; }
    public double initialStopReference() { return initialStopReference; }
    public double entryBoundaryReference() { return entryBoundaryReference; }
    public double highestSeen() { return highestSeen; }
    public double lowestSeen() { return lowestSeen; }

    public OpenPosition withObservedPrice(double price) {
        if (!(price > 0.0)) return this;
        double high = Math.max(highestSeen, price);
        double low = Math.min(lowestSeen, price);
        if (high == highestSeen && low == lowestSeen) return this;
        return new OpenPosition(
                symbol,
                name,
                side,
                entryPrice,
                entryAtEpochMs,
                initialStopReference,
                entryBoundaryReference,
                high,
                low
        );
    }

    public String sessionKey() {
        return symbol + "|" + side.name() + "|" + entryAtEpochMs;
    }
}
