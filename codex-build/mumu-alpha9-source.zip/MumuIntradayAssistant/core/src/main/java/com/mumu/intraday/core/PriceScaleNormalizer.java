package com.mumu.intraday.core;

/**
 * Repairs OCR values whose decimal point disappeared (for example 48.80 was
 * recognized as 4880). Only price-like fields are touched; volume, MACD and KD
 * keep their original scale.
 */
public final class PriceScaleNormalizer {
    private static final double MIN_REASONABLE_RATIO = 1.0 / 6.0;
    private static final double MAX_REASONABLE_RATIO = 6.0;
    private static final String CORRECTION_NOTE = "價格小數點尺度已自動校正";

    private PriceScaleNormalizer() {}

    public static MarketSnapshot normalize(MarketSnapshot source) {
        if (source == null) return null;
        double reference = source.effectiveClose();
        if (!(reference > 0.0) || !Double.isFinite(reference)) return source;

        double open = normalizePrice(source.open(), reference);
        double high = normalizePrice(source.high(), reference);
        double low = normalizePrice(source.low(), reference);
        double close = normalizePrice(source.close(), reference);
        IndicatorPoint ma5 = normalizePoint(source.ma5(), reference);
        IndicatorPoint ma10 = normalizePoint(source.ma10(), reference);
        IndicatorPoint ma20 = normalizePoint(source.ma20(), reference);
        IndicatorPoint ma60 = normalizePoint(source.ma60(), reference);
        double upper = normalizePrice(source.bollingerUpper(), reference);
        double middle = normalizePrice(source.bollingerMiddle(), reference);
        double lower = normalizePrice(source.bollingerLower(), reference);

        boolean corrected = changed(source.open(), open)
                || changed(source.high(), high)
                || changed(source.low(), low)
                || changed(source.close(), close)
                || changed(source.ma5().value(), ma5.value())
                || changed(source.ma10().value(), ma10.value())
                || changed(source.ma20().value(), ma20.value())
                || changed(source.ma60().value(), ma60.value())
                || changed(source.bollingerUpper(), upper)
                || changed(source.bollingerMiddle(), middle)
                || changed(source.bollingerLower(), lower);
        if (!corrected) return source;

        MarketSnapshot.Builder result = source.toBuilder()
                .open(open).high(high).low(low).close(close)
                .ma5(ma5).ma10(ma10).ma20(ma20).ma60(ma60)
                .bollingerUpper(upper).bollingerMiddle(middle).bollingerLower(lower);
        if (!source.recognitionNotes().contains(CORRECTION_NOTE)) {
            result.addRecognitionNote(CORRECTION_NOTE);
        }
        return result.build();
    }

    public static double normalizePrice(double value, double reference) {
        if (!Double.isFinite(value) || !(value > 0.0)
                || !Double.isFinite(reference) || !(reference > 0.0)) {
            return value;
        }
        double ratio = value / reference;
        if (ratio >= MIN_REASONABLE_RATIO && ratio <= MAX_REASONABLE_RATIO) {
            return value;
        }

        double best = value;
        double bestDistance = Double.POSITIVE_INFINITY;
        for (int power = -6; power <= 6; power++) {
            double candidate = value * Math.pow(10.0, power);
            if (!Double.isFinite(candidate) || !(candidate > 0.0)) continue;
            double candidateRatio = candidate / reference;
            if (candidateRatio < MIN_REASONABLE_RATIO
                    || candidateRatio > MAX_REASONABLE_RATIO) continue;
            double distance = Math.abs(Math.log(candidateRatio));
            if (distance < bestDistance) {
                best = candidate;
                bestDistance = distance;
            }
        }
        return best;
    }

    private static IndicatorPoint normalizePoint(IndicatorPoint point, double reference) {
        if (point == null || !point.isPresent()) return IndicatorPoint.missing();
        return new IndicatorPoint(normalizePrice(point.value(), reference), point.trend());
    }

    private static boolean changed(double before, double after) {
        return Double.doubleToLongBits(before) != Double.doubleToLongBits(after);
    }
}
