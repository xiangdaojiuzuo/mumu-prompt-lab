package com.mumu.intraday.core;

public enum MiddlePanel {
    VOLUME("成交量能"),
    MACD("MACD"),
    UNKNOWN("未辨認");

    private final String label;

    MiddlePanel(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}
