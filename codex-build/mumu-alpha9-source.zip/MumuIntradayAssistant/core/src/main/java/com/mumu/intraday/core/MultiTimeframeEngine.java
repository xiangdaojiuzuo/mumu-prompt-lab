package com.mumu.intraday.core;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class MultiTimeframeEngine {
    private static final int DAILY_THRESHOLD = 2;
    private static final int FIVE_MIN_THRESHOLD = 3;
    private static final int ONE_MIN_TRIGGER = 2;

    public SignalDecision evaluate(
            MarketSnapshot daily,
            MarketSnapshot fiveMinute,
            MarketSnapshot oneMinute,
            long nowEpochMs
    ) {
        daily = PriceScaleNormalizer.normalize(daily);
        fiveMinute = PriceScaleNormalizer.normalize(fiveMinute);
        oneMinute = PriceScaleNormalizer.normalize(oneMinute);
        SignalDecision.Builder result = SignalDecision.builder();
        String symbol = firstNonBlank(
                daily == null ? "" : daily.symbol(),
                fiveMinute == null ? "" : fiveMinute.symbol(),
                oneMinute == null ? "" : oneMinute.symbol()
        );
        String name = firstNonBlank(
                daily == null ? "" : daily.name(),
                fiveMinute == null ? "" : fiveMinute.name(),
                oneMinute == null ? "" : oneMinute.name()
        );
        result.symbol(symbol).name(name).direction(SignalDirection.WAIT);

        List<String> blockers = validateSnapshots(daily, fiveMinute, oneMinute, nowEpochMs);
        if (!blockers.isEmpty()) {
            result.structuralBias(SignalDirection.WAIT)
                    .confidencePercent(0)
                    .addBlockers(blockers);
            return result.build();
        }

        double currentPrice = oneMinute.effectiveClose();
        result.currentPrice(currentPrice)
                .boundaryReference(boundaryReference(fiveMinute));

        ScoreCard day = scoreDaily(daily);
        ScoreCard five = scoreFiveMinute(fiveMinute);
        ScoreCard one = scoreOneMinute(oneMinute);
        result.dailyScore(day.score)
                .fiveMinuteScore(five.score)
                .oneMinuteScore(one.score);

        SignalDirection structure = structuralBias(day.score, five.score);
        result.structuralBias(structure);

        SignalDirection finalDirection = SignalDirection.WAIT;
        if (structure == SignalDirection.LONG && one.score >= ONE_MIN_TRIGGER) {
            finalDirection = SignalDirection.LONG;
        } else if (structure == SignalDirection.SHORT && one.score <= -ONE_MIN_TRIGGER) {
            finalDirection = SignalDirection.SHORT;
        }

        List<String> executionBlockers = new ArrayList<>();
        if (structure == SignalDirection.WAIT) {
            executionBlockers.add(structureBlocker(day.score, five.score));
        } else if (finalDirection == SignalDirection.WAIT) {
            executionBlockers.add("1分K尚未出現同方向觸發，先不追價");
        }

        if (finalDirection == SignalDirection.LONG && isLongChasing(oneMinute)) {
            finalDirection = SignalDirection.WAIT;
            executionBlockers.add("1分K已接近布林上緣或KD過熱，等待拉回");
        }
        if (finalDirection == SignalDirection.SHORT && isShortChasing(oneMinute)) {
            finalDirection = SignalDirection.WAIT;
            executionBlockers.add("1分K已接近布林下緣或KD過低，等待反彈失敗");
        }
        if (finalDirection != SignalDirection.WAIT && hasExtremelyThinVolume(oneMinute)) {
            finalDirection = SignalDirection.WAIT;
            executionBlockers.add("1分K量能過低，訊號容易失真");
        }

        result.direction(finalDirection)
                .confidencePercent(confidence(daily, fiveMinute, oneMinute, day.score, five.score, one.score))
                .addReasons(selectReasons(finalDirection, structure, day, five, one))
                .addBlockers(executionBlockers);

        if (finalDirection == SignalDirection.LONG || finalDirection == SignalDirection.SHORT) {
            double reference = triggerReference(finalDirection, oneMinute);
            double tick = TaiwanPriceSteps.tickSize(reference);
            double invalidation = invalidation(finalDirection, fiveMinute, oneMinute);
            double entry = TaiwanPriceSteps.nearestTick(reference);
            double stop = validInvalidation(finalDirection, entry, invalidation, tick)
                    ? TaiwanPriceSteps.nearestTick(invalidation)
                    : defaultInvalidation(finalDirection, entry, tick);
            double risk = Math.max(Math.abs(entry - stop), tick * 3.0);
            double targetOne = offset(finalDirection, entry, risk);
            double targetTwo = offset(finalDirection, entry, risk * 2.0);
            result.triggerReference(entry)
                    .zoneLow(TaiwanPriceSteps.nearestTick(reference - tick))
                    .zoneHigh(TaiwanPriceSteps.nearestTick(reference + tick))
                    .invalidationReference(stop)
                    .targetOneReference(TaiwanPriceSteps.nearestTick(targetOne))
                    .targetTwoReference(TaiwanPriceSteps.nearestTick(targetTwo));
        }

        return result.build();
    }

    private List<String> validateSnapshots(
            MarketSnapshot daily,
            MarketSnapshot five,
            MarketSnapshot one,
            long nowEpochMs
    ) {
        List<String> blockers = new ArrayList<>();
        validateOne(daily, Timeframe.DAILY, "日K", nowEpochMs, blockers);
        validateOne(five, Timeframe.MIN_5, "5分K", nowEpochMs, blockers);
        validateOne(one, Timeframe.MIN_1, "1分K", nowEpochMs, blockers);
        if (daily != null && five != null && one != null) {
            Set<String> symbols = new LinkedHashSet<>();
            if (!daily.symbol().isBlank()) symbols.add(daily.symbol());
            if (!five.symbol().isBlank()) symbols.add(five.symbol());
            if (!one.symbol().isBlank()) symbols.add(one.symbol());
            if (symbols.size() > 1) blockers.add("三個週期不是同一檔股票，已清除混合資料");
        }
        return blockers;
    }

    private void validateOne(
            MarketSnapshot snapshot,
            Timeframe expected,
            String label,
            long nowEpochMs,
            List<String> blockers
    ) {
        if (snapshot == null) {
            blockers.add("尚未讀取" + label);
            return;
        }
        if (snapshot.timeframe() != expected) {
            blockers.add(label + "週期辨識不一致");
            return;
        }
        if (!snapshot.isFresh(nowEpochMs)) {
            blockers.add(label + "資料已過期，請切回該週期更新");
        }
        if (!snapshot.stableFrame()) {
            blockers.add(label + "畫面仍在切換或載入中");
        }
        if (snapshot.recognitionConfidence() < 0.78) {
            blockers.add(label + "辨識信心不足");
        }
        List<String> missing = snapshot.missingRequiredFields();
        if (!missing.isEmpty()) {
            blockers.add(label + "缺少：" + String.join("、", missing));
        }
        if (!snapshot.hasVolumePanelData() && !snapshot.hasMacdData()) {
            blockers.add(label + "中間視窗尚未讀到MACD或成交量能");
        }
    }

    private ScoreCard scoreDaily(MarketSnapshot s) {
        ScoreCard card = new ScoreCard();
        double price = s.effectiveClose();
        comparePriceToMa(card, price, s.ma20(), 2, "日K站上MA20", "日K跌破MA20");
        comparePriceToMa(card, price, s.ma10(), 1, "日K站上MA10", "日K位於MA10下方");
        alignment(card, s, 2, "日K均線多頭排列", "日K均線空頭排列");
        trend(card, s.ma5().trend(), 1, "日K MA5向上", "日K MA5向下");
        trend(card, s.ma20().trend(), 1, "日K MA20向上", "日K MA20向下");
        kd(card, s, 1, "日K KD偏多", "日K KD偏空");
        macd(card, s, 1, "日K MACD偏多", "日K MACD偏空");
        bollinger(card, s, 1, "日K位於布林中線上方", "日K位於布林中線下方");
        return card;
    }

    private ScoreCard scoreFiveMinute(MarketSnapshot s) {
        ScoreCard card = new ScoreCard();
        double price = s.effectiveClose();
        comparePriceToMa(card, price, s.ma20(), 2, "5分K站上MA20", "5分K跌破MA20");
        comparePriceToMa(card, price, s.ma5(), 1, "5分K站上MA5", "5分K位於MA5下方");
        alignment(card, s, 2, "5分K均線多頭排列", "5分K均線空頭排列");
        trend(card, s.ma5().trend(), 1, "5分K MA5向上", "5分K MA5向下");
        trend(card, s.ma10().trend(), 1, "5分K MA10向上", "5分K MA10向下");
        candle(card, s, 1, "5分K收紅", "5分K收黑");
        kd(card, s, 1, "5分K KD偏多", "5分K KD偏空");
        macd(card, s, 2, "5分K MACD偏多", "5分K MACD偏空");
        volume(card, s, 1, "5分K量能支持", "5分K量能偏弱");
        return card;
    }

    private ScoreCard scoreOneMinute(MarketSnapshot s) {
        ScoreCard card = new ScoreCard();
        double price = s.effectiveClose();
        comparePriceToMa(card, price, s.ma20(), 1, "1分K站上MA20", "1分K跌破MA20");
        comparePriceToMa(card, price, s.ma5(), 1, "1分K站上MA5", "1分K位於MA5下方");
        comparePriceToMa(card, price, s.ma10(), 1, "1分K站上MA10", "1分K位於MA10下方");
        trend(card, s.ma5().trend(), 1, "1分K MA5向上", "1分K MA5向下");
        candle(card, s, 1, "1分K收紅確認", "1分K收黑確認");
        kd(card, s, 2, "1分K KD向上觸發", "1分K KD向下觸發");
        macd(card, s, 1, "1分K MACD向上", "1分K MACD向下");
        volume(card, s, 1, "1分K量能支持", "1分K量能不足");
        return card;
    }

    private void comparePriceToMa(
            ScoreCard card,
            double price,
            IndicatorPoint ma,
            int weight,
            String bullish,
            String bearish
    ) {
        if (!ma.isPresent() || !(price > 0.0)) return;
        if (price > ma.value()) card.add(weight, bullish);
        else if (price < ma.value()) card.add(-weight, bearish);
    }

    private void alignment(ScoreCard card, MarketSnapshot s, int weight, String bullish, String bearish) {
        if (!s.ma5().isPresent() || !s.ma10().isPresent() || !s.ma20().isPresent()) return;
        if (s.ma5().value() > s.ma10().value() && s.ma10().value() > s.ma20().value()) {
            card.add(weight, bullish);
        } else if (s.ma5().value() < s.ma10().value() && s.ma10().value() < s.ma20().value()) {
            card.add(-weight, bearish);
        }
    }

    private void trend(ScoreCard card, Trend trend, int weight, String bullish, String bearish) {
        if (trend == Trend.UP) card.add(weight, bullish);
        else if (trend == Trend.DOWN) card.add(-weight, bearish);
    }

    private void kd(ScoreCard card, MarketSnapshot s, int weight, String bullish, String bearish) {
        if (!s.k().isPresent() || !s.d().isPresent()) return;
        if (s.k().value() > s.d().value()) card.add(weight, bullish);
        else if (s.k().value() < s.d().value()) card.add(-weight, bearish);
        if (s.k().trend() == Trend.UP && s.d().trend() != Trend.DOWN) card.add(1, bullish);
        if (s.k().trend() == Trend.DOWN && s.d().trend() != Trend.UP) card.add(-1, bearish);
    }

    private void bollinger(ScoreCard card, MarketSnapshot s, int weight, String bullish, String bearish) {
        if (!(s.bollingerMiddle() > 0.0)) return;
        if (s.effectiveClose() > s.bollingerMiddle()) card.add(weight, bullish);
        else if (s.effectiveClose() < s.bollingerMiddle()) card.add(-weight, bearish);
    }

    private void candle(ScoreCard card, MarketSnapshot s, int weight, String bullish, String bearish) {
        if (!(s.open() > 0.0) || !(s.close() > 0.0)) return;
        if (s.close() > s.open()) card.add(weight, bullish);
        else if (s.close() < s.open()) card.add(-weight, bearish);
    }

    private void volume(ScoreCard card, MarketSnapshot s, int weight, String healthy, String weak) {
        if (!(s.volume() >= 0.0) || !s.averageVolume5().isPresent()) return;
        double ratio = s.volume() / Math.max(1.0, s.averageVolume5().value());
        if (ratio >= 0.8) card.add(weight, healthy);
        else if (ratio < 0.35) card.note(weak);
    }

    private void macd(ScoreCard card, MarketSnapshot s, int weight, String bullish, String bearish) {
        if (!s.hasMacdData()) return;
        boolean histogramPositive = !s.macdHistogram().isPresent() || s.macdHistogram().value() >= 0.0;
        boolean histogramNegative = !s.macdHistogram().isPresent() || s.macdHistogram().value() <= 0.0;
        if (s.macdDif().value() > s.macdSignal().value() && histogramPositive) {
            card.add(weight, bullish);
        } else if (s.macdDif().value() < s.macdSignal().value() && histogramNegative) {
            card.add(-weight, bearish);
        }
        if (s.macdHistogram().trend() == Trend.UP) card.add(1, bullish);
        else if (s.macdHistogram().trend() == Trend.DOWN) card.add(-1, bearish);
    }

    private SignalDirection structuralBias(int dailyScore, int fiveScore) {
        if (dailyScore >= DAILY_THRESHOLD && fiveScore >= FIVE_MIN_THRESHOLD) return SignalDirection.LONG;
        if (dailyScore <= -DAILY_THRESHOLD && fiveScore <= -FIVE_MIN_THRESHOLD) return SignalDirection.SHORT;
        return SignalDirection.WAIT;
    }

    private String structureBlocker(int dailyScore, int fiveScore) {
        if (dailyScore >= DAILY_THRESHOLD && fiveScore <= -FIVE_MIN_THRESHOLD) {
            return "日K偏多、5分K偏空，週期互相衝突";
        }
        if (dailyScore <= -DAILY_THRESHOLD && fiveScore >= FIVE_MIN_THRESHOLD) {
            return "日K偏空、5分K偏多，週期互相衝突";
        }
        return "日K與5分K尚未形成同方向結構";
    }

    private boolean hasExtremelyThinVolume(MarketSnapshot s) {
        if (!(s.volume() >= 0.0) || !s.averageVolume5().isPresent()) return false;
        return s.volume() / Math.max(1.0, s.averageVolume5().value()) < 0.20;
    }

    private boolean isLongChasing(MarketSnapshot s) {
        boolean kdHot = s.k().isPresent() && s.k().value() >= 88.0;
        boolean atUpper = nearBandEdge(s, true);
        return kdHot && atUpper;
    }

    private boolean isShortChasing(MarketSnapshot s) {
        boolean kdCold = s.k().isPresent() && s.k().value() <= 12.0;
        boolean atLower = nearBandEdge(s, false);
        return kdCold && atLower;
    }

    private boolean nearBandEdge(MarketSnapshot s, boolean upper) {
        if (!(s.bollingerUpper() > s.bollingerLower()) || !(s.effectiveClose() > 0.0)) return false;
        double width = s.bollingerUpper() - s.bollingerLower();
        double position = (s.effectiveClose() - s.bollingerLower()) / width;
        return upper ? position >= 0.88 : position <= 0.12;
    }

    private int confidence(
            MarketSnapshot daily,
            MarketSnapshot five,
            MarketSnapshot one,
            int dailyScore,
            int fiveScore,
            int oneScore
    ) {
        double recognition = daily.recognitionConfidence() * 0.25
                + five.recognitionConfidence() * 0.40
                + one.recognitionConfidence() * 0.35;
        double strength = Math.min(1.0, Math.abs(dailyScore) / 7.0) * 0.25
                + Math.min(1.0, Math.abs(fiveScore) / 10.0) * 0.40
                + Math.min(1.0, Math.abs(oneScore) / 8.0) * 0.35;
        return (int) Math.round(Math.min(0.95, recognition * 0.58 + strength * 0.42) * 100.0);
    }

    private List<String> selectReasons(
            SignalDirection finalDirection,
            SignalDirection structure,
            ScoreCard daily,
            ScoreCard five,
            ScoreCard one
    ) {
        List<String> result = new ArrayList<>();
        boolean positive = finalDirection == SignalDirection.LONG
                || (finalDirection == SignalDirection.WAIT && structure == SignalDirection.LONG);
        boolean negative = finalDirection == SignalDirection.SHORT
                || (finalDirection == SignalDirection.WAIT && structure == SignalDirection.SHORT);
        if (positive) {
            addFirst(result, daily.positive);
            addFirst(result, five.positive);
            addFirst(result, one.positive);
        } else if (negative) {
            addFirst(result, daily.negative);
            addFirst(result, five.negative);
            addFirst(result, one.negative);
        } else {
            addFirst(result, daily.notes);
            addFirst(result, five.notes);
            addFirst(result, one.notes);
        }
        return result;
    }

    private void addFirst(List<String> output, List<String> candidates) {
        if (candidates != null && !candidates.isEmpty() && output.size() < 4) {
            output.add(candidates.get(0));
        }
    }

    private double triggerReference(SignalDirection direction, MarketSnapshot one) {
        if (direction == SignalDirection.LONG) {
            return Math.max(one.ma5().value(), one.ma10().value());
        }
        return Math.min(one.ma5().value(), one.ma10().value());
    }

    private double boundaryReference(MarketSnapshot five) {
        double value = five.ma20().isPresent()
                ? five.ma20().value()
                : five.bollingerMiddle() > 0.0
                    ? five.bollingerMiddle()
                    : five.ma10().isPresent() ? five.ma10().value() : Double.NaN;
        return value > 0.0 ? TaiwanPriceSteps.nearestTick(value) : Double.NaN;
    }

    private double invalidation(
            SignalDirection direction,
            MarketSnapshot five,
            MarketSnapshot one
    ) {
        double reference;
        if (direction == SignalDirection.LONG) {
            reference = minPositive(one.low(), five.ma20().value());
            return reference - TaiwanPriceSteps.tickSize(reference);
        }
        reference = Math.max(positiveOrZero(one.high()), positiveOrZero(five.ma20().value()));
        return reference + TaiwanPriceSteps.tickSize(reference);
    }

    private boolean validInvalidation(
            SignalDirection direction,
            double entry,
            double invalidation,
            double tick
    ) {
        return invalidation > 0.0
                && Math.abs(entry - invalidation) >= tick * 3.0
                && (direction == SignalDirection.LONG
                ? invalidation < entry
                : invalidation > entry);
    }

    private double defaultInvalidation(
            SignalDirection direction,
            double entry,
            double tick
    ) {
        double value = direction == SignalDirection.LONG
                ? entry - tick * 3.0
                : entry + tick * 3.0;
        return TaiwanPriceSteps.nearestTick(value);
    }

    private double offset(SignalDirection direction, double value, double amount) {
        return direction == SignalDirection.LONG ? value + amount : value - amount;
    }

    private double minPositive(double a, double b) {
        if (a > 0.0 && b > 0.0) return Math.min(a, b);
        if (a > 0.0) return a;
        return b;
    }

    private double positiveOrZero(double value) {
        return value > 0.0 ? value : 0.0;
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) return value.trim();
        }
        return "";
    }

    private static final class ScoreCard {
        private int score;
        private final List<String> positive = new ArrayList<>();
        private final List<String> negative = new ArrayList<>();
        private final List<String> notes = new ArrayList<>();

        private void add(int delta, String reason) {
            score += delta;
            if (delta > 0) positive.add(reason);
            else if (delta < 0) negative.add(reason);
        }

        private void note(String reason) {
            notes.add(reason);
        }
    }
}
