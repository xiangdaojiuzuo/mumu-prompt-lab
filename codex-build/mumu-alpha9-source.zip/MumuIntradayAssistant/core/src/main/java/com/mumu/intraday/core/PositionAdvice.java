package com.mumu.intraday.core;

public final class PositionAdvice {
    private final OpenPosition position;
    private final PositionAction action;
    private final double currentPrice;
    private final double unrealizedPercent;
    private final double stopReference;
    private final double targetOneReference;
    private final double targetTwoReference;
    private final double boundaryReference;
    private final String reason;

    public PositionAdvice(
            OpenPosition position,
            PositionAction action,
            double currentPrice,
            double unrealizedPercent,
            double stopReference,
            double targetOneReference,
            double targetTwoReference,
            double boundaryReference,
            String reason
    ) {
        this.position = position;
        this.action = action == null ? PositionAction.WAIT_DATA : action;
        this.currentPrice = currentPrice;
        this.unrealizedPercent = unrealizedPercent;
        this.stopReference = stopReference;
        this.targetOneReference = targetOneReference;
        this.targetTwoReference = targetTwoReference;
        this.boundaryReference = boundaryReference;
        this.reason = reason == null ? "" : reason.trim();
    }

    public OpenPosition position() { return position; }
    public PositionAction action() { return action; }
    public double currentPrice() { return currentPrice; }
    public double unrealizedPercent() { return unrealizedPercent; }
    public double stopReference() { return stopReference; }
    public double targetOneReference() { return targetOneReference; }
    public double targetTwoReference() { return targetTwoReference; }
    public double boundaryReference() { return boundaryReference; }
    public String reason() { return reason; }

    public boolean shouldNotify() {
        return position != null && action.alertWorthy();
    }

    public String eventKey() {
        if (!shouldNotify()) return "";
        return position.sessionKey() + "|" + action.name();
    }
}
