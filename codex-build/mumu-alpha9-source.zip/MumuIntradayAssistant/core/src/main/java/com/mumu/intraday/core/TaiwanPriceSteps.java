package com.mumu.intraday.core;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class TaiwanPriceSteps {
    private TaiwanPriceSteps() {}

    public static double tickSize(double price) {
        if (!(price > 0.0)) return 0.01;
        if (price < 10.0) return 0.01;
        if (price < 50.0) return 0.05;
        if (price < 100.0) return 0.10;
        if (price < 500.0) return 0.50;
        if (price < 1000.0) return 1.00;
        return 5.00;
    }

    public static double nearestTick(double price) {
        double tick = tickSize(price);
        double rounded = Math.round(price / tick) * tick;
        return roundForDisplay(rounded, tick);
    }

    public static double offsetTicks(double price, int ticks) {
        double step = tickSize(price);
        return nearestTick(price + step * ticks);
    }

    public static String alertZoneBucket(double referencePrice) {
        double tick = tickSize(referencePrice);
        double zoneWidth = tick * 5.0;
        long bucket = Math.round(referencePrice / zoneWidth);
        return Long.toString(bucket);
    }

    private static double roundForDisplay(double value, double tick) {
        int decimals = tick < 0.1 ? 2 : (tick < 1.0 ? 1 : 0);
        return BigDecimal.valueOf(value).setScale(decimals, RoundingMode.HALF_UP).doubleValue();
    }
}
