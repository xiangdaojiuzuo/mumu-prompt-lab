package com.mumu.intraday.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class MarketSnapshot {
    private final String symbol;
    private final String name;
    private final Timeframe timeframe;
    private final long capturedAtEpochMs;
    private final String sourceBarTime;
    private final double currentPrice;
    private final double open;
    private final double high;
    private final double low;
    private final double close;
    private final double volume;
    private final IndicatorPoint ma5;
    private final IndicatorPoint ma10;
    private final IndicatorPoint ma20;
    private final IndicatorPoint ma60;
    private final IndicatorPoint averageVolume5;
    private final IndicatorPoint averageVolume20;
    private final MiddlePanel middlePanel;
    private final IndicatorPoint macdDif;
    private final IndicatorPoint macdSignal;
    private final IndicatorPoint macdHistogram;
    private final double bollingerUpper;
    private final double bollingerMiddle;
    private final double bollingerLower;
    private final IndicatorPoint k;
    private final IndicatorPoint d;
    private final IndicatorPoint j;
    private final double recognitionConfidence;
    private final boolean stableFrame;
    private final List<String> recognitionNotes;

    private MarketSnapshot(Builder b) {
        this.symbol = clean(b.symbol);
        this.name = clean(b.name);
        this.timeframe = b.timeframe == null ? Timeframe.OTHER : b.timeframe;
        this.capturedAtEpochMs = b.capturedAtEpochMs;
        this.sourceBarTime = clean(b.sourceBarTime);
        this.currentPrice = b.currentPrice;
        this.open = b.open;
        this.high = b.high;
        this.low = b.low;
        this.close = b.close;
        this.volume = b.volume;
        this.ma5 = presentOrMissing(b.ma5);
        this.ma10 = presentOrMissing(b.ma10);
        this.ma20 = presentOrMissing(b.ma20);
        this.ma60 = presentOrMissing(b.ma60);
        this.averageVolume5 = presentOrMissing(b.averageVolume5);
        this.averageVolume20 = presentOrMissing(b.averageVolume20);
        this.middlePanel = b.middlePanel == null ? MiddlePanel.UNKNOWN : b.middlePanel;
        this.macdDif = presentOrMissing(b.macdDif);
        this.macdSignal = presentOrMissing(b.macdSignal);
        this.macdHistogram = presentOrMissing(b.macdHistogram);
        this.bollingerUpper = b.bollingerUpper;
        this.bollingerMiddle = b.bollingerMiddle;
        this.bollingerLower = b.bollingerLower;
        this.k = presentOrMissing(b.k);
        this.d = presentOrMissing(b.d);
        this.j = presentOrMissing(b.j);
        this.recognitionConfidence = clamp01(b.recognitionConfidence);
        this.stableFrame = b.stableFrame;
        this.recognitionNotes = Collections.unmodifiableList(new ArrayList<>(b.recognitionNotes));
    }

    private static String clean(String text) {
        return text == null ? "" : text.trim();
    }

    private static IndicatorPoint presentOrMissing(IndicatorPoint value) {
        return value == null ? IndicatorPoint.missing() : value;
    }

    private static double clamp01(double value) {
        if (!Double.isFinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }

    public String symbol() { return symbol; }
    public String name() { return name; }
    public Timeframe timeframe() { return timeframe; }
    public long capturedAtEpochMs() { return capturedAtEpochMs; }
    public String sourceBarTime() { return sourceBarTime; }
    public double currentPrice() { return currentPrice; }
    public double open() { return open; }
    public double high() { return high; }
    public double low() { return low; }
    public double close() { return close; }
    public double volume() { return volume; }
    public IndicatorPoint ma5() { return ma5; }
    public IndicatorPoint ma10() { return ma10; }
    public IndicatorPoint ma20() { return ma20; }
    public IndicatorPoint ma60() { return ma60; }
    public IndicatorPoint averageVolume5() { return averageVolume5; }
    public IndicatorPoint averageVolume20() { return averageVolume20; }
    public MiddlePanel middlePanel() { return middlePanel; }
    public IndicatorPoint macdDif() { return macdDif; }
    public IndicatorPoint macdSignal() { return macdSignal; }
    public IndicatorPoint macdHistogram() { return macdHistogram; }
    public double bollingerUpper() { return bollingerUpper; }
    public double bollingerMiddle() { return bollingerMiddle; }
    public double bollingerLower() { return bollingerLower; }
    public IndicatorPoint k() { return k; }
    public IndicatorPoint d() { return d; }
    public IndicatorPoint j() { return j; }
    public double recognitionConfidence() { return recognitionConfidence; }
    public boolean stableFrame() { return stableFrame; }
    public List<String> recognitionNotes() { return recognitionNotes; }

    public double effectiveClose() {
        // The large quote in Yuanta's stock header is the authoritative live
        // price. OHLC cells can arrive out of OCR reading order, so use close
        // only when the header price itself was not recognized.
        if (Double.isFinite(currentPrice) && currentPrice > 0.0) return currentPrice;
        return close;
    }

    public boolean isFresh(long nowEpochMs) {
        if (timeframe == Timeframe.OTHER || capturedAtEpochMs <= 0L) return false;
        long age = Math.max(0L, nowEpochMs - capturedAtEpochMs);
        return age <= timeframe.maxAgeMs();
    }

    public List<String> missingRequiredFields() {
        List<String> missing = new ArrayList<>();
        if (symbol.isEmpty()) missing.add("股票代號");
        if (timeframe == Timeframe.OTHER) missing.add("K線週期");
        if (!(effectiveClose() > 0.0)) missing.add("現價／收盤價");
        if (!ma5.isPresent()) missing.add("MA5");
        if (!ma10.isPresent()) missing.add("MA10");
        if (!ma20.isPresent()) missing.add("MA20");
        if (!k.isPresent()) missing.add("K值");
        if (!d.isPresent()) missing.add("D值");
        return missing;
    }

    public boolean hasVolumePanelData() {
        return averageVolume5.isPresent() || averageVolume20.isPresent();
    }

    public boolean hasMacdData() {
        return macdDif.isPresent() && macdSignal.isPresent();
    }

    public boolean isUsable() {
        return missingRequiredFields().isEmpty()
                && recognitionConfidence >= 0.78
                && stableFrame;
    }

    public static Builder builder() {
        return new Builder();
    }

    public Builder toBuilder() {
        return new Builder()
                .symbol(symbol).name(name).timeframe(timeframe)
                .capturedAtEpochMs(capturedAtEpochMs).sourceBarTime(sourceBarTime)
                .currentPrice(currentPrice).open(open).high(high).low(low).close(close).volume(volume)
                .ma5(ma5).ma10(ma10).ma20(ma20).ma60(ma60)
                .averageVolume5(averageVolume5).averageVolume20(averageVolume20)
                .middlePanel(middlePanel).macdDif(macdDif).macdSignal(macdSignal).macdHistogram(macdHistogram)
                .bollingerUpper(bollingerUpper).bollingerMiddle(bollingerMiddle).bollingerLower(bollingerLower)
                .k(k).d(d).j(j)
                .recognitionConfidence(recognitionConfidence).stableFrame(stableFrame)
                .addRecognitionNotes(recognitionNotes);
    }

    public static final class Builder {
        private String symbol;
        private String name;
        private Timeframe timeframe;
        private long capturedAtEpochMs;
        private String sourceBarTime;
        private double currentPrice = Double.NaN;
        private double open = Double.NaN;
        private double high = Double.NaN;
        private double low = Double.NaN;
        private double close = Double.NaN;
        private double volume = Double.NaN;
        private IndicatorPoint ma5;
        private IndicatorPoint ma10;
        private IndicatorPoint ma20;
        private IndicatorPoint ma60;
        private IndicatorPoint averageVolume5;
        private IndicatorPoint averageVolume20;
        private MiddlePanel middlePanel;
        private IndicatorPoint macdDif;
        private IndicatorPoint macdSignal;
        private IndicatorPoint macdHistogram;
        private double bollingerUpper = Double.NaN;
        private double bollingerMiddle = Double.NaN;
        private double bollingerLower = Double.NaN;
        private IndicatorPoint k;
        private IndicatorPoint d;
        private IndicatorPoint j;
        private double recognitionConfidence;
        private boolean stableFrame;
        private final List<String> recognitionNotes = new ArrayList<>();

        public Builder symbol(String value) { symbol = value; return this; }
        public Builder name(String value) { name = value; return this; }
        public Builder timeframe(Timeframe value) { timeframe = value; return this; }
        public Builder capturedAtEpochMs(long value) { capturedAtEpochMs = value; return this; }
        public Builder sourceBarTime(String value) { sourceBarTime = value; return this; }
        public Builder currentPrice(double value) { currentPrice = value; return this; }
        public Builder open(double value) { open = value; return this; }
        public Builder high(double value) { high = value; return this; }
        public Builder low(double value) { low = value; return this; }
        public Builder close(double value) { close = value; return this; }
        public Builder volume(double value) { volume = value; return this; }
        public Builder ma5(IndicatorPoint value) { ma5 = value; return this; }
        public Builder ma10(IndicatorPoint value) { ma10 = value; return this; }
        public Builder ma20(IndicatorPoint value) { ma20 = value; return this; }
        public Builder ma60(IndicatorPoint value) { ma60 = value; return this; }
        public Builder averageVolume5(IndicatorPoint value) { averageVolume5 = value; return this; }
        public Builder averageVolume20(IndicatorPoint value) { averageVolume20 = value; return this; }
        public Builder middlePanel(MiddlePanel value) { middlePanel = value; return this; }
        public Builder macdDif(IndicatorPoint value) { macdDif = value; return this; }
        public Builder macdSignal(IndicatorPoint value) { macdSignal = value; return this; }
        public Builder macdHistogram(IndicatorPoint value) { macdHistogram = value; return this; }
        public Builder bollingerUpper(double value) { bollingerUpper = value; return this; }
        public Builder bollingerMiddle(double value) { bollingerMiddle = value; return this; }
        public Builder bollingerLower(double value) { bollingerLower = value; return this; }
        public Builder k(IndicatorPoint value) { k = value; return this; }
        public Builder d(IndicatorPoint value) { d = value; return this; }
        public Builder j(IndicatorPoint value) { j = value; return this; }
        public Builder recognitionConfidence(double value) { recognitionConfidence = value; return this; }
        public Builder stableFrame(boolean value) { stableFrame = value; return this; }
        public Builder addRecognitionNote(String value) {
            if (value != null && !value.isBlank()) recognitionNotes.add(value.trim());
            return this;
        }
        public Builder addRecognitionNotes(List<String> values) {
            if (values != null) values.forEach(this::addRecognitionNote);
            return this;
        }

        public MarketSnapshot build() {
            return new MarketSnapshot(this);
        }
    }
}
