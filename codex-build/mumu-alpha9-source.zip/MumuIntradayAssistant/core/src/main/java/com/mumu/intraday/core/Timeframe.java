package com.mumu.intraday.core;

public enum Timeframe {
    DAILY("日K", 16L * 60L * 60L * 1000L),
    MIN_5("5分K", 8L * 60L * 1000L),
    MIN_1("1分K", 100L * 1000L),
    OTHER("其他", 0L);

    private final String label;
    private final long maxAgeMs;

    Timeframe(String label, long maxAgeMs) {
        this.label = label;
        this.maxAgeMs = maxAgeMs;
    }

    public String label() {
        return label;
    }

    public long maxAgeMs() {
        return maxAgeMs;
    }
}
