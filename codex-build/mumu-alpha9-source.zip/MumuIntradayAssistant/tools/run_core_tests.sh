#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")/.." && pwd)"
classes_dir="$project_dir/build/core-self-test"

mkdir -p "$classes_dir"
find "$classes_dir" -type f -name '*.class' -delete

mapfile -t source_files < <(find \
  "$project_dir/core/src/main/java" \
  "$project_dir/core/src/test/java" \
  -type f -name '*.java' | sort)

java -m jdk.compiler/com.sun.tools.javac.Main \
  -encoding UTF-8 \
  -source 17 \
  -target 17 \
  -d "$classes_dir" \
  "${source_files[@]}"

java -cp "$classes_dir" com.mumu.intraday.core.CoreSelfTest
