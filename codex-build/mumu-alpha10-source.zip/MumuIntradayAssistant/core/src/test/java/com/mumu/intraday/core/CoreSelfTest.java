package com.mumu.intraday.core;

import java.util.HashMap;
import java.util.Map;

public final class CoreSelfTest {
    private static final long NOW = 1_787_805_600_000L;

    public static void main(String[] args) {
        testThreeTimeframeShortSignal();
        testMissingTimeframeForcesWait();
        testMixedSymbolsForceWait();
        testHeaderPriceWinsOverMisreadClose();
        testSnapshotMergeKeepsIntermittentlyMissedFields();
        testLostDecimalPriceScaleIsRepaired();
        testEngineNeverDisplaysFourDigitTriggerForFortyDollarStock();
        testPreEntryPlanHasDirectionalExitLevels();
        testWaitDoesNotInventEntryOrExitPoints();
        testFastModeUsesFiveMinuteDirectionBeforeOneMinuteConfirmation();
        testFastModeDoesNotWaitForDailyContext();
        testBoundaryUsesFiveMinuteMa20();
        testPriceMustReachTriggerBeforeAlert();
        testRepricedSetupAlertsOnlyOnArrival();
        testOneNotificationForPriceOscillation();
        testOppositeDirectionCanNotifyOnce();
        testEntryPlanSurvivesOneMinuteWaitAndTriggersOnPullback();
        testEntryPlanCancelsOnlyAfterConfirmedStructureLoss();
        testEntryPlanInvalidationAndExpiry();
        testPositionAdviceAndOneTimeAlerts();
        System.out.println("CoreSelfTest: all checks passed");
    }

    private static void testThreeTimeframeShortSignal() {
        MultiTimeframeEngine engine = new MultiTimeframeEngine();
        SignalDecision decision = engine.evaluate(daily("3481"), five("3481"), one("3481", 46.70), NOW);
        require(decision.direction() == SignalDirection.SHORT,
                "expected SHORT but was " + decision.direction() + " blockers=" + decision.blockers());
        require(decision.triggerReference() == 46.75,
                "trigger should round to Taiwan tick: " + decision.triggerReference());
        require(decision.eventKey("2026-08-27").contains("3481|SHORT"), "event key missing symbol/direction");
    }

    private static void testMissingTimeframeForcesWait() {
        MultiTimeframeEngine engine = new MultiTimeframeEngine();
        SignalDecision decision = engine.evaluate(daily("3481"), five("3481"), null, NOW);
        require(decision.direction() == SignalDirection.WAIT, "missing 1m must force WAIT");
        require(decision.blockers().stream().anyMatch(x -> x.contains("1分K")), "missing 1m blocker absent");
    }

    private static void testMixedSymbolsForceWait() {
        MultiTimeframeEngine engine = new MultiTimeframeEngine();
        SignalDecision decision = engine.evaluate(daily("3481"), five("3481"), one("2330", 46.70), NOW);
        require(decision.direction() == SignalDirection.WAIT, "mixed symbols must force WAIT");
        require(decision.blockers().stream().anyMatch(x -> x.contains("不是同一檔")), "mixed symbol blocker absent");
    }

    private static void testOneNotificationForPriceOscillation() {
        Memory memory = new Memory();
        AlertGate gate = new AlertGate(memory, 2);
        SignalDecision at4670 = manualSignal(SignalDirection.SHORT, 46.70, 46.73);
        SignalDecision at4675 = manualSignal(SignalDirection.SHORT, 46.75, 46.73);

        require(gate.evaluate(at4670, "2026-08-27", NOW).isEmpty(), "first scan should only arm");
        require(gate.evaluate(at4675, "2026-08-27", NOW + 1_500L).isPresent(), "second stable scan should notify");
        for (int i = 0; i < 20; i++) {
            SignalDecision oscillating = (i % 2 == 0) ? at4670 : at4675;
            require(gate.evaluate(oscillating, "2026-08-27", NOW + 3_000L + i * 1_500L).isEmpty(),
                    "46.70/46.75 oscillation repeated an alert at iteration " + i);
        }
        require(memory.size() == 1, "same signal should have exactly one remembered alert");
    }

    private static void testPriceMustReachTriggerBeforeAlert() {
        Memory memory = new Memory();
        AlertGate gate = new AlertGate(memory, 2);
        SignalDecision farFromZone = manualSignal(SignalDirection.SHORT, 47.20, 46.73);
        require(farFromZone.hasDirectionalSetup(), "directional setup should remain visible");
        require(!farFromZone.shouldNotify(), "price outside the trigger zone must stay silent");
        require(gate.evaluate(farFromZone, "2026-08-27", NOW).isEmpty(),
                "price outside the trigger zone alerted");
        require(memory.size() == 0, "silent setup must not consume its future alert");
    }

    private static void testBoundaryUsesFiveMinuteMa20() {
        MultiTimeframeEngine engine = new MultiTimeframeEngine();
        SignalDecision decision = engine.evaluate(daily("3481"), five("3481"), one("3481", 46.70), NOW);
        require(Math.abs(decision.boundaryReference() - 46.85) < 0.0001,
                "boundary should be rounded 5m MA20: " + decision.boundaryReference());
    }

    private static void testRepricedSetupAlertsOnlyOnArrival() {
        Memory memory = new Memory();
        AlertGate gate = new AlertGate(memory, 2);
        SignalDecision waiting = manualSignal(SignalDirection.SHORT, 47.20, 46.73);
        require(gate.evaluate(waiting, "2026-08-27", NOW).isEmpty(),
                "setup must stay silent before live price arrives");

        SignalDecision reached = waiting.withCurrentPrice(46.75);
        require(reached.shouldNotify(), "repriced setup should recognize arrival");
        require(gate.evaluate(reached, "2026-08-27", NOW + 1_500L).isEmpty(),
                "first arrived quote should arm only");
        require(gate.evaluate(reached, "2026-08-27", NOW + 3_000L).isPresent(),
                "second arrived quote should notify");

        gate.evaluate(waiting, "2026-08-27", NOW + 4_500L);
        require(gate.evaluate(reached.withCurrentPrice(46.70), "2026-08-27", NOW + 6_000L).isEmpty(),
                "returning to an alerted price zone must remain silent");
        require(memory.size() == 1, "arrival should create one remembered event");
    }

    private static void testPositionAdviceAndOneTimeAlerts() {
        PositionManager manager = new PositionManager();
        OpenPosition position = new OpenPosition(
                "2330", "台積電", PositionSide.LONG,
                100.0, NOW, 98.0, 99.0, 102.2, 100.0
        );
        PositionAdvice protect = manager.evaluate(position, 101.0, null, null, null);
        require(protect.action() == PositionAction.PROTECT,
                "one-risk favorable move should protect cost: " + protect.action());
        require(protect.stopReference() == 100.0,
                "protect action should raise stop to entry: " + protect.stopReference());

        Memory memory = new Memory();
        PositionAlertGate gate = new PositionAlertGate(memory, 2);
        require(gate.evaluate(protect, NOW).isEmpty(), "position first scan should arm");
        require(gate.evaluate(protect, NOW + 1_500L).isPresent(), "protect should notify once");
        require(gate.evaluate(protect, NOW + 3_000L).isEmpty(), "protect repeated");

        PositionAdvice exit = manager.evaluate(position, 99.5, null, null, null);
        require(exit.action() == PositionAction.EXIT,
                "price below protected stop should recommend exit: " + exit.action());
        require(gate.evaluate(exit, NOW + 4_500L).isEmpty(), "exit first scan should arm");
        require(gate.evaluate(exit, NOW + 6_000L).isPresent(), "exit should notify once");
        require(gate.evaluate(exit, NOW + 7_500L).isEmpty(), "exit repeated");
        require(memory.size() == 2, "protect and exit should each alert once");
    }

    private static void testSnapshotMergeKeepsIntermittentlyMissedFields() {
        MarketSnapshot first = daily("3481");
        MarketSnapshot next = first.toBuilder()
                .currentPrice(46.75).close(46.75)
                .ma10(IndicatorPoint.missing())
                .k(IndicatorPoint.missing())
                .recognitionConfidence(0.72)
                .build();
        MarketSnapshot merged = SnapshotMerger.merge(first, next);
        require(merged.currentPrice() == 46.75, "new live price should win during merge");
        require(merged.ma10().isPresent(), "previous MA10 should survive one missed OCR frame");
        require(merged.k().isPresent(), "previous K should survive one missed OCR frame");
        require(merged.recognitionConfidence() == 0.94, "best recognition confidence should survive merge");
    }

    private static void testHeaderPriceWinsOverMisreadClose() {
        MarketSnapshot snapshot = daily("1609").toBuilder()
                .currentPrice(37.75)
                .close(38.75)
                .build();
        require(snapshot.effectiveClose() == 37.75,
                "large header quote must win over a misread OHLC close cell");
    }

    private static void testLostDecimalPriceScaleIsRepaired() {
        MarketSnapshot broken = one("3481", 49.10).toBuilder()
                .open(4890).high(4910).low(4885).close(4890)
                .ma5(point(4880, Trend.UP))
                .ma10(point(48905, Trend.UP))
                .ma20(point(48835, Trend.UP))
                .bollingerUpper(49045)
                .bollingerMiddle(48835)
                .bollingerLower(48625)
                .build();
        MarketSnapshot fixed = PriceScaleNormalizer.normalize(broken);
        require(Math.abs(fixed.open() - 48.90) < 0.0001, "OHLC decimal was not repaired");
        require(Math.abs(fixed.high() - 49.10) < 0.0001, "high decimal was not repaired");
        require(Math.abs(fixed.ma5().value() - 48.80) < 0.0001, "MA5 4880 was not repaired");
        require(Math.abs(fixed.ma10().value() - 48.905) < 0.0001, "MA10 48905 was not repaired");
        require(Math.abs(fixed.bollingerMiddle() - 48.835) < 0.0001,
                "Bollinger decimal was not repaired");
        require(fixed.recognitionNotes().stream().anyMatch(x -> x.contains("小數點")),
                "repair should leave a diagnostic note");
    }

    private static void testEngineNeverDisplaysFourDigitTriggerForFortyDollarStock() {
        MarketSnapshot brokenOne = one("3481", 46.70).toBuilder()
                .ma5(point(4675, Trend.DOWN))
                .ma10(point(4673, Trend.DOWN))
                .ma20(point(467925, Trend.DOWN))
                .build();
        SignalDecision decision = new MultiTimeframeEngine()
                .evaluate(daily("3481"), five("3481"), brokenOne, NOW);
        require(decision.direction() == SignalDirection.SHORT,
                "repaired one-minute snapshot should keep the short setup");
        require(decision.triggerReference() > 40.0 && decision.triggerReference() < 60.0,
                "trigger escaped the live-price scale: " + decision.triggerReference());
        require(decision.invalidationReference() > 40.0 && decision.invalidationReference() < 60.0,
                "invalidation escaped the live-price scale: " + decision.invalidationReference());
        require(decision.targetOneReference() > 40.0 && decision.targetOneReference() < 60.0,
                "first target escaped the live-price scale: " + decision.targetOneReference());
    }

    private static void testPreEntryPlanHasDirectionalExitLevels() {
        SignalDecision shortPlan = new MultiTimeframeEngine()
                .evaluate(daily("3481"), five("3481"), one("3481", 46.70), NOW);
        require(shortPlan.direction() == SignalDirection.SHORT, "short plan should be available");
        require(shortPlan.invalidationReference() > shortPlan.triggerReference(),
                "short stop must be above entry");
        require(shortPlan.targetOneReference() < shortPlan.triggerReference(),
                "short first target must be below entry");
        require(shortPlan.targetTwoReference() < shortPlan.targetOneReference(),
                "short second target must be below first target");
        double risk = shortPlan.invalidationReference() - shortPlan.triggerReference();
        double rewardOne = shortPlan.triggerReference() - shortPlan.targetOneReference();
        require(Math.abs(risk - rewardOne) <= TaiwanPriceSteps.tickSize(shortPlan.triggerReference()),
                "first target should be approximately one risk unit");
    }

    private static void testWaitDoesNotInventEntryOrExitPoints() {
        SignalDecision wait = new MultiTimeframeEngine()
                .evaluate(daily("3481"), neutralFive("3481"), one("3481", 49.0), NOW);
        require(wait.direction() == SignalDirection.WAIT, "neutral five-minute chart must wait");
        require(!Double.isFinite(wait.triggerReference()), "WAIT must not invent an entry");
        require(!Double.isFinite(wait.invalidationReference()), "WAIT must not invent a stop");
        require(!Double.isFinite(wait.targetOneReference()), "WAIT must not invent a target");
        require(wait.hasConditionalScenarios(), "WAIT should still show both conditional prices");
        require(wait.longConditionReference() > wait.shortConditionReference(),
                "long and short conditions should form a neutral band");
    }

    private static void testFastModeUsesFiveMinuteDirectionBeforeOneMinuteConfirmation() {
        MarketSnapshot bullishFive = five("3481").toBuilder()
                .currentPrice(49.0).open(48.85).high(49.05).low(48.80).close(49.0)
                .ma5(point(48.95, Trend.UP))
                .ma10(point(48.90, Trend.UP))
                .ma20(point(48.80, Trend.UP))
                .k(point(70.0, Trend.UP)).d(point(55.0, Trend.UP))
                .build();
        SignalDecision fast = new MultiTimeframeEngine()
                .evaluate(daily("3481"), bullishFive, one("3481", 49.0), NOW);
        require(fast.direction() == SignalDirection.LONG,
                "five-minute bullish structure should create a fast long plan even before 1m confirms");
        require(fast.triggerReference() > 0.0, "fast plan must publish its entry condition early");
        require(fast.hasConditionalScenarios(), "fast plan must publish both side conditions");
        require(fast.reasons().stream().anyMatch(x -> x.contains("5分K決定主方向")),
                "fast-mode ownership should be visible in reasons");
    }

    private static void testFastModeDoesNotWaitForDailyContext() {
        SignalDecision fast = new MultiTimeframeEngine()
                .evaluate(null, five("3481"), one("3481", 46.70), NOW);
        require(fast.direction() == SignalDirection.SHORT,
                "five-minute and one-minute data should work before daily context is collected");
        require(fast.reasons().stream().anyMatch(x -> x.contains("日K尚未就緒")),
                "missing daily context should be labeled instead of blocking intraday direction");
    }

    private static void testOppositeDirectionCanNotifyOnce() {
        Memory memory = new Memory();
        AlertGate gate = new AlertGate(memory, 2);
        SignalDecision shortSignal = manualSignal(SignalDirection.SHORT, 46.70, 46.73);
        SignalDecision longSignal = manualSignal(SignalDirection.LONG, 46.95, 46.90);
        gate.evaluate(shortSignal, "2026-08-27", NOW);
        require(gate.evaluate(shortSignal, "2026-08-27", NOW + 1_500L).isPresent(), "short should alert");
        require(gate.evaluate(longSignal, "2026-08-27", NOW + 3_000L).isEmpty(), "long first scan should arm");
        require(gate.evaluate(longSignal, "2026-08-27", NOW + 4_500L).isPresent(), "opposite direction should alert once");
        require(gate.evaluate(longSignal, "2026-08-27", NOW + 6_000L).isEmpty(), "opposite signal repeated");
        require(memory.size() == 2, "one alert per direction expected");
    }

    private static void testEntryPlanSurvivesOneMinuteWaitAndTriggersOnPullback() {
        EntryPlanTracker tracker = new EntryPlanTracker();
        SignalDecision plan = manualLongPlan(49.70);
        EntryPlanTracker.Update armed = tracker.onEvaluation(plan, 49.70, NOW);
        require(armed.event() == EntryPlanTracker.Event.ARMED, "long plan should arm above its zone");
        require(armed.hasActivePlan(), "armed plan should remain active");
        require(!armed.decision().shouldNotify(), "49.70 must not alert for a 49.50-49.60 zone");

        SignalDecision oneMinuteWait = SignalDecision.builder()
                .symbol("3481").name("群創")
                .direction(SignalDirection.WAIT)
                .structuralBias(SignalDirection.LONG)
                .confidencePercent(72)
                .currentPrice(49.60)
                .boundaryReference(49.30)
                .dailyScore(4).fiveMinuteScore(4).oneMinuteScore(0)
                .addBlocker("1分K尚未出現同方向觸發，先不追價")
                .build();
        EntryPlanTracker.Update pullback = tracker.onEvaluation(oneMinuteWait, 49.60, NOW + 60_000L);
        require(pullback.hasActivePlan(), "one-minute WAIT must not erase the valid long plan");
        require(pullback.decision().direction() == SignalDirection.LONG,
                "pullback should still evaluate the original long plan");
        require(pullback.decision().shouldNotify(), "49.60 is inside the original trigger zone");
        require(pullback.event() == EntryPlanTracker.Event.ZONE_REACHED,
                "first pullback into the zone must create an arrival event");
    }

    private static void testEntryPlanCancelsOnlyAfterConfirmedStructureLoss() {
        EntryPlanTracker tracker = new EntryPlanTracker();
        tracker.onEvaluation(manualLongPlan(49.70), 49.70, NOW);
        SignalDecision lostStructure = SignalDecision.builder()
                .symbol("3481").name("群創")
                .direction(SignalDirection.WAIT)
                .structuralBias(SignalDirection.WAIT)
                .confidencePercent(70)
                .currentPrice(49.65)
                .boundaryReference(49.30)
                .addBlocker("日K與5分K尚未形成同方向結構")
                .build();
        EntryPlanTracker.Update first = tracker.onEvaluation(lostStructure, 49.65, NOW + 30_000L);
        require(first.hasActivePlan(), "one structure-loss read must not erase the plan");
        EntryPlanTracker.Update second = tracker.onEvaluation(lostStructure, 49.65, NOW + 32_000L);
        require(!second.hasActivePlan(), "two confirmed structure-loss reads should cancel the plan");
        require(second.event() == EntryPlanTracker.Event.CANCELLED,
                "confirmed structure loss should be recorded as cancellation");
        require(second.decision().direction() == SignalDirection.WAIT,
                "cancelled plan should clearly become WAIT");
    }

    private static void testEntryPlanInvalidationAndExpiry() {
        EntryPlanTracker invalidationTracker = new EntryPlanTracker();
        invalidationTracker.onEvaluation(manualLongPlan(49.70), 49.70, NOW);
        EntryPlanTracker.Update invalidated = invalidationTracker.onPrice(49.25, NOW + 20_000L);
        require(invalidated.event() == EntryPlanTracker.Event.INVALIDATED,
                "touching the long invalidation must cancel the plan");
        require(!invalidated.hasActivePlan(), "invalidated plan must not remain active");

        EntryPlanTracker expiryTracker = new EntryPlanTracker(10_000L);
        expiryTracker.onEvaluation(manualLongPlan(49.70), 49.70, NOW);
        EntryPlanTracker.Update expired = expiryTracker.onPrice(49.65, NOW + 10_000L);
        require(expired.event() == EntryPlanTracker.Event.EXPIRED, "stale plan should expire");
        require(!expired.hasActivePlan(), "expired plan must not remain active");
        EntryPlanTracker.Update rearmed = expiryTracker.onEvaluation(
                manualLongPlan(49.70),
                49.70,
                NOW + 11_000L
        );
        require(rearmed.event() == EntryPlanTracker.Event.ARMED,
                "a fresh K-line evaluation may rearm an expired fast plan");
    }

    private static MarketSnapshot daily(String symbol) {
        return MarketSnapshot.builder()
                .symbol(symbol).name("群創").timeframe(Timeframe.DAILY)
                .capturedAtEpochMs(NOW - 30_000L).sourceBarTime("2026/08/27")
                .currentPrice(46.70).open(46.90).high(47.30).low(46.20).close(46.70).volume(78_893)
                .ma5(point(46.28, Trend.UP)).ma10(point(47.495, Trend.DOWN)).ma20(point(48.08, Trend.UP))
                .ma60(point(54.10, Trend.DOWN))
                .bollingerUpper(52.1866).bollingerMiddle(48.08).bollingerLower(43.9734)
                .averageVolume5(point(125_465, Trend.DOWN)).averageVolume20(point(239_453, Trend.DOWN))
                .k(point(24.038, Trend.UP)).d(point(27.115, Trend.DOWN)).j(point(17.884, Trend.UP))
                .recognitionConfidence(0.94).stableFrame(true).build();
    }

    private static MarketSnapshot five(String symbol) {
        return MarketSnapshot.builder()
                .symbol(symbol).name("群創").timeframe(Timeframe.MIN_5)
                .capturedAtEpochMs(NOW - 20_000L).sourceBarTime("08/27 10:55")
                .currentPrice(46.70).open(46.75).high(46.75).low(46.70).close(46.70).volume(671)
                .ma5(point(46.80, Trend.DOWN)).ma10(point(46.845, Trend.DOWN)).ma20(point(46.835, Trend.UP))
                .ma60(point(46.90, Trend.DOWN))
                .bollingerUpper(47.2039).bollingerMiddle(46.835).bollingerLower(46.4661)
                .averageVolume5(point(901, Trend.DOWN)).averageVolume20(point(2_496, Trend.DOWN))
                .k(point(13.089, Trend.DOWN)).d(point(24.719, Trend.DOWN)).j(point(-10.17, Trend.DOWN))
                .recognitionConfidence(0.93).stableFrame(true).build();
    }

    private static MarketSnapshot neutralFive(String symbol) {
        return MarketSnapshot.builder()
                .symbol(symbol).name("群創").timeframe(Timeframe.MIN_5)
                .capturedAtEpochMs(NOW - 20_000L).sourceBarTime("08/27 10:55")
                .currentPrice(49.0).open(49.0).high(49.05).low(48.95).close(49.0).volume(100)
                .ma5(point(49.0, Trend.FLAT)).ma10(point(49.0, Trend.FLAT))
                .ma20(point(49.0, Trend.FLAT)).ma60(point(49.0, Trend.FLAT))
                .bollingerUpper(49.30).bollingerMiddle(49.0).bollingerLower(48.70)
                .averageVolume5(point(100, Trend.FLAT)).averageVolume20(point(100, Trend.FLAT))
                .k(point(50.0, Trend.FLAT)).d(point(50.0, Trend.FLAT)).j(point(50.0, Trend.FLAT))
                .recognitionConfidence(0.95).stableFrame(true).build();
    }

    private static MarketSnapshot one(String symbol, double price) {
        return MarketSnapshot.builder()
                .symbol(symbol).name("群創").timeframe(Timeframe.MIN_1)
                .capturedAtEpochMs(NOW - 5_000L).sourceBarTime("08/27 10:53")
                .currentPrice(price).open(46.70).high(46.75).low(46.70).close(price).volume(52)
                .ma5(point(46.73, Trend.DOWN)).ma10(point(46.73, Trend.DOWN)).ma20(point(46.7925, Trend.DOWN))
                .ma60(point(46.9008, Trend.DOWN))
                .bollingerUpper(46.9577).bollingerMiddle(46.7925).bollingerLower(46.6273)
                .averageVolume5(point(150, Trend.DOWN)).averageVolume20(point(196, Trend.DOWN))
                .k(point(22.181, Trend.DOWN)).d(point(23.418, Trend.DOWN)).j(point(19.707, Trend.DOWN))
                .recognitionConfidence(0.95).stableFrame(true).build();
    }

    private static IndicatorPoint point(double value, Trend trend) {
        return new IndicatorPoint(value, trend);
    }

    private static SignalDecision manualSignal(SignalDirection direction, double price, double reference) {
        double tick = TaiwanPriceSteps.tickSize(reference);
        return SignalDecision.builder()
                .symbol("3481").name("群創").direction(direction).structuralBias(direction)
                .currentPrice(price).triggerReference(reference)
                .zoneLow(reference - tick).zoneHigh(reference + tick)
                .invalidationReference(direction == SignalDirection.SHORT ? 46.90 : 46.65)
                .confidencePercent(82).addReason("測試訊號").build();
    }

    private static SignalDecision manualLongPlan(double price) {
        return SignalDecision.builder()
                .symbol("3481").name("群創")
                .direction(SignalDirection.LONG).structuralBias(SignalDirection.LONG)
                .currentPrice(price).boundaryReference(49.30)
                .triggerReference(49.55).zoneLow(49.50).zoneHigh(49.60)
                .invalidationReference(49.25)
                .targetOneReference(49.85).targetTwoReference(50.10)
                .dailyScore(4).fiveMinuteScore(5).oneMinuteScore(3)
                .confidencePercent(74).addReason("日K與5分K偏多")
                .build();
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static final class Memory implements AlertMemory {
        private final Map<String, Long> values = new HashMap<>();
        @Override public boolean wasAlerted(String eventKey) { return values.containsKey(eventKey); }
        @Override public void remember(String eventKey, long alertedAtEpochMs) { values.put(eventKey, alertedAtEpochMs); }
        @Override public void clear() { values.clear(); }
        int size() { return values.size(); }
    }
}
