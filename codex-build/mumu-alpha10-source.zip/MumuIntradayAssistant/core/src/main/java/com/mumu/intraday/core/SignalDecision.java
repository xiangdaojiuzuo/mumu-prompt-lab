package com.mumu.intraday.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class SignalDecision {
    private final String symbol;
    private final String name;
    private final SignalDirection direction;
    private final SignalDirection structuralBias;
    private final int confidencePercent;
    private final double currentPrice;
    private final double boundaryReference;
    private final double longConditionReference;
    private final double shortConditionReference;
    private final double triggerReference;
    private final double zoneLow;
    private final double zoneHigh;
    private final double invalidationReference;
    private final double targetOneReference;
    private final double targetTwoReference;
    private final List<String> reasons;
    private final List<String> blockers;
    private final int dailyScore;
    private final int fiveMinuteScore;
    private final int oneMinuteScore;

    private SignalDecision(Builder b) {
        symbol = safe(b.symbol);
        name = safe(b.name);
        direction = b.direction == null ? SignalDirection.WAIT : b.direction;
        structuralBias = b.structuralBias == null ? SignalDirection.WAIT : b.structuralBias;
        confidencePercent = Math.max(0, Math.min(100, b.confidencePercent));
        currentPrice = b.currentPrice;
        boundaryReference = b.boundaryReference;
        longConditionReference = b.longConditionReference;
        shortConditionReference = b.shortConditionReference;
        triggerReference = b.triggerReference;
        zoneLow = b.zoneLow;
        zoneHigh = b.zoneHigh;
        invalidationReference = b.invalidationReference;
        targetOneReference = b.targetOneReference;
        targetTwoReference = b.targetTwoReference;
        reasons = Collections.unmodifiableList(new ArrayList<>(b.reasons));
        blockers = Collections.unmodifiableList(new ArrayList<>(b.blockers));
        dailyScore = b.dailyScore;
        fiveMinuteScore = b.fiveMinuteScore;
        oneMinuteScore = b.oneMinuteScore;
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }

    public String symbol() { return symbol; }
    public String name() { return name; }
    public SignalDirection direction() { return direction; }
    public SignalDirection structuralBias() { return structuralBias; }
    public int confidencePercent() { return confidencePercent; }
    public double currentPrice() { return currentPrice; }
    public double boundaryReference() { return boundaryReference; }
    public double longConditionReference() { return longConditionReference; }
    public double shortConditionReference() { return shortConditionReference; }
    public double triggerReference() { return triggerReference; }
    public double zoneLow() { return zoneLow; }
    public double zoneHigh() { return zoneHigh; }
    public double invalidationReference() { return invalidationReference; }
    public double targetOneReference() { return targetOneReference; }
    public double targetTwoReference() { return targetTwoReference; }
    public List<String> reasons() { return reasons; }
    public List<String> blockers() { return blockers; }
    public int dailyScore() { return dailyScore; }
    public int fiveMinuteScore() { return fiveMinuteScore; }
    public int oneMinuteScore() { return oneMinuteScore; }

    public boolean hasDirectionalSetup() {
        return direction == SignalDirection.LONG || direction == SignalDirection.SHORT;
    }

    public boolean hasConditionalScenarios() {
        return longConditionReference > 0.0 && shortConditionReference > 0.0;
    }

    public boolean isNearTrigger() {
        if (!hasDirectionalSetup() || shouldNotify() || !(currentPrice > 0.0)) return false;
        double low = Math.min(zoneLow, zoneHigh);
        double high = Math.max(zoneLow, zoneHigh);
        if (!Double.isFinite(low) || !Double.isFinite(high)) return false;
        double distance = currentPrice < low ? low - currentPrice : currentPrice - high;
        return distance <= TaiwanPriceSteps.tickSize(currentPrice) * 2.01;
    }

    /**
     * A setup may stay visible before price reaches it.  The audible/heads-up
     * notification is armed only while the live one-minute close is inside the
     * displayed trigger zone.
     */
    public boolean shouldNotify() {
        if (!hasDirectionalSetup()
                || !Double.isFinite(currentPrice)
                || !Double.isFinite(zoneLow)
                || !Double.isFinite(zoneHigh)) {
            return false;
        }
        double low = Math.min(zoneLow, zoneHigh);
        double high = Math.max(zoneLow, zoneHigh);
        double tolerance = TaiwanPriceSteps.tickSize(currentPrice) * 0.01;
        return currentPrice + tolerance >= low && currentPrice - tolerance <= high;
    }

    public String eventKey(String tradingDateKey) {
        if (!shouldNotify() || !(triggerReference > 0.0)) return "";
        return safe(tradingDateKey)
                + "|" + symbol
                + "|" + direction.name()
                + "|" + TaiwanPriceSteps.alertZoneBucket(triggerReference);
    }

    /**
     * Keeps the last complete K-line setup while replacing only its live quote.
     * This lets the order page continue watching the already calculated entry
     * price without reading any account or order-entry fields.
     */
    public SignalDecision withCurrentPrice(double value) {
        return builder()
                .symbol(symbol)
                .name(name)
                .direction(direction)
                .structuralBias(structuralBias)
                .confidencePercent(confidencePercent)
                .currentPrice(value)
                .boundaryReference(boundaryReference)
                .longConditionReference(longConditionReference)
                .shortConditionReference(shortConditionReference)
                .triggerReference(triggerReference)
                .zoneLow(zoneLow)
                .zoneHigh(zoneHigh)
                .invalidationReference(invalidationReference)
                .targetOneReference(targetOneReference)
                .targetTwoReference(targetTwoReference)
                .addReasons(reasons)
                .addBlockers(blockers)
                .dailyScore(dailyScore)
                .fiveMinuteScore(fiveMinuteScore)
                .oneMinuteScore(oneMinuteScore)
                .build();
    }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private String symbol;
        private String name;
        private SignalDirection direction;
        private SignalDirection structuralBias;
        private int confidencePercent;
        private double currentPrice = Double.NaN;
        private double boundaryReference = Double.NaN;
        private double longConditionReference = Double.NaN;
        private double shortConditionReference = Double.NaN;
        private double triggerReference = Double.NaN;
        private double zoneLow = Double.NaN;
        private double zoneHigh = Double.NaN;
        private double invalidationReference = Double.NaN;
        private double targetOneReference = Double.NaN;
        private double targetTwoReference = Double.NaN;
        private final List<String> reasons = new ArrayList<>();
        private final List<String> blockers = new ArrayList<>();
        private int dailyScore;
        private int fiveMinuteScore;
        private int oneMinuteScore;

        public Builder symbol(String value) { symbol = value; return this; }
        public Builder name(String value) { name = value; return this; }
        public Builder direction(SignalDirection value) { direction = value; return this; }
        public Builder structuralBias(SignalDirection value) { structuralBias = value; return this; }
        public Builder confidencePercent(int value) { confidencePercent = value; return this; }
        public Builder currentPrice(double value) { currentPrice = value; return this; }
        public Builder boundaryReference(double value) { boundaryReference = value; return this; }
        public Builder longConditionReference(double value) { longConditionReference = value; return this; }
        public Builder shortConditionReference(double value) { shortConditionReference = value; return this; }
        public Builder triggerReference(double value) { triggerReference = value; return this; }
        public Builder zoneLow(double value) { zoneLow = value; return this; }
        public Builder zoneHigh(double value) { zoneHigh = value; return this; }
        public Builder invalidationReference(double value) { invalidationReference = value; return this; }
        public Builder targetOneReference(double value) { targetOneReference = value; return this; }
        public Builder targetTwoReference(double value) { targetTwoReference = value; return this; }
        public Builder addReason(String value) {
            if (value != null && !value.isBlank()) reasons.add(value.trim());
            return this;
        }
        public Builder addReasons(List<String> values) {
            if (values != null) values.forEach(this::addReason);
            return this;
        }
        public Builder addBlocker(String value) {
            if (value != null && !value.isBlank()) blockers.add(value.trim());
            return this;
        }
        public Builder addBlockers(List<String> values) {
            if (values != null) values.forEach(this::addBlocker);
            return this;
        }
        public Builder dailyScore(int value) { dailyScore = value; return this; }
        public Builder fiveMinuteScore(int value) { fiveMinuteScore = value; return this; }
        public Builder oneMinuteScore(int value) { oneMinuteScore = value; return this; }
        public SignalDecision build() { return new SignalDecision(this); }
    }
}
